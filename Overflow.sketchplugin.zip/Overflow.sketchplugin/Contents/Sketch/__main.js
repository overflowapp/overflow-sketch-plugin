var globalThis = this;
var global = this;
function __skpm_run (key, context) {
  globalThis.context = context;
  try {

var exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/main.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./node_modules/@babel/runtime/helpers/arrayLikeToArray.js":
/*!*****************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/arrayLikeToArray.js ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _arrayLikeToArray(arr, len) {
  if (len == null || len > arr.length) len = arr.length;

  for (var i = 0, arr2 = new Array(len); i < len; i++) {
    arr2[i] = arr[i];
  }

  return arr2;
}

module.exports = _arrayLikeToArray;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/arrayWithoutHoles.js":
/*!******************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/arrayWithoutHoles.js ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var arrayLikeToArray = __webpack_require__(/*! ./arrayLikeToArray */ "./node_modules/@babel/runtime/helpers/arrayLikeToArray.js");

function _arrayWithoutHoles(arr) {
  if (Array.isArray(arr)) return arrayLikeToArray(arr);
}

module.exports = _arrayWithoutHoles;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/asyncToGenerator.js":
/*!*****************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/asyncToGenerator.js ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(Promise) {function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
  try {
    var info = gen[key](arg);
    var value = info.value;
  } catch (error) {
    reject(error);
    return;
  }

  if (info.done) {
    resolve(value);
  } else {
    Promise.resolve(value).then(_next, _throw);
  }
}

function _asyncToGenerator(fn) {
  return function () {
    var self = this,
        args = arguments;
    return new Promise(function (resolve, reject) {
      var gen = fn.apply(self, args);

      function _next(value) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
      }

      function _throw(err) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
      }

      _next(undefined);
    });
  };
}

module.exports = _asyncToGenerator;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@skpm/promise/index.js */ "./node_modules/@skpm/promise/index.js")))

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/classCallCheck.js":
/*!***************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/classCallCheck.js ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

module.exports = _classCallCheck;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/createClass.js":
/*!************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/createClass.js ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

module.exports = _createClass;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/iterableToArray.js":
/*!****************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/iterableToArray.js ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _iterableToArray(iter) {
  if (typeof Symbol !== "undefined" && Symbol.iterator in Object(iter)) return Array.from(iter);
}

module.exports = _iterableToArray;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/nonIterableSpread.js":
/*!******************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/nonIterableSpread.js ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _nonIterableSpread() {
  throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}

module.exports = _nonIterableSpread;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/toConsumableArray.js":
/*!******************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/toConsumableArray.js ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var arrayWithoutHoles = __webpack_require__(/*! ./arrayWithoutHoles */ "./node_modules/@babel/runtime/helpers/arrayWithoutHoles.js");

var iterableToArray = __webpack_require__(/*! ./iterableToArray */ "./node_modules/@babel/runtime/helpers/iterableToArray.js");

var unsupportedIterableToArray = __webpack_require__(/*! ./unsupportedIterableToArray */ "./node_modules/@babel/runtime/helpers/unsupportedIterableToArray.js");

var nonIterableSpread = __webpack_require__(/*! ./nonIterableSpread */ "./node_modules/@babel/runtime/helpers/nonIterableSpread.js");

function _toConsumableArray(arr) {
  return arrayWithoutHoles(arr) || iterableToArray(arr) || unsupportedIterableToArray(arr) || nonIterableSpread();
}

module.exports = _toConsumableArray;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/unsupportedIterableToArray.js":
/*!***************************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/unsupportedIterableToArray.js ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var arrayLikeToArray = __webpack_require__(/*! ./arrayLikeToArray */ "./node_modules/@babel/runtime/helpers/arrayLikeToArray.js");

function _unsupportedIterableToArray(o, minLen) {
  if (!o) return;
  if (typeof o === "string") return arrayLikeToArray(o, minLen);
  var n = Object.prototype.toString.call(o).slice(8, -1);
  if (n === "Object" && o.constructor) n = o.constructor.name;
  if (n === "Map" || n === "Set") return Array.from(o);
  if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return arrayLikeToArray(o, minLen);
}

module.exports = _unsupportedIterableToArray;

/***/ }),

/***/ "./node_modules/@babel/runtime/regenerator/index.js":
/*!**********************************************************!*\
  !*** ./node_modules/@babel/runtime/regenerator/index.js ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! regenerator-runtime */ "./node_modules/regenerator-runtime/runtime.js");


/***/ }),

/***/ "./node_modules/@skpm/builder/node_modules/sketch-polyfill-fetch/lib/form-data.js":
/*!****************************************************************************************!*\
  !*** ./node_modules/@skpm/builder/node_modules/sketch-polyfill-fetch/lib/form-data.js ***!
  \****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var Buffer
try {
  Buffer = __webpack_require__(/*! buffer */ "buffer").Buffer
} catch (err) {}
var util
try {
  util = __webpack_require__(/*! util */ "util")
} catch (err) {}

var boundary = "Boundary-" + NSUUID.UUID().UUIDString()

module.exports = function FormData() {
  var data = NSMutableData.data()
  return {
    _boundary: boundary,
    _isFormData: true,
    _data: data,
    append: function(field, value) {
      data.appendData(
        NSString.alloc()
          .initWithString("--" + boundary + "\r\n")
          .dataUsingEncoding(NSUTF8StringEncoding)
      )
      data.appendData(
        NSString.alloc()
          .initWithString("Content-Disposition: form-data; name=\"" + field + "\"")
          .dataUsingEncoding(NSUTF8StringEncoding)
      )
      if (util ? util.isString(value) : typeof value === 'string') {
        data.appendData(
          NSString.alloc()
            .initWithString("\r\n\r\n" + value)
            .dataUsingEncoding(NSUTF8StringEncoding)
        )
      } else if (value && value.fileName && value.data && value.mimeType) {
        var nsdata
        if (Buffer && Buffer.isBuffer(value.data)) {
          nsdata = value.data.toNSData()
        } else if (value.data.isKindOfClass && value.data.isKindOfClass(NSData) == 1) {
          nsdata = value.data
        } else {
          throw new Error('unknown data type')
        }
        data.appendData(
          NSString.alloc()
            .initWithString("; filename=\"" + value.fileName + "\"\r\nContent-Type: " + value.mimeType + "\r\n\r\n")
            .dataUsingEncoding(NSUTF8StringEncoding)
        )
        data.appendData(nsdata)
      } else {
        throw new Error('unknown value type')
      }
      data.appendData(
        NSString.alloc()
          .initWithString("\r\n")
          .dataUsingEncoding(NSUTF8StringEncoding)
      )
    }
  }
}


/***/ }),

/***/ "./node_modules/@skpm/builder/node_modules/sketch-polyfill-fetch/lib/index.js":
/*!************************************************************************************!*\
  !*** ./node_modules/@skpm/builder/node_modules/sketch-polyfill-fetch/lib/index.js ***!
  \************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(Promise) {/* globals NSJSONSerialization NSJSONWritingPrettyPrinted NSDictionary NSHTTPURLResponse NSString NSASCIIStringEncoding NSUTF8StringEncoding coscript NSURL NSMutableURLRequest NSMutableData NSURLConnection */
var Buffer;
try {
  Buffer = __webpack_require__(/*! buffer */ "buffer").Buffer;
} catch (err) {}

function response(httpResponse, data) {
  var keys = [];
  var all = [];
  var headers = {};
  var header;

  for (var i = 0; i < httpResponse.allHeaderFields().allKeys().length; i++) {
    var key = httpResponse
      .allHeaderFields()
      .allKeys()
      [i].toLowerCase();
    var value = String(httpResponse.allHeaderFields()[key]);
    keys.push(key);
    all.push([key, value]);
    header = headers[key];
    headers[key] = header ? header + "," + value : value;
  }

  return {
    ok: ((httpResponse.statusCode() / 200) | 0) == 1, // 200-399
    status: Number(httpResponse.statusCode()),
    statusText: String(
      NSHTTPURLResponse.localizedStringForStatusCode(httpResponse.statusCode())
    ),
    useFinalURL: true,
    url: String(httpResponse.URL().absoluteString()),
    clone: response.bind(this, httpResponse, data),
    text: function() {
      return new Promise(function(resolve, reject) {
        const str = String(
          NSString.alloc().initWithData_encoding(data, NSASCIIStringEncoding)
        );
        if (str) {
          resolve(str);
        } else {
          reject(new Error("Couldn't parse body"));
        }
      });
    },
    json: function() {
      return new Promise(function(resolve, reject) {
        var str = String(
          NSString.alloc().initWithData_encoding(data, NSUTF8StringEncoding)
        );
        if (str) {
          // parse errors are turned into exceptions, which cause promise to be rejected
          var obj = JSON.parse(str);
          resolve(obj);
        } else {
          reject(
            new Error(
              "Could not parse JSON because it is not valid UTF-8 data."
            )
          );
        }
      });
    },
    blob: function() {
      return Promise.resolve(data);
    },
    arrayBuffer: function() {
      return Promise.resolve(Buffer.from(data));
    },
    headers: {
      keys: function() {
        return keys;
      },
      entries: function() {
        return all;
      },
      get: function(n) {
        return headers[n.toLowerCase()];
      },
      has: function(n) {
        return n.toLowerCase() in headers;
      }
    }
  };
}

// We create one ObjC class for ourselves here
var DelegateClass;

function fetch(urlString, options) {
  if (
    typeof urlString === "object" &&
    (!urlString.isKindOfClass || !urlString.isKindOfClass(NSString))
  ) {
    options = urlString;
    urlString = options.url;
  }
  options = options || {};
  if (!urlString) {
    return Promise.reject("Missing URL");
  }
  var fiber;
  try {
    fiber = coscript.createFiber();
  } catch (err) {
    coscript.shouldKeepAround = true;
  }
  return new Promise(function(resolve, reject) {
    var url = NSURL.alloc().initWithString(urlString);
    var request = NSMutableURLRequest.requestWithURL(url);
    request.setHTTPMethod(options.method || "GET");

    Object.keys(options.headers || {}).forEach(function(i) {
      request.setValue_forHTTPHeaderField(options.headers[i], i);
    });

    if (options.body) {
      var data;
      if (typeof options.body === "string") {
        var str = NSString.alloc().initWithString(options.body);
        data = str.dataUsingEncoding(NSUTF8StringEncoding);
      } else if (Buffer && Buffer.isBuffer(options.body)) {
        data = options.body.toNSData();
      } else if (
        options.body.isKindOfClass &&
        options.body.isKindOfClass(NSData) == 1
      ) {
        data = options.body;
      } else if (options.body._isFormData) {
        var boundary = options.body._boundary;
        data = options.body._data;
        data.appendData(
          NSString.alloc()
            .initWithString("--" + boundary + "--\r\n")
            .dataUsingEncoding(NSUTF8StringEncoding)
        );
        request.setValue_forHTTPHeaderField(
          "multipart/form-data; boundary=" + boundary,
          "Content-Type"
        );
      } else {
        var error;
        data = NSJSONSerialization.dataWithJSONObject_options_error(
          options.body,
          NSJSONWritingPrettyPrinted,
          error
        );
        if (error != null) {
          return reject(error);
        }
        request.setValue_forHTTPHeaderField(
          "" + data.length(),
          "Content-Length"
        );
      }
      request.setHTTPBody(data);
    }

    if (options.cache) {
      switch (options.cache) {
        case "reload":
        case "no-cache":
        case "no-store": {
          request.setCachePolicy(1); // NSURLRequestReloadIgnoringLocalCacheData
        }
        case "force-cache": {
          request.setCachePolicy(2); // NSURLRequestReturnCacheDataElseLoad
        }
        case "only-if-cached": {
          request.setCachePolicy(3); // NSURLRequestReturnCacheDataElseLoad
        }
      }
    }

    if (!options.credentials) {
      request.setHTTPShouldHandleCookies(false);
    }

    var finished = false;

    var connection = NSURLSession.sharedSession().dataTaskWithRequest_completionHandler(
      request,
      __mocha__.createBlock_function(
        'v32@?0@"NSData"8@"NSURLResponse"16@"NSError"24',
        function(data, res, error) {
          if (fiber) {
            fiber.cleanup();
          } else {
            coscript.shouldKeepAround = false;
          }
          if (error) {
            finished = true;
            return reject(error);
          }
          return resolve(response(res, data));
        }
      )
    );

    connection.resume();

    if (fiber) {
      fiber.onCleanup(function() {
        if (!finished) {
          connection.cancel();
        }
      });
    }
  });
}

module.exports = fetch;

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@skpm/promise/index.js */ "./node_modules/@skpm/promise/index.js")))

/***/ }),

/***/ "./node_modules/@skpm/console/index.js":
/*!*********************************************!*\
  !*** ./node_modules/@skpm/console/index.js ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/* globals log, __command, NSThread */

var util = __webpack_require__(/*! util */ "util")
var prepareValue = __webpack_require__(/*! ./prepare-value */ "./node_modules/@skpm/console/prepare-value.js")

var indentLevel = 0
function indentString(string) {
  var indent = ""
  for (var i = 0; i < indentLevel; i += 1) {
    indent += "  "
  }
  if (indentLevel > 0) {
    indent += "| "
  }

  return string.replace(/\n/g, indent + "\n")
}

function logEverywhere(level, payload, skipFormat) {
  var stringValue = skipFormat ? payload : util.format.apply(this, payload)

  log({
    stringValue: indentString(stringValue),
    payload: [prepareValue(payload)],
    level: level,
    command: __command
  })
}

if (!console._sketch) {
  var oldAssert = console.assert
  console.assert = function assert(condition, text) {
    // log to the JS context
    if (oldAssert) oldAssert.apply(this, arguments)

    if (!condition) {
      return logEverywhere("assert", [text])
    }
    return undefined
  }

  var oldClear = console.clear
  console.clear = function clear() {
    if (oldClear) oldClear.apply(this, arguments)

    var threadDictionary = NSThread.mainThread().threadDictionary()
    var panel = threadDictionary["skpm.debugger"]
    if (!panel) {
      return
    }

    var webview = panel.contentView().subviews()[0]
    if (!webview || !webview.evaluateJavaScript_completionHandler) {
      return
    }

    webview.evaluateJavaScript_completionHandler(
      'sketchBridge({"name":"logs/CLEAR_LOGS"});',
      null
    )
  }

  var counts = {}

  var oldCount = console.count
  console.count = function count(label) {
    // log to the JS context
    if (oldCount) oldCount.apply(this, arguments)

    label = typeof label !== "undefined" ? label : "default"
    counts[label] = (counts[label] || 0) + 1

    return logEverywhere("log", label + ": " + counts[label], true)
  }

  var oldCountReset = console.countReset
  console.countReset = function countReset(label) {
    // log to the JS context
    if (oldCountReset) oldCountReset.apply(this, arguments)

    label = typeof label !== "undefined" ? label : "default"
    counts[label] = 0
  }

  console.debug = console.log

  var oldDir = console.dir
  console.dir = function dir(obj, options) {
    // log to the JS context
    if (oldDir) oldDir.apply(this, arguments)

    options = options || {}
    options.customInspect = false
    return logEverywhere("log", util.inspect(obj, options), true)
  }

  var oldDirxml = console.dirxml
  console.dirxml = function dirxml() {
    // log to the JS context
    if (oldDirxml) oldDirxml.apply(this, arguments)

    return logEverywhere("log", Array.from(arguments))
  }

  var oldError = console.error
  console.error = function error() {
    // log to the JS context
    if (oldError) oldError.apply(this, arguments)
    return logEverywhere("error", Array.from(arguments))
  }

  var oldGroup = console.group
  console.group = function group() {
    // log to the JS context
    if (oldGroup) oldGroup.apply(this, arguments)

    if (arguments.length) {
      Array.from(arguments).forEach(function logItems(label) {
        logEverywhere("log", [label])
      })
    }
    indentLevel += 1
  }

  console.groupCollapsed = console.group

  var oldGroupEnd = console.groupEnd
  console.groupEnd = function groupEnd() {
    // log to the JS context
    if (oldGroupEnd) oldGroupEnd.apply(this, arguments)

    indentLevel -= 1
    if (indentLevel < 0) {
      indentLevel = 0
    }
  }

  var oldInfo = console.info
  console.info = function info() {
    // log to the JS context
    if (oldInfo) oldInfo.apply(this, arguments)

    return logEverywhere("info", Array.from(arguments))
  }

  var oldLog = console.log
  console.log = function log() {
    // log to the JS context
    if (oldLog) oldLog.apply(this, arguments)

    return logEverywhere("log", Array.from(arguments))
  }

  var timers = {}

  var oldTime = console.time
  console.time = function time(label) {
    // log to the JS context
    if (oldTime) oldTime.apply(this, arguments)

    label = typeof label !== "undefined" ? label : "default"
    if (timers[label]) {
      return logEverywhere("warn", 'Timer "' + label + '" already exists', true)
    }

    timers[label] = Date.now()
    return undefined
  }

  var oldTimeEnd = console.timeEnd
  console.timeEnd = function timeEnd(label) {
    // log to the JS context
    if (oldTimeEnd) oldTimeEnd.apply(this, arguments)

    label = typeof label !== "undefined" ? label : "default"
    if (!timers[label]) {
      return logEverywhere("warn", 'Timer "' + label + '" does not exist', true)
    }

    var duration = Date.now() - timers[label]
    delete timers[label]
    return logEverywhere("log", [label + ": " + duration + "ms"])
  }

  // console.trace = function() {}

  var oldWarn = console.warn
  console.warn = function warm() {
    // log to the JS context
    if (oldWarn) oldWarn.apply(this, arguments)

    return logEverywhere("warn", Array.from(arguments))
  }

  console._sketch = true
}

module.exports = function createConsole() {
  return console
}


/***/ }),

/***/ "./node_modules/@skpm/console/prepare-value.js":
/*!*****************************************************!*\
  !*** ./node_modules/@skpm/console/prepare-value.js ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var util = __webpack_require__(/*! util */ "util")

function prepareArray(array, options) {
  return array.map(function prepareItem(i) {
    return prepareValue(i, options) // eslint-disable-line no-use-before-define
  })
}

function prepareObject(object, options) {
  if (!object) {
    return {}
  }
  const deep = {}
  Object.keys(object).forEach(function prepareItem(key) {
    deep[key] = prepareValue(object[key], options) // eslint-disable-line no-use-before-define
  })
  return deep
}

function prepareValue(value, options) {
  if (!options) {
    options = {}
  }
  if (!options.seen) {
    options.seen = []
  }
  var type
  var primitive
  if (util.isArray(value)) {
    type = Array.isArray(value) ? "Array" : util.getNativeClass(value)
    primitive = "Array"
    if (options.seen.indexOf(value) !== -1) {
      type = "Circular"
      value = []
    } else {
      options.seen.push(value)
      value = prepareArray(util.toArray(value), options)
    }
  } else if (util.isBoolean(value)) {
    type = typeof value === "boolean" ? "Boolean" : util.getNativeClass(value)
    primitive = "Boolean"
    value = Boolean(Number(value))
  } else if (util.isNullOrUndefined(value) || Number.isNaN(value)) {
    type = "Empty"
    primitive = "Empty"
    value = String(value)
  } else if (util.isNumber(value)) {
    type = typeof value === "number" ? "Number" : util.getNativeClass(value)
    primitive = "Number"
    value = Number(value)
  } else if (util.isString(value)) {
    type = typeof value === "string" ? "String" : util.getNativeClass(value)
    primitive = "String"
    value = String(value)
  } else if (util.getNativeClass(value) === 'MOStruct') {
    type = 'MOStruct'
    primitive = "Object"
    value = prepareObject(util.toObject(value), options)
  } else if (util.isSymbol(value)) {
    type = "Symbol"
    primitive = "Symbol"
    value = util.inspect(value)
  } else if (util.isRegExp(value)) {
    type = "RegExp"
    primitive = "RegExp"
    value = util.inspect(value)
  } else if (util.isDate(value)) {
    type = "Date"
    primitive = "Date"
    value = util.inspect(value)
  } else if (util.isFunction(value)) {
    type = typeof value === "function" ? "Function" : util.getNativeClass(value)
    primitive = "Function"
    value =
      typeof value === "function" ? "[Function]" : util.getNativeClass(value)
  } else if (util.isBuffer(value)) {
    type = "Buffer"
    primitive = "Buffer"
    value = String(value)
  } else if (util.isError(value)) {
    type = "Error"
    primitive = "Error"
    value = {
      message: value.message,
      name: value.name,
      stack: value.stack,
      nativeException: prepareValue(value.nativeException, options)
    }
  } else if (util.isObject(value)) {
    var nativeClass = util.getNativeClass(value)
    type = nativeClass || "Object"
    primitive = "Object"
    if (options.seen.indexOf(value) !== -1) {
      type = "Circular"
      value = {}
    } else if (value._isWrappedObject) {
      options.seen.push(value)
      type = value.type
      const propertyList = value.constructor._DefinedPropertiesKey
      const json = {}
      Object.keys(propertyList).forEach(function customToJSON(k) {
        if (!propertyList[k].exportable) {
          return
        }
        if (typeof value[k] === 'undefined') {
          return
        }
        json[k] = value[k]
        if (json[k] && !json[k]._isWrappedObject && json[k].toJSON) {
          json[k] = json[k].toJSON()
        }
      })
      value = prepareObject(json, options)
    } else {
      options.seen.push(value)
      value = prepareObject(util.toObject(value), options)
    }
  } else if (util.isNativeObject(value)) {
    type = util.getNativeClass(value)
    // special case for NSException
    if (type === "NSException") {
      primitive = "Error"
      var stack = ""
      var userInfo = value.userInfo && value.userInfo() ? value.userInfo() : {}
      if (userInfo.stack) {
        stack = String(userInfo.stack)
      }
      value = {
        message: String(value.reason()),
        name: String(value.name()),
        stack: stack,
        userInfo: prepareObject(util.toObject(userInfo), options)
      }
    } else if (value.class().mocha) {
      primitive = "Mocha"
      value = type
    } else {
      primitive = "Unknown"
      value = type
    }
  } else {
    type = "Unknown"
    primitive = "Unknown"
    value = type
  }

  return {
    value: value,
    type: type,
    primitive: primitive
  }
}

module.exports = prepareValue
module.exports.prepareObject = prepareObject
module.exports.prepareArray = prepareArray


/***/ }),

/***/ "./node_modules/@skpm/fs/index.js":
/*!****************************************!*\
  !*** ./node_modules/@skpm/fs/index.js ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// TODO: async. Should probably be done with NSFileHandle and some notifications
// TODO: file descriptor. Needs to be done with NSFileHandle
var Buffer = __webpack_require__(/*! buffer */ "buffer").Buffer;
var utils = __webpack_require__(/*! ./utils */ "./node_modules/@skpm/fs/utils.js");
var parseStat = utils.parseStat;
var fsError = utils.fsError;
var fsErrorForPath = utils.fsErrorForPath;
var encodingFromOptions = utils.encodingFromOptions;
var NOT_IMPLEMENTED = utils.NOT_IMPLEMENTED;

module.exports.constants = {
  F_OK: 0,
  R_OK: 4,
  W_OK: 2,
  X_OK: 1,
};

module.exports.access = NOT_IMPLEMENTED("access");

module.exports.accessSync = function (path, mode) {
  mode = mode | 0;
  var fileManager = NSFileManager.defaultManager();

  switch (mode) {
    case 0:
      canAccess = module.exports.existsSync(path);
      break;
    case 1:
      canAccess = Boolean(Number(fileManager.isExecutableFileAtPath(path)));
      break;
    case 2:
      canAccess = Boolean(Number(fileManager.isWritableFileAtPath(path)));
      break;
    case 3:
      canAccess =
        Boolean(Number(fileManager.isExecutableFileAtPath(path))) &&
        Boolean(Number(fileManager.isWritableFileAtPath(path)));
      break;
    case 4:
      canAccess = Boolean(Number(fileManager.isReadableFileAtPath(path)));
      break;
    case 5:
      canAccess =
        Boolean(Number(fileManager.isReadableFileAtPath(path))) &&
        Boolean(Number(fileManager.isExecutableFileAtPath(path)));
      break;
    case 6:
      canAccess =
        Boolean(Number(fileManager.isReadableFileAtPath(path))) &&
        Boolean(Number(fileManager.isWritableFileAtPath(path)));
      break;
    case 7:
      canAccess =
        Boolean(Number(fileManager.isReadableFileAtPath(path))) &&
        Boolean(Number(fileManager.isWritableFileAtPath(path))) &&
        Boolean(Number(fileManager.isExecutableFileAtPath(path)));
      break;
  }

  if (!canAccess) {
    throw new Error("Can't access " + String(path));
  }
};

module.exports.appendFile = NOT_IMPLEMENTED("appendFile");

module.exports.appendFileSync = function (file, data, options) {
  if (!module.exports.existsSync(file)) {
    return module.exports.writeFileSync(file, data, options);
  }

  var handle = NSFileHandle.fileHandleForWritingAtPath(file);
  handle.seekToEndOfFile();

  var encoding = encodingFromOptions(options, "utf8");

  var nsdata = Buffer.from(
    data,
    encoding === "NSData" || encoding === "buffer" ? undefined : encoding
  ).toNSData();

  handle.writeData(nsdata);
};

module.exports.chmod = NOT_IMPLEMENTED("chmod");

module.exports.chmodSync = function (path, mode) {
  var err = MOPointer.alloc().init();
  var fileManager = NSFileManager.defaultManager();
  fileManager.setAttributes_ofItemAtPath_error(
    {
      NSFilePosixPermissions: mode,
    },
    path,
    err
  );

  if (err.value() !== null) {
    throw fsErrorForPath(path, undefined, err.value());
  }
};

module.exports.chown = NOT_IMPLEMENTED("chown");
module.exports.chownSync = NOT_IMPLEMENTED("chownSync");

module.exports.close = NOT_IMPLEMENTED("close");
module.exports.closeSync = NOT_IMPLEMENTED("closeSync");

module.exports.copyFile = NOT_IMPLEMENTED("copyFile");

module.exports.copyFileSync = function (path, dest, flags) {
  var err = MOPointer.alloc().init();
  var fileManager = NSFileManager.defaultManager();
  fileManager.copyItemAtPath_toPath_error(path, dest, err);

  if (err.value() !== null) {
    throw fsErrorForPath(path, false, err.value());
  }
};

module.exports.createReadStream = NOT_IMPLEMENTED("createReadStream");
module.exports.createWriteStream = NOT_IMPLEMENTED("createWriteStream");

module.exports.exists = NOT_IMPLEMENTED("exists");

module.exports.existsSync = function (path) {
  var fileManager = NSFileManager.defaultManager();
  return Boolean(Number(fileManager.fileExistsAtPath(path)));
};

module.exports.fchmod = NOT_IMPLEMENTED("fchmod");
module.exports.fchmodSync = NOT_IMPLEMENTED("fchmodSync");
module.exports.fchown = NOT_IMPLEMENTED("fchown");
module.exports.fchownSync = NOT_IMPLEMENTED("fchownSync");
module.exports.fdatasync = NOT_IMPLEMENTED("fdatasync");
module.exports.fdatasyncSync = NOT_IMPLEMENTED("fdatasyncSync");
module.exports.fstat = NOT_IMPLEMENTED("fstat");
module.exports.fstatSync = NOT_IMPLEMENTED("fstatSync");
module.exports.fsync = NOT_IMPLEMENTED("fsync");
module.exports.fsyncSync = NOT_IMPLEMENTED("fsyncSync");
module.exports.ftruncate = NOT_IMPLEMENTED("ftruncate");
module.exports.ftruncateSync = NOT_IMPLEMENTED("ftruncateSync");
module.exports.futimes = NOT_IMPLEMENTED("futimes");
module.exports.futimesSync = NOT_IMPLEMENTED("futimesSync");

module.exports.lchmod = NOT_IMPLEMENTED("lchmod");
module.exports.lchmodSync = NOT_IMPLEMENTED("lchmodSync");
module.exports.lchown = NOT_IMPLEMENTED("lchown");
module.exports.lchownSync = NOT_IMPLEMENTED("lchownSync");

module.exports.link = NOT_IMPLEMENTED("link");

module.exports.linkSync = function (existingPath, newPath) {
  var err = MOPointer.alloc().init();
  var fileManager = NSFileManager.defaultManager();
  fileManager.linkItemAtPath_toPath_error(existingPath, newPath, err);

  if (err.value() !== null) {
    throw fsErrorForPath(existingPath, undefined, err.value());
  }
};

module.exports.lstat = NOT_IMPLEMENTED("lstat");

module.exports.lstatSync = function (path) {
  var err = MOPointer.alloc().init();
  var fileManager = NSFileManager.defaultManager();
  var result = fileManager.attributesOfItemAtPath_error(path, err);

  if (err.value() !== null) {
    throw fsErrorForPath(path, undefined, err.value());
  }

  return parseStat(result);
};

module.exports.mkdir = NOT_IMPLEMENTED("mkdir");

module.exports.mkdirSync = function (path, options) {
  var mode = 0o777;
  var recursive = false;
  if (options && options.mode) {
    mode = options.mode;
  }
  if (options && options.recursive) {
    recursive = options.recursive;
  }
  if (typeof options === "number") {
    mode = options;
  }
  var err = MOPointer.alloc().init();
  var fileManager = NSFileManager.defaultManager();
  fileManager.createDirectoryAtPath_withIntermediateDirectories_attributes_error(
    path,
    recursive,
    {
      NSFilePosixPermissions: mode,
    },
    err
  );

  if (err.value() !== null) {
    throw new Error(err.value());
  }
};

module.exports.mkdtemp = NOT_IMPLEMENTED("mkdtemp");

module.exports.mkdtempSync = function (path) {
  function makeid() {
    var text = "";
    var possible =
      "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

    for (var i = 0; i < 6; i++)
      text += possible.charAt(Math.floor(Math.random() * possible.length));

    return text;
  }
  var tempPath = path + makeid();
  module.exports.mkdirSync(tempPath);
  return tempPath;
};

module.exports.open = NOT_IMPLEMENTED("open");
module.exports.openSync = NOT_IMPLEMENTED("openSync");

module.exports.read = NOT_IMPLEMENTED("read");

module.exports.readdir = NOT_IMPLEMENTED("readdir");

module.exports.readdirSync = function (path, options) {
  var encoding = encodingFromOptions(options, "utf8");
  var fileManager = NSFileManager.defaultManager();
  var paths = fileManager.subpathsAtPath(path);
  var arr = [];
  for (var i = 0; i < paths.length; i++) {
    var pathName = paths[i];
    arr.push(encoding === "buffer" ? Buffer.from(pathName) : String(pathName));
  }
  return arr;
};

module.exports.readFile = NOT_IMPLEMENTED("readFile");

module.exports.readFileSync = function (path, options) {
  var encoding = encodingFromOptions(options, "buffer");
  var fileManager = NSFileManager.defaultManager();
  var data = fileManager.contentsAtPath(path);
  if (!data) {
    throw fsErrorForPath(path, false);
  }

  var buffer = Buffer.from(data);

  if (encoding === "buffer") {
    return buffer;
  } else if (encoding === "NSData") {
    return buffer.toNSData();
  } else {
    return buffer.toString(encoding);
  }
};

module.exports.readlink = NOT_IMPLEMENTED("readlink");

module.exports.readlinkSync = function (path) {
  var err = MOPointer.alloc().init();
  var fileManager = NSFileManager.defaultManager();
  var result = fileManager.destinationOfSymbolicLinkAtPath_error(path, err);

  if (err.value() !== null) {
    throw fsErrorForPath(path, undefined, err.value());
  }

  return String(result);
};

module.exports.readSync = NOT_IMPLEMENTED("readSync");

module.exports.realpath = NOT_IMPLEMENTED("realpath");
module.exports.realpath.native = NOT_IMPLEMENTED("realpath.native");

module.exports.realpathSync = function (path) {
  return String(
    NSString.stringWithString(path).stringByResolvingSymlinksInPath()
  );
};

module.exports.realpathSync.native = NOT_IMPLEMENTED("realpathSync.native");

module.exports.rename = NOT_IMPLEMENTED("rename");

module.exports.renameSync = function (oldPath, newPath) {
  var err = MOPointer.alloc().init();
  var fileManager = NSFileManager.defaultManager();
  fileManager.moveItemAtPath_toPath_error(oldPath, newPath, err);

  var error = err.value();

  if (error !== null) {
    // if there is already a file, we need to overwrite it
    if (
      String(error.domain()) === "NSCocoaErrorDomain" &&
      Number(error.code()) === 516
    ) {
      var err2 = MOPointer.alloc().init();
      fileManager.replaceItemAtURL_withItemAtURL_backupItemName_options_resultingItemURL_error(
        NSURL.fileURLWithPath(newPath),
        NSURL.fileURLWithPath(oldPath),
        null,
        NSFileManagerItemReplacementUsingNewMetadataOnly,
        null,
        err2
      );
      if (err2.value() !== null) {
        throw fsErrorForPath(oldPath, undefined, err2.value());
      }
    } else {
      throw fsErrorForPath(oldPath, undefined, error);
    }
  }
};

module.exports.rmdir = NOT_IMPLEMENTED("rmdir");

module.exports.rmdirSync = function (path) {
  var err = MOPointer.alloc().init();
  var fileManager = NSFileManager.defaultManager();
  var isDirectory = module.exports.lstatSync(path).isDirectory();
  if (!isDirectory) {
    throw fsError("ENOTDIR", {
      path: path,
      syscall: "rmdir",
    });
  }
  fileManager.removeItemAtPath_error(path, err);

  if (err.value() !== null) {
    throw fsErrorForPath(path, true, err.value(), "rmdir");
  }
};

module.exports.stat = NOT_IMPLEMENTED("stat");

// the only difference with lstat is that we resolve symlinks
//
// > lstat() is identical to stat(), except that if pathname is a symbolic
// > link, then it returns information about the link itself, not the file
// > that it refers to.
// http://man7.org/linux/man-pages/man2/lstat.2.html
module.exports.statSync = function (path) {
  return module.exports.lstatSync(module.exports.realpathSync(path));
};

module.exports.symlink = NOT_IMPLEMENTED("symlink");

module.exports.symlinkSync = function (target, path) {
  var err = MOPointer.alloc().init();
  var fileManager = NSFileManager.defaultManager();
  var result = fileManager.createSymbolicLinkAtPath_withDestinationPath_error(
    path,
    target,
    err
  );

  if (err.value() !== null) {
    throw new Error(err.value());
  }
};

module.exports.truncate = NOT_IMPLEMENTED("truncate");

module.exports.truncateSync = function (path, len) {
  var hFile = NSFileHandle.fileHandleForUpdatingAtPath(sFilePath);
  hFile.truncateFileAtOffset(len || 0);
  hFile.closeFile();
};

module.exports.unlink = NOT_IMPLEMENTED("unlink");

module.exports.unlinkSync = function (path) {
  var err = MOPointer.alloc().init();
  var fileManager = NSFileManager.defaultManager();
  var isDirectory = module.exports.lstatSync(path).isDirectory();
  if (isDirectory) {
    throw fsError("EPERM", {
      path: path,
      syscall: "unlink",
    });
  }
  var result = fileManager.removeItemAtPath_error(path, err);

  if (err.value() !== null) {
    throw fsErrorForPath(path, false, err.value());
  }
};

module.exports.unwatchFile = NOT_IMPLEMENTED("unwatchFile");

module.exports.utimes = NOT_IMPLEMENTED("utimes");

module.exports.utimesSync = function (path, aTime, mTime) {
  var err = MOPointer.alloc().init();
  var fileManager = NSFileManager.defaultManager();
  var result = fileManager.setAttributes_ofItemAtPath_error(
    {
      NSFileModificationDate: aTime,
    },
    path,
    err
  );

  if (err.value() !== null) {
    throw fsErrorForPath(path, undefined, err.value());
  }
};

module.exports.watch = NOT_IMPLEMENTED("watch");
module.exports.watchFile = NOT_IMPLEMENTED("watchFile");

module.exports.write = NOT_IMPLEMENTED("write");

module.exports.writeFile = NOT_IMPLEMENTED("writeFile");

module.exports.writeFileSync = function (path, data, options) {
  var encoding = encodingFromOptions(options, "utf8");

  var nsdata = Buffer.from(
    data,
    encoding === "NSData" || encoding === "buffer" ? undefined : encoding
  ).toNSData();

  nsdata.writeToFile_atomically(path, true);
};

module.exports.writeSync = NOT_IMPLEMENTED("writeSync");


/***/ }),

/***/ "./node_modules/@skpm/fs/utils.js":
/*!****************************************!*\
  !*** ./node_modules/@skpm/fs/utils.js ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports.parseStat = function parseStat(result) {
  return {
    dev: String(result.NSFileDeviceIdentifier),
    // ino: 48064969, The file system specific "Inode" number for the file.
    mode: result.NSFileType | result.NSFilePosixPermissions,
    nlink: Number(result.NSFileReferenceCount),
    uid: String(result.NSFileOwnerAccountID),
    gid: String(result.NSFileGroupOwnerAccountID),
    // rdev: 0, A numeric device identifier if the file is considered "special".
    size: Number(result.NSFileSize),
    // blksize: 4096, The file system block size for i/o operations.
    // blocks: 8, The number of blocks allocated for this file.
    atimeMs:
      Number(result.NSFileModificationDate.timeIntervalSince1970()) * 1000,
    mtimeMs:
      Number(result.NSFileModificationDate.timeIntervalSince1970()) * 1000,
    ctimeMs:
      Number(result.NSFileModificationDate.timeIntervalSince1970()) * 1000,
    birthtimeMs:
      Number(result.NSFileCreationDate.timeIntervalSince1970()) * 1000,
    atime: new Date(
      Number(result.NSFileModificationDate.timeIntervalSince1970()) * 1000 + 0.5
    ), // the 0.5 comes from the node source. Not sure why it's added but in doubt...
    mtime: new Date(
      Number(result.NSFileModificationDate.timeIntervalSince1970()) * 1000 + 0.5
    ),
    ctime: new Date(
      Number(result.NSFileModificationDate.timeIntervalSince1970()) * 1000 + 0.5
    ),
    birthtime: new Date(
      Number(result.NSFileCreationDate.timeIntervalSince1970()) * 1000 + 0.5
    ),
    isBlockDevice: function () {
      return result.NSFileType === NSFileTypeBlockSpecial;
    },
    isCharacterDevice: function () {
      return result.NSFileType === NSFileTypeCharacterSpecial;
    },
    isDirectory: function () {
      return result.NSFileType === NSFileTypeDirectory;
    },
    isFIFO: function () {
      return false;
    },
    isFile: function () {
      return result.NSFileType === NSFileTypeRegular;
    },
    isSocket: function () {
      return result.NSFileType === NSFileTypeSocket;
    },
    isSymbolicLink: function () {
      return result.NSFileType === NSFileTypeSymbolicLink;
    },
  };
};

var ERRORS = {
  EPERM: {
    message: "operation not permitted",
    errno: -1,
  },
  ENOENT: {
    message: "no such file or directory",
    errno: -2,
  },
  EACCES: {
    message: "permission denied",
    errno: -13,
  },
  ENOTDIR: {
    message: "not a directory",
    errno: -20,
  },
  EISDIR: {
    message: "illegal operation on a directory",
    errno: -21,
  },
};

function fsError(code, options) {
  var error = new Error(
    code +
      ": " +
      ERRORS[code].message +
      ", " +
      (options.syscall || "") +
      (options.path ? " '" + options.path + "'" : "")
  );

  Object.keys(options).forEach(function (k) {
    error[k] = options[k];
  });

  error.code = code;
  error.errno = ERRORS[code].errno;

  return error;
}

module.exports.fsError = fsError;

module.exports.fsErrorForPath = function fsErrorForPath(
  path,
  shouldBeDir,
  err,
  syscall
) {
  var fileManager = NSFileManager.defaultManager();
  var doesExist = fileManager.fileExistsAtPath(path);
  if (!doesExist) {
    return fsError("ENOENT", {
      path: path,
      syscall: syscall || "open",
    });
  }
  var isReadable = fileManager.isReadableFileAtPath(path);
  if (!isReadable) {
    return fsError("EACCES", {
      path: path,
      syscall: syscall || "open",
    });
  }
  if (typeof shouldBeDir !== "undefined") {
    var isDirectory = __webpack_require__(/*! ./index */ "./node_modules/@skpm/fs/index.js").lstatSync(path).isDirectory();
    if (isDirectory && !shouldBeDir) {
      return fsError("EISDIR", {
        path: path,
        syscall: syscall || "read",
      });
    } else if (!isDirectory && shouldBeDir) {
      return fsError("ENOTDIR", {
        path: path,
        syscall: syscall || "read",
      });
    }
  }
  return new Error(err || "Unknown error while manipulating " + path);
};

module.exports.encodingFromOptions = function encodingFromOptions(
  options,
  defaultValue
) {
  return options && options.encoding
    ? String(options.encoding)
    : options
    ? String(options)
    : defaultValue;
};

module.exports.NOT_IMPLEMENTED = function NOT_IMPLEMENTED(name) {
  return function () {
    throw new Error(
      "fs." +
        name +
        " is not implemented yet. If you feel like implementing it, any contribution will be gladly accepted on https://github.com/skpm/fs"
    );
  };
};


/***/ }),

/***/ "./node_modules/@skpm/nib-loader/lib/nib-class.js":
/*!********************************************************!*\
  !*** ./node_modules/@skpm/nib-loader/lib/nib-class.js ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/* eslint-disable no-var, prefer-template, vars-on-top, no-underscore-dangle, prefer-arrow-callback, no-param-reassign */
/* globals NSUUID, MOClassDescription, NSBundle, NSObject, __command, MOPointer */
var ObjClass = __webpack_require__(/*! cocoascript-class */ "./node_modules/cocoascript-class/lib/index.js").default;

function walkViewTree(rootView, fn) {
  function _visit(view) {
    fn(view);

    var subviews = view.subviews();
    for (var i = 0; i < subviews.count(); i++) {
      _visit(subviews.objectAtIndex(i));
    }
  }

  _visit(rootView);
}

var CONTAINS_EXT = /\.nib$/;

function NibClass(nibName, delegate, bundleURL) {
  if (CONTAINS_EXT.test(nibName)) {
    nibName = nibName.replace(CONTAINS_EXT, '');
  }
  var bundle = NSBundle.bundleWithURL(bundleURL || __command.pluginBundle().url());

  var nibOwner = (new ObjClass(delegate || {})).new();
  var root;

  var result = {
    getOwner() {
      return nibOwner;
    },
    getRoot() {
      return root;
    },
  };

  var topLevelObjectsPointer = MOPointer.alloc().initWithValue(null);

  var didManagedToLoad = bundle.loadNibNamed_owner_topLevelObjects(
    nibName,
    nibOwner,
    topLevelObjectsPointer,
  );

  if (!didManagedToLoad) {
    throw new Error('Error loading nib file ' + nibName + '.nib');
  }

  var topLevelObjects = topLevelObjectsPointer.value();
  for (var i = 0; i < topLevelObjects.count(); i++) {
    var obj = topLevelObjects.objectAtIndex(i);
    if (/View$/.test(String(obj.className()))) {
      root = obj;
      break;
    }
  }

  // find the views that have an identifier for easy access
  // we don't take the ones starting with _ since it's probably internal identifiers (used by cocoa)
  walkViewTree(root, function visit(view) {
    var id = String(view.identifier());
    if (id && id.indexOf('_') !== 0) {
      result[id] = view;
    }
  });

  return result;
}

module.exports = NibClass;


/***/ }),

/***/ "./node_modules/@skpm/promise/index.js":
/*!*********************************************!*\
  !*** ./node_modules/@skpm/promise/index.js ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/* from https://github.com/taylorhakes/promise-polyfill */

function promiseFinally(callback) {
  var constructor = this.constructor;
  return this.then(
    function(value) {
      return constructor.resolve(callback()).then(function() {
        return value;
      });
    },
    function(reason) {
      return constructor.resolve(callback()).then(function() {
        return constructor.reject(reason);
      });
    }
  );
}

function noop() {}

/**
 * @constructor
 * @param {Function} fn
 */
function Promise(fn) {
  if (!(this instanceof Promise))
    throw new TypeError("Promises must be constructed via new");
  if (typeof fn !== "function") throw new TypeError("not a function");
  /** @type {!number} */
  this._state = 0;
  /** @type {!boolean} */
  this._handled = false;
  /** @type {Promise|undefined} */
  this._value = undefined;
  /** @type {!Array<!Function>} */
  this._deferreds = [];

  doResolve(fn, this);
}

function handle(self, deferred) {
  while (self._state === 3) {
    self = self._value;
  }
  if (self._state === 0) {
    self._deferreds.push(deferred);
    return;
  }
  self._handled = true;
  Promise._immediateFn(function() {
    var cb = self._state === 1 ? deferred.onFulfilled : deferred.onRejected;
    if (cb === null) {
      (self._state === 1 ? resolve : reject)(deferred.promise, self._value);
      return;
    }
    var ret;
    try {
      ret = cb(self._value);
    } catch (e) {
      reject(deferred.promise, e);
      return;
    }
    resolve(deferred.promise, ret);
  });
}

function resolve(self, newValue) {
  try {
    // Promise Resolution Procedure: https://github.com/promises-aplus/promises-spec#the-promise-resolution-procedure
    if (newValue === self)
      throw new TypeError("A promise cannot be resolved with itself.");
    if (
      newValue &&
      (typeof newValue === "object" || typeof newValue === "function")
    ) {
      var then = newValue.then;
      if (newValue instanceof Promise) {
        self._state = 3;
        self._value = newValue;
        finale(self);
        return;
      } else if (typeof then === "function") {
        doResolve(then.bind(newValue), self);
        return;
      }
    }
    self._state = 1;
    self._value = newValue;
    finale(self);
  } catch (e) {
    reject(self, e);
  }
}

function reject(self, newValue) {
  self._state = 2;
  self._value = newValue;
  finale(self);
}

function finale(self) {
  if (self._state === 2 && self._deferreds.length === 0) {
    Promise._immediateFn(function() {
      if (!self._handled) {
        Promise._unhandledRejectionFn(self._value, self);
      }
    });
  }

  for (var i = 0, len = self._deferreds.length; i < len; i++) {
    handle(self, self._deferreds[i]);
  }
  self._deferreds = null;
}

/**
 * @constructor
 */
function Handler(onFulfilled, onRejected, promise) {
  this.onFulfilled = typeof onFulfilled === "function" ? onFulfilled : null;
  this.onRejected = typeof onRejected === "function" ? onRejected : null;
  this.promise = promise;
}

/**
 * Take a potentially misbehaving resolver function and make sure
 * onFulfilled and onRejected are only called once.
 *
 * Makes no guarantees about asynchrony.
 */
function doResolve(fn, self) {
  var done = false;
  try {
    fn(
      function(value) {
        if (done) {
          Promise._multipleResolvesFn("resolve", self, value);
          return;
        }
        done = true;
        resolve(self, value);
      },
      function(reason) {
        if (done) {
          Promise._multipleResolvesFn("reject", self, reason);
          return;
        }
        done = true;
        reject(self, reason);
      }
    );
  } catch (ex) {
    if (done) {
      Promise._multipleResolvesFn("reject", self, ex);
      return;
    }
    done = true;
    reject(self, ex);
  }
}

Promise.prototype["catch"] = function(onRejected) {
  return this.then(null, onRejected);
};

Promise.prototype.then = function(onFulfilled, onRejected) {
  // @ts-ignore
  var prom = new this.constructor(noop);

  handle(this, new Handler(onFulfilled, onRejected, prom));
  return prom;
};

Promise.prototype["finally"] = promiseFinally;

Promise.all = function(arr) {
  return new Promise(function(resolve, reject) {
    if (!Array.isArray(arr)) {
      return reject(new TypeError("Promise.all accepts an array"));
    }

    var args = Array.prototype.slice.call(arr);
    if (args.length === 0) return resolve([]);
    var remaining = args.length;

    function res(i, val) {
      try {
        if (val && (typeof val === "object" || typeof val === "function")) {
          var then = val.then;
          if (typeof then === "function") {
            then.call(
              val,
              function(val) {
                res(i, val);
              },
              reject
            );
            return;
          }
        }
        args[i] = val;
        if (--remaining === 0) {
          resolve(args);
        }
      } catch (ex) {
        reject(ex);
      }
    }

    for (var i = 0; i < args.length; i++) {
      res(i, args[i]);
    }
  });
};

Promise.resolve = function(value) {
  if (value && typeof value === "object" && value.constructor === Promise) {
    return value;
  }

  return new Promise(function(resolve) {
    resolve(value);
  });
};

Promise.reject = function(value) {
  return new Promise(function(resolve, reject) {
    reject(value);
  });
};

Promise.race = function(arr) {
  return new Promise(function(resolve, reject) {
    if (!Array.isArray(arr)) {
      return reject(new TypeError("Promise.race accepts an array"));
    }

    for (var i = 0, len = arr.length; i < len; i++) {
      Promise.resolve(arr[i]).then(resolve, reject);
    }
  });
};

// Use polyfill for setImmediate for performance gains
Promise._immediateFn = setImmediate;

Promise._unhandledRejectionFn = function _unhandledRejectionFn(err, promise) {
  if (
    typeof process !== "undefined" &&
    process.listenerCount &&
    (process.listenerCount("unhandledRejection") ||
      process.listenerCount("uncaughtException"))
  ) {
    process.emit("unhandledRejection", err, promise);
    process.emit("uncaughtException", err, "unhandledRejection");
  } else if (typeof console !== "undefined" && console) {
    console.warn("Possible Unhandled Promise Rejection:", err);
  }
};

Promise._multipleResolvesFn = function _multipleResolvesFn(
  type,
  promise,
  value
) {
  if (typeof process !== "undefined" && process.emit) {
    process.emit("multipleResolves", type, promise, value);
  }
};

module.exports = Promise;


/***/ }),

/***/ "./node_modules/cocoascript-class/lib/index.js":
/*!*****************************************************!*\
  !*** ./node_modules/cocoascript-class/lib/index.js ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.SuperCall = undefined;
exports.default = ObjCClass;

var _runtime = __webpack_require__(/*! ./runtime.js */ "./node_modules/cocoascript-class/lib/runtime.js");

exports.SuperCall = _runtime.SuperCall;

// super when returnType is id and args are void
// id objc_msgSendSuper(struct objc_super *super, SEL op, void)

const SuperInit = (0, _runtime.SuperCall)(NSStringFromSelector("init"), [], { type: "@" });

// Returns a real ObjC class. No need to use new.
function ObjCClass(defn) {
  const superclass = defn.superclass || NSObject;
  const className = (defn.className || defn.classname || "ObjCClass") + NSUUID.UUID().UUIDString();
  const reserved = new Set(['className', 'classname', 'superclass']);
  var cls = MOClassDescription.allocateDescriptionForClassWithName_superclass_(className, superclass);
  // Add each handler to the class description
  const ivars = [];
  for (var key in defn) {
    const v = defn[key];
    if (typeof v == 'function' && key !== 'init') {
      var selector = NSSelectorFromString(key);
      cls.addInstanceMethodWithSelector_function_(selector, v);
    } else if (!reserved.has(key)) {
      ivars.push(key);
      cls.addInstanceVariableWithName_typeEncoding(key, "@");
    }
  }

  cls.addInstanceMethodWithSelector_function_(NSSelectorFromString('init'), function () {
    const self = SuperInit.call(this);
    ivars.map(name => {
      Object.defineProperty(self, name, {
        get() {
          return getIvar(self, name);
        },
        set(v) {
          (0, _runtime.object_setInstanceVariable)(self, name, v);
        }
      });
      self[name] = defn[name];
    });
    // If there is a passsed-in init funciton, call it now.
    if (typeof defn.init == 'function') defn.init.call(this);
    return self;
  });

  return cls.registerClass();
};

function getIvar(obj, name) {
  const retPtr = MOPointer.new();
  (0, _runtime.object_getInstanceVariable)(obj, name, retPtr);
  return retPtr.value().retain().autorelease();
}

/***/ }),

/***/ "./node_modules/cocoascript-class/lib/runtime.js":
/*!*******************************************************!*\
  !*** ./node_modules/cocoascript-class/lib/runtime.js ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.SuperCall = SuperCall;
exports.CFunc = CFunc;
const objc_super_typeEncoding = '{objc_super="receiver"@"super_class"#}';

// You can store this to call your function. this must be bound to the current instance.
function SuperCall(selector, argTypes, returnType) {
  const func = CFunc("objc_msgSendSuper", [{ type: '^' + objc_super_typeEncoding }, { type: ":" }, ...argTypes], returnType);
  return function (...args) {
    const struct = make_objc_super(this, this.superclass());
    const structPtr = MOPointer.alloc().initWithValue_(struct);
    return func(structPtr, selector, ...args);
  };
}

// Recursively create a MOStruct
function makeStruct(def) {
  if (typeof def !== 'object' || Object.keys(def).length == 0) {
    return def;
  }
  const name = Object.keys(def)[0];
  const values = def[name];

  const structure = MOStruct.structureWithName_memberNames_runtime(name, Object.keys(values), Mocha.sharedRuntime());

  Object.keys(values).map(member => {
    structure[member] = makeStruct(values[member]);
  });

  return structure;
}

function make_objc_super(self, cls) {
  return makeStruct({
    objc_super: {
      receiver: self,
      super_class: cls
    }
  });
}

// Due to particularities of the JS bridge, we can't call into MOBridgeSupport objects directly
// But, we can ask key value coding to do the dirty work for us ;)
function setKeys(o, d) {
  const funcDict = NSMutableDictionary.dictionary();
  funcDict.o = o;
  Object.keys(d).map(k => funcDict.setValue_forKeyPath(d[k], "o." + k));
}

// Use any C function, not just ones with BridgeSupport
function CFunc(name, args, retVal) {
  function makeArgument(a) {
    if (!a) return null;
    const arg = MOBridgeSupportArgument.alloc().init();
    setKeys(arg, {
      type64: a.type
    });
    return arg;
  }
  const func = MOBridgeSupportFunction.alloc().init();
  setKeys(func, {
    name: name,
    arguments: args.map(makeArgument),
    returnValue: makeArgument(retVal)
  });
  return func;
}

/*
@encode(char*) = "*"
@encode(id) = "@"
@encode(Class) = "#"
@encode(void*) = "^v"
@encode(CGRect) = "{CGRect={CGPoint=dd}{CGSize=dd}}"
@encode(SEL) = ":"
*/

function addStructToBridgeSupport(key, structDef) {
  // OK, so this is probably the nastiest hack in this file.
  // We go modify MOBridgeSupportController behind its back and use kvc to add our own definition
  // There isn't another API for this though. So the only other way would be to make a real bridgesupport file.
  const symbols = MOBridgeSupportController.sharedController().valueForKey('symbols');
  if (!symbols) throw Error("Something has changed within bridge support so we can't add our definitions");
  // If someone already added this definition, don't re-register it.
  if (symbols[key] !== null) return;
  const def = MOBridgeSupportStruct.alloc().init();
  setKeys(def, {
    name: key,
    type: structDef.type
  });
  symbols[key] = def;
};

// This assumes the ivar is an object type. Return value is pretty useless.
const object_getInstanceVariable = exports.object_getInstanceVariable = CFunc("object_getInstanceVariable", [{ type: "@" }, { type: '*' }, { type: "^@" }], { type: "^{objc_ivar=}" });
// Again, ivar is of object type
const object_setInstanceVariable = exports.object_setInstanceVariable = CFunc("object_setInstanceVariable", [{ type: "@" }, { type: '*' }, { type: "@" }], { type: "^{objc_ivar=}" });

// We need Mocha to understand what an objc_super is so we can use it as a function argument
addStructToBridgeSupport('objc_super', { type: objc_super_typeEncoding });

/***/ }),

/***/ "./node_modules/regenerator-runtime/runtime.js":
/*!*****************************************************!*\
  !*** ./node_modules/regenerator-runtime/runtime.js ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(Promise) {/**
 * Copyright (c) 2014-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

var runtime = (function (exports) {
  "use strict";

  var Op = Object.prototype;
  var hasOwn = Op.hasOwnProperty;
  var undefined; // More compressible than void 0.
  var $Symbol = typeof Symbol === "function" ? Symbol : {};
  var iteratorSymbol = $Symbol.iterator || "@@iterator";
  var asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator";
  var toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag";

  function define(obj, key, value) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
    return obj[key];
  }
  try {
    // IE 8 has a broken Object.defineProperty that only works on DOM objects.
    define({}, "");
  } catch (err) {
    define = function(obj, key, value) {
      return obj[key] = value;
    };
  }

  function wrap(innerFn, outerFn, self, tryLocsList) {
    // If outerFn provided and outerFn.prototype is a Generator, then outerFn.prototype instanceof Generator.
    var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator;
    var generator = Object.create(protoGenerator.prototype);
    var context = new Context(tryLocsList || []);

    // The ._invoke method unifies the implementations of the .next,
    // .throw, and .return methods.
    generator._invoke = makeInvokeMethod(innerFn, self, context);

    return generator;
  }
  exports.wrap = wrap;

  // Try/catch helper to minimize deoptimizations. Returns a completion
  // record like context.tryEntries[i].completion. This interface could
  // have been (and was previously) designed to take a closure to be
  // invoked without arguments, but in all the cases we care about we
  // already have an existing method we want to call, so there's no need
  // to create a new function object. We can even get away with assuming
  // the method takes exactly one argument, since that happens to be true
  // in every case, so we don't have to touch the arguments object. The
  // only additional allocation required is the completion record, which
  // has a stable shape and so hopefully should be cheap to allocate.
  function tryCatch(fn, obj, arg) {
    try {
      return { type: "normal", arg: fn.call(obj, arg) };
    } catch (err) {
      return { type: "throw", arg: err };
    }
  }

  var GenStateSuspendedStart = "suspendedStart";
  var GenStateSuspendedYield = "suspendedYield";
  var GenStateExecuting = "executing";
  var GenStateCompleted = "completed";

  // Returning this object from the innerFn has the same effect as
  // breaking out of the dispatch switch statement.
  var ContinueSentinel = {};

  // Dummy constructor functions that we use as the .constructor and
  // .constructor.prototype properties for functions that return Generator
  // objects. For full spec compliance, you may wish to configure your
  // minifier not to mangle the names of these two functions.
  function Generator() {}
  function GeneratorFunction() {}
  function GeneratorFunctionPrototype() {}

  // This is a polyfill for %IteratorPrototype% for environments that
  // don't natively support it.
  var IteratorPrototype = {};
  IteratorPrototype[iteratorSymbol] = function () {
    return this;
  };

  var getProto = Object.getPrototypeOf;
  var NativeIteratorPrototype = getProto && getProto(getProto(values([])));
  if (NativeIteratorPrototype &&
      NativeIteratorPrototype !== Op &&
      hasOwn.call(NativeIteratorPrototype, iteratorSymbol)) {
    // This environment has a native %IteratorPrototype%; use it instead
    // of the polyfill.
    IteratorPrototype = NativeIteratorPrototype;
  }

  var Gp = GeneratorFunctionPrototype.prototype =
    Generator.prototype = Object.create(IteratorPrototype);
  GeneratorFunction.prototype = Gp.constructor = GeneratorFunctionPrototype;
  GeneratorFunctionPrototype.constructor = GeneratorFunction;
  GeneratorFunction.displayName = define(
    GeneratorFunctionPrototype,
    toStringTagSymbol,
    "GeneratorFunction"
  );

  // Helper for defining the .next, .throw, and .return methods of the
  // Iterator interface in terms of a single ._invoke method.
  function defineIteratorMethods(prototype) {
    ["next", "throw", "return"].forEach(function(method) {
      define(prototype, method, function(arg) {
        return this._invoke(method, arg);
      });
    });
  }

  exports.isGeneratorFunction = function(genFun) {
    var ctor = typeof genFun === "function" && genFun.constructor;
    return ctor
      ? ctor === GeneratorFunction ||
        // For the native GeneratorFunction constructor, the best we can
        // do is to check its .name property.
        (ctor.displayName || ctor.name) === "GeneratorFunction"
      : false;
  };

  exports.mark = function(genFun) {
    if (Object.setPrototypeOf) {
      Object.setPrototypeOf(genFun, GeneratorFunctionPrototype);
    } else {
      genFun.__proto__ = GeneratorFunctionPrototype;
      define(genFun, toStringTagSymbol, "GeneratorFunction");
    }
    genFun.prototype = Object.create(Gp);
    return genFun;
  };

  // Within the body of any async function, `await x` is transformed to
  // `yield regeneratorRuntime.awrap(x)`, so that the runtime can test
  // `hasOwn.call(value, "__await")` to determine if the yielded value is
  // meant to be awaited.
  exports.awrap = function(arg) {
    return { __await: arg };
  };

  function AsyncIterator(generator, PromiseImpl) {
    function invoke(method, arg, resolve, reject) {
      var record = tryCatch(generator[method], generator, arg);
      if (record.type === "throw") {
        reject(record.arg);
      } else {
        var result = record.arg;
        var value = result.value;
        if (value &&
            typeof value === "object" &&
            hasOwn.call(value, "__await")) {
          return PromiseImpl.resolve(value.__await).then(function(value) {
            invoke("next", value, resolve, reject);
          }, function(err) {
            invoke("throw", err, resolve, reject);
          });
        }

        return PromiseImpl.resolve(value).then(function(unwrapped) {
          // When a yielded Promise is resolved, its final value becomes
          // the .value of the Promise<{value,done}> result for the
          // current iteration.
          result.value = unwrapped;
          resolve(result);
        }, function(error) {
          // If a rejected Promise was yielded, throw the rejection back
          // into the async generator function so it can be handled there.
          return invoke("throw", error, resolve, reject);
        });
      }
    }

    var previousPromise;

    function enqueue(method, arg) {
      function callInvokeWithMethodAndArg() {
        return new PromiseImpl(function(resolve, reject) {
          invoke(method, arg, resolve, reject);
        });
      }

      return previousPromise =
        // If enqueue has been called before, then we want to wait until
        // all previous Promises have been resolved before calling invoke,
        // so that results are always delivered in the correct order. If
        // enqueue has not been called before, then it is important to
        // call invoke immediately, without waiting on a callback to fire,
        // so that the async generator function has the opportunity to do
        // any necessary setup in a predictable way. This predictability
        // is why the Promise constructor synchronously invokes its
        // executor callback, and why async functions synchronously
        // execute code before the first await. Since we implement simple
        // async functions in terms of async generators, it is especially
        // important to get this right, even though it requires care.
        previousPromise ? previousPromise.then(
          callInvokeWithMethodAndArg,
          // Avoid propagating failures to Promises returned by later
          // invocations of the iterator.
          callInvokeWithMethodAndArg
        ) : callInvokeWithMethodAndArg();
    }

    // Define the unified helper method that is used to implement .next,
    // .throw, and .return (see defineIteratorMethods).
    this._invoke = enqueue;
  }

  defineIteratorMethods(AsyncIterator.prototype);
  AsyncIterator.prototype[asyncIteratorSymbol] = function () {
    return this;
  };
  exports.AsyncIterator = AsyncIterator;

  // Note that simple async functions are implemented on top of
  // AsyncIterator objects; they just return a Promise for the value of
  // the final result produced by the iterator.
  exports.async = function(innerFn, outerFn, self, tryLocsList, PromiseImpl) {
    if (PromiseImpl === void 0) PromiseImpl = Promise;

    var iter = new AsyncIterator(
      wrap(innerFn, outerFn, self, tryLocsList),
      PromiseImpl
    );

    return exports.isGeneratorFunction(outerFn)
      ? iter // If outerFn is a generator, return the full iterator.
      : iter.next().then(function(result) {
          return result.done ? result.value : iter.next();
        });
  };

  function makeInvokeMethod(innerFn, self, context) {
    var state = GenStateSuspendedStart;

    return function invoke(method, arg) {
      if (state === GenStateExecuting) {
        throw new Error("Generator is already running");
      }

      if (state === GenStateCompleted) {
        if (method === "throw") {
          throw arg;
        }

        // Be forgiving, per 25.3.3.3.3 of the spec:
        // https://people.mozilla.org/~jorendorff/es6-draft.html#sec-generatorresume
        return doneResult();
      }

      context.method = method;
      context.arg = arg;

      while (true) {
        var delegate = context.delegate;
        if (delegate) {
          var delegateResult = maybeInvokeDelegate(delegate, context);
          if (delegateResult) {
            if (delegateResult === ContinueSentinel) continue;
            return delegateResult;
          }
        }

        if (context.method === "next") {
          // Setting context._sent for legacy support of Babel's
          // function.sent implementation.
          context.sent = context._sent = context.arg;

        } else if (context.method === "throw") {
          if (state === GenStateSuspendedStart) {
            state = GenStateCompleted;
            throw context.arg;
          }

          context.dispatchException(context.arg);

        } else if (context.method === "return") {
          context.abrupt("return", context.arg);
        }

        state = GenStateExecuting;

        var record = tryCatch(innerFn, self, context);
        if (record.type === "normal") {
          // If an exception is thrown from innerFn, we leave state ===
          // GenStateExecuting and loop back for another invocation.
          state = context.done
            ? GenStateCompleted
            : GenStateSuspendedYield;

          if (record.arg === ContinueSentinel) {
            continue;
          }

          return {
            value: record.arg,
            done: context.done
          };

        } else if (record.type === "throw") {
          state = GenStateCompleted;
          // Dispatch the exception by looping back around to the
          // context.dispatchException(context.arg) call above.
          context.method = "throw";
          context.arg = record.arg;
        }
      }
    };
  }

  // Call delegate.iterator[context.method](context.arg) and handle the
  // result, either by returning a { value, done } result from the
  // delegate iterator, or by modifying context.method and context.arg,
  // setting context.delegate to null, and returning the ContinueSentinel.
  function maybeInvokeDelegate(delegate, context) {
    var method = delegate.iterator[context.method];
    if (method === undefined) {
      // A .throw or .return when the delegate iterator has no .throw
      // method always terminates the yield* loop.
      context.delegate = null;

      if (context.method === "throw") {
        // Note: ["return"] must be used for ES3 parsing compatibility.
        if (delegate.iterator["return"]) {
          // If the delegate iterator has a return method, give it a
          // chance to clean up.
          context.method = "return";
          context.arg = undefined;
          maybeInvokeDelegate(delegate, context);

          if (context.method === "throw") {
            // If maybeInvokeDelegate(context) changed context.method from
            // "return" to "throw", let that override the TypeError below.
            return ContinueSentinel;
          }
        }

        context.method = "throw";
        context.arg = new TypeError(
          "The iterator does not provide a 'throw' method");
      }

      return ContinueSentinel;
    }

    var record = tryCatch(method, delegate.iterator, context.arg);

    if (record.type === "throw") {
      context.method = "throw";
      context.arg = record.arg;
      context.delegate = null;
      return ContinueSentinel;
    }

    var info = record.arg;

    if (! info) {
      context.method = "throw";
      context.arg = new TypeError("iterator result is not an object");
      context.delegate = null;
      return ContinueSentinel;
    }

    if (info.done) {
      // Assign the result of the finished delegate to the temporary
      // variable specified by delegate.resultName (see delegateYield).
      context[delegate.resultName] = info.value;

      // Resume execution at the desired location (see delegateYield).
      context.next = delegate.nextLoc;

      // If context.method was "throw" but the delegate handled the
      // exception, let the outer generator proceed normally. If
      // context.method was "next", forget context.arg since it has been
      // "consumed" by the delegate iterator. If context.method was
      // "return", allow the original .return call to continue in the
      // outer generator.
      if (context.method !== "return") {
        context.method = "next";
        context.arg = undefined;
      }

    } else {
      // Re-yield the result returned by the delegate method.
      return info;
    }

    // The delegate iterator is finished, so forget it and continue with
    // the outer generator.
    context.delegate = null;
    return ContinueSentinel;
  }

  // Define Generator.prototype.{next,throw,return} in terms of the
  // unified ._invoke helper method.
  defineIteratorMethods(Gp);

  define(Gp, toStringTagSymbol, "Generator");

  // A Generator should always return itself as the iterator object when the
  // @@iterator function is called on it. Some browsers' implementations of the
  // iterator prototype chain incorrectly implement this, causing the Generator
  // object to not be returned from this call. This ensures that doesn't happen.
  // See https://github.com/facebook/regenerator/issues/274 for more details.
  Gp[iteratorSymbol] = function() {
    return this;
  };

  Gp.toString = function() {
    return "[object Generator]";
  };

  function pushTryEntry(locs) {
    var entry = { tryLoc: locs[0] };

    if (1 in locs) {
      entry.catchLoc = locs[1];
    }

    if (2 in locs) {
      entry.finallyLoc = locs[2];
      entry.afterLoc = locs[3];
    }

    this.tryEntries.push(entry);
  }

  function resetTryEntry(entry) {
    var record = entry.completion || {};
    record.type = "normal";
    delete record.arg;
    entry.completion = record;
  }

  function Context(tryLocsList) {
    // The root entry object (effectively a try statement without a catch
    // or a finally block) gives us a place to store values thrown from
    // locations where there is no enclosing try statement.
    this.tryEntries = [{ tryLoc: "root" }];
    tryLocsList.forEach(pushTryEntry, this);
    this.reset(true);
  }

  exports.keys = function(object) {
    var keys = [];
    for (var key in object) {
      keys.push(key);
    }
    keys.reverse();

    // Rather than returning an object with a next method, we keep
    // things simple and return the next function itself.
    return function next() {
      while (keys.length) {
        var key = keys.pop();
        if (key in object) {
          next.value = key;
          next.done = false;
          return next;
        }
      }

      // To avoid creating an additional object, we just hang the .value
      // and .done properties off the next function object itself. This
      // also ensures that the minifier will not anonymize the function.
      next.done = true;
      return next;
    };
  };

  function values(iterable) {
    if (iterable) {
      var iteratorMethod = iterable[iteratorSymbol];
      if (iteratorMethod) {
        return iteratorMethod.call(iterable);
      }

      if (typeof iterable.next === "function") {
        return iterable;
      }

      if (!isNaN(iterable.length)) {
        var i = -1, next = function next() {
          while (++i < iterable.length) {
            if (hasOwn.call(iterable, i)) {
              next.value = iterable[i];
              next.done = false;
              return next;
            }
          }

          next.value = undefined;
          next.done = true;

          return next;
        };

        return next.next = next;
      }
    }

    // Return an iterator with no values.
    return { next: doneResult };
  }
  exports.values = values;

  function doneResult() {
    return { value: undefined, done: true };
  }

  Context.prototype = {
    constructor: Context,

    reset: function(skipTempReset) {
      this.prev = 0;
      this.next = 0;
      // Resetting context._sent for legacy support of Babel's
      // function.sent implementation.
      this.sent = this._sent = undefined;
      this.done = false;
      this.delegate = null;

      this.method = "next";
      this.arg = undefined;

      this.tryEntries.forEach(resetTryEntry);

      if (!skipTempReset) {
        for (var name in this) {
          // Not sure about the optimal order of these conditions:
          if (name.charAt(0) === "t" &&
              hasOwn.call(this, name) &&
              !isNaN(+name.slice(1))) {
            this[name] = undefined;
          }
        }
      }
    },

    stop: function() {
      this.done = true;

      var rootEntry = this.tryEntries[0];
      var rootRecord = rootEntry.completion;
      if (rootRecord.type === "throw") {
        throw rootRecord.arg;
      }

      return this.rval;
    },

    dispatchException: function(exception) {
      if (this.done) {
        throw exception;
      }

      var context = this;
      function handle(loc, caught) {
        record.type = "throw";
        record.arg = exception;
        context.next = loc;

        if (caught) {
          // If the dispatched exception was caught by a catch block,
          // then let that catch block handle the exception normally.
          context.method = "next";
          context.arg = undefined;
        }

        return !! caught;
      }

      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        var record = entry.completion;

        if (entry.tryLoc === "root") {
          // Exception thrown outside of any try block that could handle
          // it, so set the completion value of the entire function to
          // throw the exception.
          return handle("end");
        }

        if (entry.tryLoc <= this.prev) {
          var hasCatch = hasOwn.call(entry, "catchLoc");
          var hasFinally = hasOwn.call(entry, "finallyLoc");

          if (hasCatch && hasFinally) {
            if (this.prev < entry.catchLoc) {
              return handle(entry.catchLoc, true);
            } else if (this.prev < entry.finallyLoc) {
              return handle(entry.finallyLoc);
            }

          } else if (hasCatch) {
            if (this.prev < entry.catchLoc) {
              return handle(entry.catchLoc, true);
            }

          } else if (hasFinally) {
            if (this.prev < entry.finallyLoc) {
              return handle(entry.finallyLoc);
            }

          } else {
            throw new Error("try statement without catch or finally");
          }
        }
      }
    },

    abrupt: function(type, arg) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.tryLoc <= this.prev &&
            hasOwn.call(entry, "finallyLoc") &&
            this.prev < entry.finallyLoc) {
          var finallyEntry = entry;
          break;
        }
      }

      if (finallyEntry &&
          (type === "break" ||
           type === "continue") &&
          finallyEntry.tryLoc <= arg &&
          arg <= finallyEntry.finallyLoc) {
        // Ignore the finally entry if control is not jumping to a
        // location outside the try/catch block.
        finallyEntry = null;
      }

      var record = finallyEntry ? finallyEntry.completion : {};
      record.type = type;
      record.arg = arg;

      if (finallyEntry) {
        this.method = "next";
        this.next = finallyEntry.finallyLoc;
        return ContinueSentinel;
      }

      return this.complete(record);
    },

    complete: function(record, afterLoc) {
      if (record.type === "throw") {
        throw record.arg;
      }

      if (record.type === "break" ||
          record.type === "continue") {
        this.next = record.arg;
      } else if (record.type === "return") {
        this.rval = this.arg = record.arg;
        this.method = "return";
        this.next = "end";
      } else if (record.type === "normal" && afterLoc) {
        this.next = afterLoc;
      }

      return ContinueSentinel;
    },

    finish: function(finallyLoc) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.finallyLoc === finallyLoc) {
          this.complete(entry.completion, entry.afterLoc);
          resetTryEntry(entry);
          return ContinueSentinel;
        }
      }
    },

    "catch": function(tryLoc) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.tryLoc === tryLoc) {
          var record = entry.completion;
          if (record.type === "throw") {
            var thrown = record.arg;
            resetTryEntry(entry);
          }
          return thrown;
        }
      }

      // The context.catch method must only be called with a location
      // argument that corresponds to a known catch block.
      throw new Error("illegal catch attempt");
    },

    delegateYield: function(iterable, resultName, nextLoc) {
      this.delegate = {
        iterator: values(iterable),
        resultName: resultName,
        nextLoc: nextLoc
      };

      if (this.method === "next") {
        // Deliberately forget the last sent value so that we don't
        // accidentally pass it on to the delegate.
        this.arg = undefined;
      }

      return ContinueSentinel;
    }
  };

  // Regardless of whether this script is executing as a CommonJS module
  // or not, return the runtime object so that we can declare the variable
  // regeneratorRuntime in the outer scope, which allows this module to be
  // injected easily by `bin/regenerator --include-runtime script.js`.
  return exports;

}(
  // If this script is executing as a CommonJS module, use module.exports
  // as the regeneratorRuntime namespace. Otherwise create a new empty
  // object. Either way, the resulting object will be used to initialize
  // the regeneratorRuntime variable at the top of this file.
   true ? module.exports : undefined
));

try {
  regeneratorRuntime = runtime;
} catch (accidentalStrictMode) {
  // This module should not be running in strict mode, so the above
  // assignment should always work unless something is misconfigured. Just
  // in case runtime.js accidentally runs in strict mode, we can escape
  // strict mode using a global Function call. This could conceivably fail
  // if a Content Security Policy forbids using Function, but in that case
  // the proper solution is to fix the accidental strict mode problem. If
  // you've misconfigured your bundler to force strict mode and applied a
  // CSP to forbid Function, and you're not willing to fix either of those
  // problems, please detail your unique predicament in a GitHub issue.
  Function("r", "regeneratorRuntime = r")(runtime);
}

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@skpm/promise/index.js */ "./node_modules/@skpm/promise/index.js")))

/***/ }),

/***/ "./node_modules/semver/classes/comparator.js":
/*!***************************************************!*\
  !*** ./node_modules/semver/classes/comparator.js ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

const ANY = Symbol('SemVer ANY')
// hoisted class for cyclic dependency
class Comparator {
  static get ANY () {
    return ANY
  }
  constructor (comp, options) {
    options = parseOptions(options)

    if (comp instanceof Comparator) {
      if (comp.loose === !!options.loose) {
        return comp
      } else {
        comp = comp.value
      }
    }

    debug('comparator', comp, options)
    this.options = options
    this.loose = !!options.loose
    this.parse(comp)

    if (this.semver === ANY) {
      this.value = ''
    } else {
      this.value = this.operator + this.semver.version
    }

    debug('comp', this)
  }

  parse (comp) {
    const r = this.options.loose ? re[t.COMPARATORLOOSE] : re[t.COMPARATOR]
    const m = comp.match(r)

    if (!m) {
      throw new TypeError(`Invalid comparator: ${comp}`)
    }

    this.operator = m[1] !== undefined ? m[1] : ''
    if (this.operator === '=') {
      this.operator = ''
    }

    // if it literally is just '>' or '' then allow anything.
    if (!m[2]) {
      this.semver = ANY
    } else {
      this.semver = new SemVer(m[2], this.options.loose)
    }
  }

  toString () {
    return this.value
  }

  test (version) {
    debug('Comparator.test', version, this.options.loose)

    if (this.semver === ANY || version === ANY) {
      return true
    }

    if (typeof version === 'string') {
      try {
        version = new SemVer(version, this.options)
      } catch (er) {
        return false
      }
    }

    return cmp(version, this.operator, this.semver, this.options)
  }

  intersects (comp, options) {
    if (!(comp instanceof Comparator)) {
      throw new TypeError('a Comparator is required')
    }

    if (!options || typeof options !== 'object') {
      options = {
        loose: !!options,
        includePrerelease: false
      }
    }

    if (this.operator === '') {
      if (this.value === '') {
        return true
      }
      return new Range(comp.value, options).test(this.value)
    } else if (comp.operator === '') {
      if (comp.value === '') {
        return true
      }
      return new Range(this.value, options).test(comp.semver)
    }

    const sameDirectionIncreasing =
      (this.operator === '>=' || this.operator === '>') &&
      (comp.operator === '>=' || comp.operator === '>')
    const sameDirectionDecreasing =
      (this.operator === '<=' || this.operator === '<') &&
      (comp.operator === '<=' || comp.operator === '<')
    const sameSemVer = this.semver.version === comp.semver.version
    const differentDirectionsInclusive =
      (this.operator === '>=' || this.operator === '<=') &&
      (comp.operator === '>=' || comp.operator === '<=')
    const oppositeDirectionsLessThan =
      cmp(this.semver, '<', comp.semver, options) &&
      (this.operator === '>=' || this.operator === '>') &&
        (comp.operator === '<=' || comp.operator === '<')
    const oppositeDirectionsGreaterThan =
      cmp(this.semver, '>', comp.semver, options) &&
      (this.operator === '<=' || this.operator === '<') &&
        (comp.operator === '>=' || comp.operator === '>')

    return (
      sameDirectionIncreasing ||
      sameDirectionDecreasing ||
      (sameSemVer && differentDirectionsInclusive) ||
      oppositeDirectionsLessThan ||
      oppositeDirectionsGreaterThan
    )
  }
}

module.exports = Comparator

const parseOptions = __webpack_require__(/*! ../internal/parse-options */ "./node_modules/semver/internal/parse-options.js")
const {re, t} = __webpack_require__(/*! ../internal/re */ "./node_modules/semver/internal/re.js")
const cmp = __webpack_require__(/*! ../functions/cmp */ "./node_modules/semver/functions/cmp.js")
const debug = __webpack_require__(/*! ../internal/debug */ "./node_modules/semver/internal/debug.js")
const SemVer = __webpack_require__(/*! ./semver */ "./node_modules/semver/classes/semver.js")
const Range = __webpack_require__(/*! ./range */ "./node_modules/semver/classes/range.js")


/***/ }),

/***/ "./node_modules/semver/classes/range.js":
/*!**********************************************!*\
  !*** ./node_modules/semver/classes/range.js ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// hoisted class for cyclic dependency
class Range {
  constructor (range, options) {
    options = parseOptions(options)

    if (range instanceof Range) {
      if (
        range.loose === !!options.loose &&
        range.includePrerelease === !!options.includePrerelease
      ) {
        return range
      } else {
        return new Range(range.raw, options)
      }
    }

    if (range instanceof Comparator) {
      // just put it in the set and return
      this.raw = range.value
      this.set = [[range]]
      this.format()
      return this
    }

    this.options = options
    this.loose = !!options.loose
    this.includePrerelease = !!options.includePrerelease

    // First, split based on boolean or ||
    this.raw = range
    this.set = range
      .split(/\s*\|\|\s*/)
      // map the range to a 2d array of comparators
      .map(range => this.parseRange(range.trim()))
      // throw out any comparator lists that are empty
      // this generally means that it was not a valid range, which is allowed
      // in loose mode, but will still throw if the WHOLE range is invalid.
      .filter(c => c.length)

    if (!this.set.length) {
      throw new TypeError(`Invalid SemVer Range: ${range}`)
    }

    // if we have any that are not the null set, throw out null sets.
    if (this.set.length > 1) {
      // keep the first one, in case they're all null sets
      const first = this.set[0]
      this.set = this.set.filter(c => !isNullSet(c[0]))
      if (this.set.length === 0)
        this.set = [first]
      else if (this.set.length > 1) {
        // if we have any that are *, then the range is just *
        for (const c of this.set) {
          if (c.length === 1 && isAny(c[0])) {
            this.set = [c]
            break
          }
        }
      }
    }

    this.format()
  }

  format () {
    this.range = this.set
      .map((comps) => {
        return comps.join(' ').trim()
      })
      .join('||')
      .trim()
    return this.range
  }

  toString () {
    return this.range
  }

  parseRange (range) {
    range = range.trim()

    // memoize range parsing for performance.
    // this is a very hot path, and fully deterministic.
    const memoOpts = Object.keys(this.options).join(',')
    const memoKey = `parseRange:${memoOpts}:${range}`
    const cached = cache.get(memoKey)
    if (cached)
      return cached

    const loose = this.options.loose
    // `1.2.3 - 1.2.4` => `>=1.2.3 <=1.2.4`
    const hr = loose ? re[t.HYPHENRANGELOOSE] : re[t.HYPHENRANGE]
    range = range.replace(hr, hyphenReplace(this.options.includePrerelease))
    debug('hyphen replace', range)
    // `> 1.2.3 < 1.2.5` => `>1.2.3 <1.2.5`
    range = range.replace(re[t.COMPARATORTRIM], comparatorTrimReplace)
    debug('comparator trim', range, re[t.COMPARATORTRIM])

    // `~ 1.2.3` => `~1.2.3`
    range = range.replace(re[t.TILDETRIM], tildeTrimReplace)

    // `^ 1.2.3` => `^1.2.3`
    range = range.replace(re[t.CARETTRIM], caretTrimReplace)

    // normalize spaces
    range = range.split(/\s+/).join(' ')

    // At this point, the range is completely trimmed and
    // ready to be split into comparators.

    const compRe = loose ? re[t.COMPARATORLOOSE] : re[t.COMPARATOR]
    const rangeList = range
      .split(' ')
      .map(comp => parseComparator(comp, this.options))
      .join(' ')
      .split(/\s+/)
      // >=0.0.0 is equivalent to *
      .map(comp => replaceGTE0(comp, this.options))
      // in loose mode, throw out any that are not valid comparators
      .filter(this.options.loose ? comp => !!comp.match(compRe) : () => true)
      .map(comp => new Comparator(comp, this.options))

    // if any comparators are the null set, then replace with JUST null set
    // if more than one comparator, remove any * comparators
    // also, don't include the same comparator more than once
    const l = rangeList.length
    const rangeMap = new Map()
    for (const comp of rangeList) {
      if (isNullSet(comp))
        return [comp]
      rangeMap.set(comp.value, comp)
    }
    if (rangeMap.size > 1 && rangeMap.has(''))
      rangeMap.delete('')

    const result = [...rangeMap.values()]
    cache.set(memoKey, result)
    return result
  }

  intersects (range, options) {
    if (!(range instanceof Range)) {
      throw new TypeError('a Range is required')
    }

    return this.set.some((thisComparators) => {
      return (
        isSatisfiable(thisComparators, options) &&
        range.set.some((rangeComparators) => {
          return (
            isSatisfiable(rangeComparators, options) &&
            thisComparators.every((thisComparator) => {
              return rangeComparators.every((rangeComparator) => {
                return thisComparator.intersects(rangeComparator, options)
              })
            })
          )
        })
      )
    })
  }

  // if ANY of the sets match ALL of its comparators, then pass
  test (version) {
    if (!version) {
      return false
    }

    if (typeof version === 'string') {
      try {
        version = new SemVer(version, this.options)
      } catch (er) {
        return false
      }
    }

    for (let i = 0; i < this.set.length; i++) {
      if (testSet(this.set[i], version, this.options)) {
        return true
      }
    }
    return false
  }
}
module.exports = Range

const LRU = __webpack_require__(/*! lru-cache */ "./node_modules/semver/node_modules/lru-cache/index.js")
const cache = new LRU({ max: 1000 })

const parseOptions = __webpack_require__(/*! ../internal/parse-options */ "./node_modules/semver/internal/parse-options.js")
const Comparator = __webpack_require__(/*! ./comparator */ "./node_modules/semver/classes/comparator.js")
const debug = __webpack_require__(/*! ../internal/debug */ "./node_modules/semver/internal/debug.js")
const SemVer = __webpack_require__(/*! ./semver */ "./node_modules/semver/classes/semver.js")
const {
  re,
  t,
  comparatorTrimReplace,
  tildeTrimReplace,
  caretTrimReplace
} = __webpack_require__(/*! ../internal/re */ "./node_modules/semver/internal/re.js")

const isNullSet = c => c.value === '<0.0.0-0'
const isAny = c => c.value === ''

// take a set of comparators and determine whether there
// exists a version which can satisfy it
const isSatisfiable = (comparators, options) => {
  let result = true
  const remainingComparators = comparators.slice()
  let testComparator = remainingComparators.pop()

  while (result && remainingComparators.length) {
    result = remainingComparators.every((otherComparator) => {
      return testComparator.intersects(otherComparator, options)
    })

    testComparator = remainingComparators.pop()
  }

  return result
}

// comprised of xranges, tildes, stars, and gtlt's at this point.
// already replaced the hyphen ranges
// turn into a set of JUST comparators.
const parseComparator = (comp, options) => {
  debug('comp', comp, options)
  comp = replaceCarets(comp, options)
  debug('caret', comp)
  comp = replaceTildes(comp, options)
  debug('tildes', comp)
  comp = replaceXRanges(comp, options)
  debug('xrange', comp)
  comp = replaceStars(comp, options)
  debug('stars', comp)
  return comp
}

const isX = id => !id || id.toLowerCase() === 'x' || id === '*'

// ~, ~> --> * (any, kinda silly)
// ~2, ~2.x, ~2.x.x, ~>2, ~>2.x ~>2.x.x --> >=2.0.0 <3.0.0-0
// ~2.0, ~2.0.x, ~>2.0, ~>2.0.x --> >=2.0.0 <2.1.0-0
// ~1.2, ~1.2.x, ~>1.2, ~>1.2.x --> >=1.2.0 <1.3.0-0
// ~1.2.3, ~>1.2.3 --> >=1.2.3 <1.3.0-0
// ~1.2.0, ~>1.2.0 --> >=1.2.0 <1.3.0-0
const replaceTildes = (comp, options) =>
  comp.trim().split(/\s+/).map((comp) => {
    return replaceTilde(comp, options)
  }).join(' ')

const replaceTilde = (comp, options) => {
  const r = options.loose ? re[t.TILDELOOSE] : re[t.TILDE]
  return comp.replace(r, (_, M, m, p, pr) => {
    debug('tilde', comp, _, M, m, p, pr)
    let ret

    if (isX(M)) {
      ret = ''
    } else if (isX(m)) {
      ret = `>=${M}.0.0 <${+M + 1}.0.0-0`
    } else if (isX(p)) {
      // ~1.2 == >=1.2.0 <1.3.0-0
      ret = `>=${M}.${m}.0 <${M}.${+m + 1}.0-0`
    } else if (pr) {
      debug('replaceTilde pr', pr)
      ret = `>=${M}.${m}.${p}-${pr
      } <${M}.${+m + 1}.0-0`
    } else {
      // ~1.2.3 == >=1.2.3 <1.3.0-0
      ret = `>=${M}.${m}.${p
      } <${M}.${+m + 1}.0-0`
    }

    debug('tilde return', ret)
    return ret
  })
}

// ^ --> * (any, kinda silly)
// ^2, ^2.x, ^2.x.x --> >=2.0.0 <3.0.0-0
// ^2.0, ^2.0.x --> >=2.0.0 <3.0.0-0
// ^1.2, ^1.2.x --> >=1.2.0 <2.0.0-0
// ^1.2.3 --> >=1.2.3 <2.0.0-0
// ^1.2.0 --> >=1.2.0 <2.0.0-0
const replaceCarets = (comp, options) =>
  comp.trim().split(/\s+/).map((comp) => {
    return replaceCaret(comp, options)
  }).join(' ')

const replaceCaret = (comp, options) => {
  debug('caret', comp, options)
  const r = options.loose ? re[t.CARETLOOSE] : re[t.CARET]
  const z = options.includePrerelease ? '-0' : ''
  return comp.replace(r, (_, M, m, p, pr) => {
    debug('caret', comp, _, M, m, p, pr)
    let ret

    if (isX(M)) {
      ret = ''
    } else if (isX(m)) {
      ret = `>=${M}.0.0${z} <${+M + 1}.0.0-0`
    } else if (isX(p)) {
      if (M === '0') {
        ret = `>=${M}.${m}.0${z} <${M}.${+m + 1}.0-0`
      } else {
        ret = `>=${M}.${m}.0${z} <${+M + 1}.0.0-0`
      }
    } else if (pr) {
      debug('replaceCaret pr', pr)
      if (M === '0') {
        if (m === '0') {
          ret = `>=${M}.${m}.${p}-${pr
          } <${M}.${m}.${+p + 1}-0`
        } else {
          ret = `>=${M}.${m}.${p}-${pr
          } <${M}.${+m + 1}.0-0`
        }
      } else {
        ret = `>=${M}.${m}.${p}-${pr
        } <${+M + 1}.0.0-0`
      }
    } else {
      debug('no pr')
      if (M === '0') {
        if (m === '0') {
          ret = `>=${M}.${m}.${p
          }${z} <${M}.${m}.${+p + 1}-0`
        } else {
          ret = `>=${M}.${m}.${p
          }${z} <${M}.${+m + 1}.0-0`
        }
      } else {
        ret = `>=${M}.${m}.${p
        } <${+M + 1}.0.0-0`
      }
    }

    debug('caret return', ret)
    return ret
  })
}

const replaceXRanges = (comp, options) => {
  debug('replaceXRanges', comp, options)
  return comp.split(/\s+/).map((comp) => {
    return replaceXRange(comp, options)
  }).join(' ')
}

const replaceXRange = (comp, options) => {
  comp = comp.trim()
  const r = options.loose ? re[t.XRANGELOOSE] : re[t.XRANGE]
  return comp.replace(r, (ret, gtlt, M, m, p, pr) => {
    debug('xRange', comp, ret, gtlt, M, m, p, pr)
    const xM = isX(M)
    const xm = xM || isX(m)
    const xp = xm || isX(p)
    const anyX = xp

    if (gtlt === '=' && anyX) {
      gtlt = ''
    }

    // if we're including prereleases in the match, then we need
    // to fix this to -0, the lowest possible prerelease value
    pr = options.includePrerelease ? '-0' : ''

    if (xM) {
      if (gtlt === '>' || gtlt === '<') {
        // nothing is allowed
        ret = '<0.0.0-0'
      } else {
        // nothing is forbidden
        ret = '*'
      }
    } else if (gtlt && anyX) {
      // we know patch is an x, because we have any x at all.
      // replace X with 0
      if (xm) {
        m = 0
      }
      p = 0

      if (gtlt === '>') {
        // >1 => >=2.0.0
        // >1.2 => >=1.3.0
        gtlt = '>='
        if (xm) {
          M = +M + 1
          m = 0
          p = 0
        } else {
          m = +m + 1
          p = 0
        }
      } else if (gtlt === '<=') {
        // <=0.7.x is actually <0.8.0, since any 0.7.x should
        // pass.  Similarly, <=7.x is actually <8.0.0, etc.
        gtlt = '<'
        if (xm) {
          M = +M + 1
        } else {
          m = +m + 1
        }
      }

      if (gtlt === '<')
        pr = '-0'

      ret = `${gtlt + M}.${m}.${p}${pr}`
    } else if (xm) {
      ret = `>=${M}.0.0${pr} <${+M + 1}.0.0-0`
    } else if (xp) {
      ret = `>=${M}.${m}.0${pr
      } <${M}.${+m + 1}.0-0`
    }

    debug('xRange return', ret)

    return ret
  })
}

// Because * is AND-ed with everything else in the comparator,
// and '' means "any version", just remove the *s entirely.
const replaceStars = (comp, options) => {
  debug('replaceStars', comp, options)
  // Looseness is ignored here.  star is always as loose as it gets!
  return comp.trim().replace(re[t.STAR], '')
}

const replaceGTE0 = (comp, options) => {
  debug('replaceGTE0', comp, options)
  return comp.trim()
    .replace(re[options.includePrerelease ? t.GTE0PRE : t.GTE0], '')
}

// This function is passed to string.replace(re[t.HYPHENRANGE])
// M, m, patch, prerelease, build
// 1.2 - 3.4.5 => >=1.2.0 <=3.4.5
// 1.2.3 - 3.4 => >=1.2.0 <3.5.0-0 Any 3.4.x will do
// 1.2 - 3.4 => >=1.2.0 <3.5.0-0
const hyphenReplace = incPr => ($0,
  from, fM, fm, fp, fpr, fb,
  to, tM, tm, tp, tpr, tb) => {
  if (isX(fM)) {
    from = ''
  } else if (isX(fm)) {
    from = `>=${fM}.0.0${incPr ? '-0' : ''}`
  } else if (isX(fp)) {
    from = `>=${fM}.${fm}.0${incPr ? '-0' : ''}`
  } else if (fpr) {
    from = `>=${from}`
  } else {
    from = `>=${from}${incPr ? '-0' : ''}`
  }

  if (isX(tM)) {
    to = ''
  } else if (isX(tm)) {
    to = `<${+tM + 1}.0.0-0`
  } else if (isX(tp)) {
    to = `<${tM}.${+tm + 1}.0-0`
  } else if (tpr) {
    to = `<=${tM}.${tm}.${tp}-${tpr}`
  } else if (incPr) {
    to = `<${tM}.${tm}.${+tp + 1}-0`
  } else {
    to = `<=${to}`
  }

  return (`${from} ${to}`).trim()
}

const testSet = (set, version, options) => {
  for (let i = 0; i < set.length; i++) {
    if (!set[i].test(version)) {
      return false
    }
  }

  if (version.prerelease.length && !options.includePrerelease) {
    // Find the set of versions that are allowed to have prereleases
    // For example, ^1.2.3-pr.1 desugars to >=1.2.3-pr.1 <2.0.0
    // That should allow `1.2.3-pr.2` to pass.
    // However, `1.2.4-alpha.notready` should NOT be allowed,
    // even though it's within the range set by the comparators.
    for (let i = 0; i < set.length; i++) {
      debug(set[i].semver)
      if (set[i].semver === Comparator.ANY) {
        continue
      }

      if (set[i].semver.prerelease.length > 0) {
        const allowed = set[i].semver
        if (allowed.major === version.major &&
            allowed.minor === version.minor &&
            allowed.patch === version.patch) {
          return true
        }
      }
    }

    // Version has a -pre, but it's not one of the ones we like.
    return false
  }

  return true
}


/***/ }),

/***/ "./node_modules/semver/classes/semver.js":
/*!***********************************************!*\
  !*** ./node_modules/semver/classes/semver.js ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

const debug = __webpack_require__(/*! ../internal/debug */ "./node_modules/semver/internal/debug.js")
const { MAX_LENGTH, MAX_SAFE_INTEGER } = __webpack_require__(/*! ../internal/constants */ "./node_modules/semver/internal/constants.js")
const { re, t } = __webpack_require__(/*! ../internal/re */ "./node_modules/semver/internal/re.js")

const parseOptions = __webpack_require__(/*! ../internal/parse-options */ "./node_modules/semver/internal/parse-options.js")
const { compareIdentifiers } = __webpack_require__(/*! ../internal/identifiers */ "./node_modules/semver/internal/identifiers.js")
class SemVer {
  constructor (version, options) {
    options = parseOptions(options)

    if (version instanceof SemVer) {
      if (version.loose === !!options.loose &&
          version.includePrerelease === !!options.includePrerelease) {
        return version
      } else {
        version = version.version
      }
    } else if (typeof version !== 'string') {
      throw new TypeError(`Invalid Version: ${version}`)
    }

    if (version.length > MAX_LENGTH) {
      throw new TypeError(
        `version is longer than ${MAX_LENGTH} characters`
      )
    }

    debug('SemVer', version, options)
    this.options = options
    this.loose = !!options.loose
    // this isn't actually relevant for versions, but keep it so that we
    // don't run into trouble passing this.options around.
    this.includePrerelease = !!options.includePrerelease

    const m = version.trim().match(options.loose ? re[t.LOOSE] : re[t.FULL])

    if (!m) {
      throw new TypeError(`Invalid Version: ${version}`)
    }

    this.raw = version

    // these are actually numbers
    this.major = +m[1]
    this.minor = +m[2]
    this.patch = +m[3]

    if (this.major > MAX_SAFE_INTEGER || this.major < 0) {
      throw new TypeError('Invalid major version')
    }

    if (this.minor > MAX_SAFE_INTEGER || this.minor < 0) {
      throw new TypeError('Invalid minor version')
    }

    if (this.patch > MAX_SAFE_INTEGER || this.patch < 0) {
      throw new TypeError('Invalid patch version')
    }

    // numberify any prerelease numeric ids
    if (!m[4]) {
      this.prerelease = []
    } else {
      this.prerelease = m[4].split('.').map((id) => {
        if (/^[0-9]+$/.test(id)) {
          const num = +id
          if (num >= 0 && num < MAX_SAFE_INTEGER) {
            return num
          }
        }
        return id
      })
    }

    this.build = m[5] ? m[5].split('.') : []
    this.format()
  }

  format () {
    this.version = `${this.major}.${this.minor}.${this.patch}`
    if (this.prerelease.length) {
      this.version += `-${this.prerelease.join('.')}`
    }
    return this.version
  }

  toString () {
    return this.version
  }

  compare (other) {
    debug('SemVer.compare', this.version, this.options, other)
    if (!(other instanceof SemVer)) {
      if (typeof other === 'string' && other === this.version) {
        return 0
      }
      other = new SemVer(other, this.options)
    }

    if (other.version === this.version) {
      return 0
    }

    return this.compareMain(other) || this.comparePre(other)
  }

  compareMain (other) {
    if (!(other instanceof SemVer)) {
      other = new SemVer(other, this.options)
    }

    return (
      compareIdentifiers(this.major, other.major) ||
      compareIdentifiers(this.minor, other.minor) ||
      compareIdentifiers(this.patch, other.patch)
    )
  }

  comparePre (other) {
    if (!(other instanceof SemVer)) {
      other = new SemVer(other, this.options)
    }

    // NOT having a prerelease is > having one
    if (this.prerelease.length && !other.prerelease.length) {
      return -1
    } else if (!this.prerelease.length && other.prerelease.length) {
      return 1
    } else if (!this.prerelease.length && !other.prerelease.length) {
      return 0
    }

    let i = 0
    do {
      const a = this.prerelease[i]
      const b = other.prerelease[i]
      debug('prerelease compare', i, a, b)
      if (a === undefined && b === undefined) {
        return 0
      } else if (b === undefined) {
        return 1
      } else if (a === undefined) {
        return -1
      } else if (a === b) {
        continue
      } else {
        return compareIdentifiers(a, b)
      }
    } while (++i)
  }

  compareBuild (other) {
    if (!(other instanceof SemVer)) {
      other = new SemVer(other, this.options)
    }

    let i = 0
    do {
      const a = this.build[i]
      const b = other.build[i]
      debug('prerelease compare', i, a, b)
      if (a === undefined && b === undefined) {
        return 0
      } else if (b === undefined) {
        return 1
      } else if (a === undefined) {
        return -1
      } else if (a === b) {
        continue
      } else {
        return compareIdentifiers(a, b)
      }
    } while (++i)
  }

  // preminor will bump the version up to the next minor release, and immediately
  // down to pre-release. premajor and prepatch work the same way.
  inc (release, identifier) {
    switch (release) {
      case 'premajor':
        this.prerelease.length = 0
        this.patch = 0
        this.minor = 0
        this.major++
        this.inc('pre', identifier)
        break
      case 'preminor':
        this.prerelease.length = 0
        this.patch = 0
        this.minor++
        this.inc('pre', identifier)
        break
      case 'prepatch':
        // If this is already a prerelease, it will bump to the next version
        // drop any prereleases that might already exist, since they are not
        // relevant at this point.
        this.prerelease.length = 0
        this.inc('patch', identifier)
        this.inc('pre', identifier)
        break
      // If the input is a non-prerelease version, this acts the same as
      // prepatch.
      case 'prerelease':
        if (this.prerelease.length === 0) {
          this.inc('patch', identifier)
        }
        this.inc('pre', identifier)
        break

      case 'major':
        // If this is a pre-major version, bump up to the same major version.
        // Otherwise increment major.
        // 1.0.0-5 bumps to 1.0.0
        // 1.1.0 bumps to 2.0.0
        if (
          this.minor !== 0 ||
          this.patch !== 0 ||
          this.prerelease.length === 0
        ) {
          this.major++
        }
        this.minor = 0
        this.patch = 0
        this.prerelease = []
        break
      case 'minor':
        // If this is a pre-minor version, bump up to the same minor version.
        // Otherwise increment minor.
        // 1.2.0-5 bumps to 1.2.0
        // 1.2.1 bumps to 1.3.0
        if (this.patch !== 0 || this.prerelease.length === 0) {
          this.minor++
        }
        this.patch = 0
        this.prerelease = []
        break
      case 'patch':
        // If this is not a pre-release version, it will increment the patch.
        // If it is a pre-release it will bump up to the same patch version.
        // 1.2.0-5 patches to 1.2.0
        // 1.2.0 patches to 1.2.1
        if (this.prerelease.length === 0) {
          this.patch++
        }
        this.prerelease = []
        break
      // This probably shouldn't be used publicly.
      // 1.0.0 'pre' would become 1.0.0-0 which is the wrong direction.
      case 'pre':
        if (this.prerelease.length === 0) {
          this.prerelease = [0]
        } else {
          let i = this.prerelease.length
          while (--i >= 0) {
            if (typeof this.prerelease[i] === 'number') {
              this.prerelease[i]++
              i = -2
            }
          }
          if (i === -1) {
            // didn't increment anything
            this.prerelease.push(0)
          }
        }
        if (identifier) {
          // 1.2.0-beta.1 bumps to 1.2.0-beta.2,
          // 1.2.0-beta.fooblz or 1.2.0-beta bumps to 1.2.0-beta.0
          if (this.prerelease[0] === identifier) {
            if (isNaN(this.prerelease[1])) {
              this.prerelease = [identifier, 0]
            }
          } else {
            this.prerelease = [identifier, 0]
          }
        }
        break

      default:
        throw new Error(`invalid increment argument: ${release}`)
    }
    this.format()
    this.raw = this.version
    return this
  }
}

module.exports = SemVer


/***/ }),

/***/ "./node_modules/semver/functions/clean.js":
/*!************************************************!*\
  !*** ./node_modules/semver/functions/clean.js ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

const parse = __webpack_require__(/*! ./parse */ "./node_modules/semver/functions/parse.js")
const clean = (version, options) => {
  const s = parse(version.trim().replace(/^[=v]+/, ''), options)
  return s ? s.version : null
}
module.exports = clean


/***/ }),

/***/ "./node_modules/semver/functions/cmp.js":
/*!**********************************************!*\
  !*** ./node_modules/semver/functions/cmp.js ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

const eq = __webpack_require__(/*! ./eq */ "./node_modules/semver/functions/eq.js")
const neq = __webpack_require__(/*! ./neq */ "./node_modules/semver/functions/neq.js")
const gt = __webpack_require__(/*! ./gt */ "./node_modules/semver/functions/gt.js")
const gte = __webpack_require__(/*! ./gte */ "./node_modules/semver/functions/gte.js")
const lt = __webpack_require__(/*! ./lt */ "./node_modules/semver/functions/lt.js")
const lte = __webpack_require__(/*! ./lte */ "./node_modules/semver/functions/lte.js")

const cmp = (a, op, b, loose) => {
  switch (op) {
    case '===':
      if (typeof a === 'object')
        a = a.version
      if (typeof b === 'object')
        b = b.version
      return a === b

    case '!==':
      if (typeof a === 'object')
        a = a.version
      if (typeof b === 'object')
        b = b.version
      return a !== b

    case '':
    case '=':
    case '==':
      return eq(a, b, loose)

    case '!=':
      return neq(a, b, loose)

    case '>':
      return gt(a, b, loose)

    case '>=':
      return gte(a, b, loose)

    case '<':
      return lt(a, b, loose)

    case '<=':
      return lte(a, b, loose)

    default:
      throw new TypeError(`Invalid operator: ${op}`)
  }
}
module.exports = cmp


/***/ }),

/***/ "./node_modules/semver/functions/coerce.js":
/*!*************************************************!*\
  !*** ./node_modules/semver/functions/coerce.js ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

const SemVer = __webpack_require__(/*! ../classes/semver */ "./node_modules/semver/classes/semver.js")
const parse = __webpack_require__(/*! ./parse */ "./node_modules/semver/functions/parse.js")
const {re, t} = __webpack_require__(/*! ../internal/re */ "./node_modules/semver/internal/re.js")

const coerce = (version, options) => {
  if (version instanceof SemVer) {
    return version
  }

  if (typeof version === 'number') {
    version = String(version)
  }

  if (typeof version !== 'string') {
    return null
  }

  options = options || {}

  let match = null
  if (!options.rtl) {
    match = version.match(re[t.COERCE])
  } else {
    // Find the right-most coercible string that does not share
    // a terminus with a more left-ward coercible string.
    // Eg, '1.2.3.4' wants to coerce '2.3.4', not '3.4' or '4'
    //
    // Walk through the string checking with a /g regexp
    // Manually set the index so as to pick up overlapping matches.
    // Stop when we get a match that ends at the string end, since no
    // coercible string can be more right-ward without the same terminus.
    let next
    while ((next = re[t.COERCERTL].exec(version)) &&
        (!match || match.index + match[0].length !== version.length)
    ) {
      if (!match ||
            next.index + next[0].length !== match.index + match[0].length) {
        match = next
      }
      re[t.COERCERTL].lastIndex = next.index + next[1].length + next[2].length
    }
    // leave it in a clean state
    re[t.COERCERTL].lastIndex = -1
  }

  if (match === null)
    return null

  return parse(`${match[2]}.${match[3] || '0'}.${match[4] || '0'}`, options)
}
module.exports = coerce


/***/ }),

/***/ "./node_modules/semver/functions/compare-build.js":
/*!********************************************************!*\
  !*** ./node_modules/semver/functions/compare-build.js ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

const SemVer = __webpack_require__(/*! ../classes/semver */ "./node_modules/semver/classes/semver.js")
const compareBuild = (a, b, loose) => {
  const versionA = new SemVer(a, loose)
  const versionB = new SemVer(b, loose)
  return versionA.compare(versionB) || versionA.compareBuild(versionB)
}
module.exports = compareBuild


/***/ }),

/***/ "./node_modules/semver/functions/compare-loose.js":
/*!********************************************************!*\
  !*** ./node_modules/semver/functions/compare-loose.js ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

const compare = __webpack_require__(/*! ./compare */ "./node_modules/semver/functions/compare.js")
const compareLoose = (a, b) => compare(a, b, true)
module.exports = compareLoose


/***/ }),

/***/ "./node_modules/semver/functions/compare.js":
/*!**************************************************!*\
  !*** ./node_modules/semver/functions/compare.js ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

const SemVer = __webpack_require__(/*! ../classes/semver */ "./node_modules/semver/classes/semver.js")
const compare = (a, b, loose) =>
  new SemVer(a, loose).compare(new SemVer(b, loose))

module.exports = compare


/***/ }),

/***/ "./node_modules/semver/functions/diff.js":
/*!***********************************************!*\
  !*** ./node_modules/semver/functions/diff.js ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

const parse = __webpack_require__(/*! ./parse */ "./node_modules/semver/functions/parse.js")
const eq = __webpack_require__(/*! ./eq */ "./node_modules/semver/functions/eq.js")

const diff = (version1, version2) => {
  if (eq(version1, version2)) {
    return null
  } else {
    const v1 = parse(version1)
    const v2 = parse(version2)
    const hasPre = v1.prerelease.length || v2.prerelease.length
    const prefix = hasPre ? 'pre' : ''
    const defaultResult = hasPre ? 'prerelease' : ''
    for (const key in v1) {
      if (key === 'major' || key === 'minor' || key === 'patch') {
        if (v1[key] !== v2[key]) {
          return prefix + key
        }
      }
    }
    return defaultResult // may be undefined
  }
}
module.exports = diff


/***/ }),

/***/ "./node_modules/semver/functions/eq.js":
/*!*********************************************!*\
  !*** ./node_modules/semver/functions/eq.js ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

const compare = __webpack_require__(/*! ./compare */ "./node_modules/semver/functions/compare.js")
const eq = (a, b, loose) => compare(a, b, loose) === 0
module.exports = eq


/***/ }),

/***/ "./node_modules/semver/functions/gt.js":
/*!*********************************************!*\
  !*** ./node_modules/semver/functions/gt.js ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

const compare = __webpack_require__(/*! ./compare */ "./node_modules/semver/functions/compare.js")
const gt = (a, b, loose) => compare(a, b, loose) > 0
module.exports = gt


/***/ }),

/***/ "./node_modules/semver/functions/gte.js":
/*!**********************************************!*\
  !*** ./node_modules/semver/functions/gte.js ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

const compare = __webpack_require__(/*! ./compare */ "./node_modules/semver/functions/compare.js")
const gte = (a, b, loose) => compare(a, b, loose) >= 0
module.exports = gte


/***/ }),

/***/ "./node_modules/semver/functions/inc.js":
/*!**********************************************!*\
  !*** ./node_modules/semver/functions/inc.js ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

const SemVer = __webpack_require__(/*! ../classes/semver */ "./node_modules/semver/classes/semver.js")

const inc = (version, release, options, identifier) => {
  if (typeof (options) === 'string') {
    identifier = options
    options = undefined
  }

  try {
    return new SemVer(version, options).inc(release, identifier).version
  } catch (er) {
    return null
  }
}
module.exports = inc


/***/ }),

/***/ "./node_modules/semver/functions/lt.js":
/*!*********************************************!*\
  !*** ./node_modules/semver/functions/lt.js ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

const compare = __webpack_require__(/*! ./compare */ "./node_modules/semver/functions/compare.js")
const lt = (a, b, loose) => compare(a, b, loose) < 0
module.exports = lt


/***/ }),

/***/ "./node_modules/semver/functions/lte.js":
/*!**********************************************!*\
  !*** ./node_modules/semver/functions/lte.js ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

const compare = __webpack_require__(/*! ./compare */ "./node_modules/semver/functions/compare.js")
const lte = (a, b, loose) => compare(a, b, loose) <= 0
module.exports = lte


/***/ }),

/***/ "./node_modules/semver/functions/major.js":
/*!************************************************!*\
  !*** ./node_modules/semver/functions/major.js ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

const SemVer = __webpack_require__(/*! ../classes/semver */ "./node_modules/semver/classes/semver.js")
const major = (a, loose) => new SemVer(a, loose).major
module.exports = major


/***/ }),

/***/ "./node_modules/semver/functions/minor.js":
/*!************************************************!*\
  !*** ./node_modules/semver/functions/minor.js ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

const SemVer = __webpack_require__(/*! ../classes/semver */ "./node_modules/semver/classes/semver.js")
const minor = (a, loose) => new SemVer(a, loose).minor
module.exports = minor


/***/ }),

/***/ "./node_modules/semver/functions/neq.js":
/*!**********************************************!*\
  !*** ./node_modules/semver/functions/neq.js ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

const compare = __webpack_require__(/*! ./compare */ "./node_modules/semver/functions/compare.js")
const neq = (a, b, loose) => compare(a, b, loose) !== 0
module.exports = neq


/***/ }),

/***/ "./node_modules/semver/functions/parse.js":
/*!************************************************!*\
  !*** ./node_modules/semver/functions/parse.js ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

const {MAX_LENGTH} = __webpack_require__(/*! ../internal/constants */ "./node_modules/semver/internal/constants.js")
const { re, t } = __webpack_require__(/*! ../internal/re */ "./node_modules/semver/internal/re.js")
const SemVer = __webpack_require__(/*! ../classes/semver */ "./node_modules/semver/classes/semver.js")

const parseOptions = __webpack_require__(/*! ../internal/parse-options */ "./node_modules/semver/internal/parse-options.js")
const parse = (version, options) => {
  options = parseOptions(options)

  if (version instanceof SemVer) {
    return version
  }

  if (typeof version !== 'string') {
    return null
  }

  if (version.length > MAX_LENGTH) {
    return null
  }

  const r = options.loose ? re[t.LOOSE] : re[t.FULL]
  if (!r.test(version)) {
    return null
  }

  try {
    return new SemVer(version, options)
  } catch (er) {
    return null
  }
}

module.exports = parse


/***/ }),

/***/ "./node_modules/semver/functions/patch.js":
/*!************************************************!*\
  !*** ./node_modules/semver/functions/patch.js ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

const SemVer = __webpack_require__(/*! ../classes/semver */ "./node_modules/semver/classes/semver.js")
const patch = (a, loose) => new SemVer(a, loose).patch
module.exports = patch


/***/ }),

/***/ "./node_modules/semver/functions/prerelease.js":
/*!*****************************************************!*\
  !*** ./node_modules/semver/functions/prerelease.js ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

const parse = __webpack_require__(/*! ./parse */ "./node_modules/semver/functions/parse.js")
const prerelease = (version, options) => {
  const parsed = parse(version, options)
  return (parsed && parsed.prerelease.length) ? parsed.prerelease : null
}
module.exports = prerelease


/***/ }),

/***/ "./node_modules/semver/functions/rcompare.js":
/*!***************************************************!*\
  !*** ./node_modules/semver/functions/rcompare.js ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

const compare = __webpack_require__(/*! ./compare */ "./node_modules/semver/functions/compare.js")
const rcompare = (a, b, loose) => compare(b, a, loose)
module.exports = rcompare


/***/ }),

/***/ "./node_modules/semver/functions/rsort.js":
/*!************************************************!*\
  !*** ./node_modules/semver/functions/rsort.js ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

const compareBuild = __webpack_require__(/*! ./compare-build */ "./node_modules/semver/functions/compare-build.js")
const rsort = (list, loose) => list.sort((a, b) => compareBuild(b, a, loose))
module.exports = rsort


/***/ }),

/***/ "./node_modules/semver/functions/satisfies.js":
/*!****************************************************!*\
  !*** ./node_modules/semver/functions/satisfies.js ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

const Range = __webpack_require__(/*! ../classes/range */ "./node_modules/semver/classes/range.js")
const satisfies = (version, range, options) => {
  try {
    range = new Range(range, options)
  } catch (er) {
    return false
  }
  return range.test(version)
}
module.exports = satisfies


/***/ }),

/***/ "./node_modules/semver/functions/sort.js":
/*!***********************************************!*\
  !*** ./node_modules/semver/functions/sort.js ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

const compareBuild = __webpack_require__(/*! ./compare-build */ "./node_modules/semver/functions/compare-build.js")
const sort = (list, loose) => list.sort((a, b) => compareBuild(a, b, loose))
module.exports = sort


/***/ }),

/***/ "./node_modules/semver/functions/valid.js":
/*!************************************************!*\
  !*** ./node_modules/semver/functions/valid.js ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

const parse = __webpack_require__(/*! ./parse */ "./node_modules/semver/functions/parse.js")
const valid = (version, options) => {
  const v = parse(version, options)
  return v ? v.version : null
}
module.exports = valid


/***/ }),

/***/ "./node_modules/semver/index.js":
/*!**************************************!*\
  !*** ./node_modules/semver/index.js ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// just pre-load all the stuff that index.js lazily exports
const internalRe = __webpack_require__(/*! ./internal/re */ "./node_modules/semver/internal/re.js")
module.exports = {
  re: internalRe.re,
  src: internalRe.src,
  tokens: internalRe.t,
  SEMVER_SPEC_VERSION: __webpack_require__(/*! ./internal/constants */ "./node_modules/semver/internal/constants.js").SEMVER_SPEC_VERSION,
  SemVer: __webpack_require__(/*! ./classes/semver */ "./node_modules/semver/classes/semver.js"),
  compareIdentifiers: __webpack_require__(/*! ./internal/identifiers */ "./node_modules/semver/internal/identifiers.js").compareIdentifiers,
  rcompareIdentifiers: __webpack_require__(/*! ./internal/identifiers */ "./node_modules/semver/internal/identifiers.js").rcompareIdentifiers,
  parse: __webpack_require__(/*! ./functions/parse */ "./node_modules/semver/functions/parse.js"),
  valid: __webpack_require__(/*! ./functions/valid */ "./node_modules/semver/functions/valid.js"),
  clean: __webpack_require__(/*! ./functions/clean */ "./node_modules/semver/functions/clean.js"),
  inc: __webpack_require__(/*! ./functions/inc */ "./node_modules/semver/functions/inc.js"),
  diff: __webpack_require__(/*! ./functions/diff */ "./node_modules/semver/functions/diff.js"),
  major: __webpack_require__(/*! ./functions/major */ "./node_modules/semver/functions/major.js"),
  minor: __webpack_require__(/*! ./functions/minor */ "./node_modules/semver/functions/minor.js"),
  patch: __webpack_require__(/*! ./functions/patch */ "./node_modules/semver/functions/patch.js"),
  prerelease: __webpack_require__(/*! ./functions/prerelease */ "./node_modules/semver/functions/prerelease.js"),
  compare: __webpack_require__(/*! ./functions/compare */ "./node_modules/semver/functions/compare.js"),
  rcompare: __webpack_require__(/*! ./functions/rcompare */ "./node_modules/semver/functions/rcompare.js"),
  compareLoose: __webpack_require__(/*! ./functions/compare-loose */ "./node_modules/semver/functions/compare-loose.js"),
  compareBuild: __webpack_require__(/*! ./functions/compare-build */ "./node_modules/semver/functions/compare-build.js"),
  sort: __webpack_require__(/*! ./functions/sort */ "./node_modules/semver/functions/sort.js"),
  rsort: __webpack_require__(/*! ./functions/rsort */ "./node_modules/semver/functions/rsort.js"),
  gt: __webpack_require__(/*! ./functions/gt */ "./node_modules/semver/functions/gt.js"),
  lt: __webpack_require__(/*! ./functions/lt */ "./node_modules/semver/functions/lt.js"),
  eq: __webpack_require__(/*! ./functions/eq */ "./node_modules/semver/functions/eq.js"),
  neq: __webpack_require__(/*! ./functions/neq */ "./node_modules/semver/functions/neq.js"),
  gte: __webpack_require__(/*! ./functions/gte */ "./node_modules/semver/functions/gte.js"),
  lte: __webpack_require__(/*! ./functions/lte */ "./node_modules/semver/functions/lte.js"),
  cmp: __webpack_require__(/*! ./functions/cmp */ "./node_modules/semver/functions/cmp.js"),
  coerce: __webpack_require__(/*! ./functions/coerce */ "./node_modules/semver/functions/coerce.js"),
  Comparator: __webpack_require__(/*! ./classes/comparator */ "./node_modules/semver/classes/comparator.js"),
  Range: __webpack_require__(/*! ./classes/range */ "./node_modules/semver/classes/range.js"),
  satisfies: __webpack_require__(/*! ./functions/satisfies */ "./node_modules/semver/functions/satisfies.js"),
  toComparators: __webpack_require__(/*! ./ranges/to-comparators */ "./node_modules/semver/ranges/to-comparators.js"),
  maxSatisfying: __webpack_require__(/*! ./ranges/max-satisfying */ "./node_modules/semver/ranges/max-satisfying.js"),
  minSatisfying: __webpack_require__(/*! ./ranges/min-satisfying */ "./node_modules/semver/ranges/min-satisfying.js"),
  minVersion: __webpack_require__(/*! ./ranges/min-version */ "./node_modules/semver/ranges/min-version.js"),
  validRange: __webpack_require__(/*! ./ranges/valid */ "./node_modules/semver/ranges/valid.js"),
  outside: __webpack_require__(/*! ./ranges/outside */ "./node_modules/semver/ranges/outside.js"),
  gtr: __webpack_require__(/*! ./ranges/gtr */ "./node_modules/semver/ranges/gtr.js"),
  ltr: __webpack_require__(/*! ./ranges/ltr */ "./node_modules/semver/ranges/ltr.js"),
  intersects: __webpack_require__(/*! ./ranges/intersects */ "./node_modules/semver/ranges/intersects.js"),
  simplifyRange: __webpack_require__(/*! ./ranges/simplify */ "./node_modules/semver/ranges/simplify.js"),
  subset: __webpack_require__(/*! ./ranges/subset */ "./node_modules/semver/ranges/subset.js"),
}


/***/ }),

/***/ "./node_modules/semver/internal/constants.js":
/*!***************************************************!*\
  !*** ./node_modules/semver/internal/constants.js ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

// Note: this is the semver.org version of the spec that it implements
// Not necessarily the package version of this code.
const SEMVER_SPEC_VERSION = '2.0.0'

const MAX_LENGTH = 256
const MAX_SAFE_INTEGER = Number.MAX_SAFE_INTEGER ||
  /* istanbul ignore next */ 9007199254740991

// Max safe segment length for coercion.
const MAX_SAFE_COMPONENT_LENGTH = 16

module.exports = {
  SEMVER_SPEC_VERSION,
  MAX_LENGTH,
  MAX_SAFE_INTEGER,
  MAX_SAFE_COMPONENT_LENGTH
}


/***/ }),

/***/ "./node_modules/semver/internal/debug.js":
/*!***********************************************!*\
  !*** ./node_modules/semver/internal/debug.js ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

const debug = (
  typeof process === 'object' &&
  process.env &&
  process.env.NODE_DEBUG &&
  /\bsemver\b/i.test(process.env.NODE_DEBUG)
) ? (...args) => console.error('SEMVER', ...args)
  : () => {}

module.exports = debug


/***/ }),

/***/ "./node_modules/semver/internal/identifiers.js":
/*!*****************************************************!*\
  !*** ./node_modules/semver/internal/identifiers.js ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

const numeric = /^[0-9]+$/
const compareIdentifiers = (a, b) => {
  const anum = numeric.test(a)
  const bnum = numeric.test(b)

  if (anum && bnum) {
    a = +a
    b = +b
  }

  return a === b ? 0
    : (anum && !bnum) ? -1
    : (bnum && !anum) ? 1
    : a < b ? -1
    : 1
}

const rcompareIdentifiers = (a, b) => compareIdentifiers(b, a)

module.exports = {
  compareIdentifiers,
  rcompareIdentifiers
}


/***/ }),

/***/ "./node_modules/semver/internal/parse-options.js":
/*!*******************************************************!*\
  !*** ./node_modules/semver/internal/parse-options.js ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

// parse out just the options we care about so we always get a consistent
// obj with keys in a consistent order.
const opts = ['includePrerelease', 'loose', 'rtl']
const parseOptions = options =>
  !options ? {}
  : typeof options !== 'object' ? { loose: true }
  : opts.filter(k => options[k]).reduce((options, k) => {
    options[k] = true
    return options
  }, {})
module.exports = parseOptions


/***/ }),

/***/ "./node_modules/semver/internal/re.js":
/*!********************************************!*\
  !*** ./node_modules/semver/internal/re.js ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

const { MAX_SAFE_COMPONENT_LENGTH } = __webpack_require__(/*! ./constants */ "./node_modules/semver/internal/constants.js")
const debug = __webpack_require__(/*! ./debug */ "./node_modules/semver/internal/debug.js")
exports = module.exports = {}

// The actual regexps go on exports.re
const re = exports.re = []
const src = exports.src = []
const t = exports.t = {}
let R = 0

const createToken = (name, value, isGlobal) => {
  const index = R++
  debug(index, value)
  t[name] = index
  src[index] = value
  re[index] = new RegExp(value, isGlobal ? 'g' : undefined)
}

// The following Regular Expressions can be used for tokenizing,
// validating, and parsing SemVer version strings.

// ## Numeric Identifier
// A single `0`, or a non-zero digit followed by zero or more digits.

createToken('NUMERICIDENTIFIER', '0|[1-9]\\d*')
createToken('NUMERICIDENTIFIERLOOSE', '[0-9]+')

// ## Non-numeric Identifier
// Zero or more digits, followed by a letter or hyphen, and then zero or
// more letters, digits, or hyphens.

createToken('NONNUMERICIDENTIFIER', '\\d*[a-zA-Z-][a-zA-Z0-9-]*')

// ## Main Version
// Three dot-separated numeric identifiers.

createToken('MAINVERSION', `(${src[t.NUMERICIDENTIFIER]})\\.` +
                   `(${src[t.NUMERICIDENTIFIER]})\\.` +
                   `(${src[t.NUMERICIDENTIFIER]})`)

createToken('MAINVERSIONLOOSE', `(${src[t.NUMERICIDENTIFIERLOOSE]})\\.` +
                        `(${src[t.NUMERICIDENTIFIERLOOSE]})\\.` +
                        `(${src[t.NUMERICIDENTIFIERLOOSE]})`)

// ## Pre-release Version Identifier
// A numeric identifier, or a non-numeric identifier.

createToken('PRERELEASEIDENTIFIER', `(?:${src[t.NUMERICIDENTIFIER]
}|${src[t.NONNUMERICIDENTIFIER]})`)

createToken('PRERELEASEIDENTIFIERLOOSE', `(?:${src[t.NUMERICIDENTIFIERLOOSE]
}|${src[t.NONNUMERICIDENTIFIER]})`)

// ## Pre-release Version
// Hyphen, followed by one or more dot-separated pre-release version
// identifiers.

createToken('PRERELEASE', `(?:-(${src[t.PRERELEASEIDENTIFIER]
}(?:\\.${src[t.PRERELEASEIDENTIFIER]})*))`)

createToken('PRERELEASELOOSE', `(?:-?(${src[t.PRERELEASEIDENTIFIERLOOSE]
}(?:\\.${src[t.PRERELEASEIDENTIFIERLOOSE]})*))`)

// ## Build Metadata Identifier
// Any combination of digits, letters, or hyphens.

createToken('BUILDIDENTIFIER', '[0-9A-Za-z-]+')

// ## Build Metadata
// Plus sign, followed by one or more period-separated build metadata
// identifiers.

createToken('BUILD', `(?:\\+(${src[t.BUILDIDENTIFIER]
}(?:\\.${src[t.BUILDIDENTIFIER]})*))`)

// ## Full Version String
// A main version, followed optionally by a pre-release version and
// build metadata.

// Note that the only major, minor, patch, and pre-release sections of
// the version string are capturing groups.  The build metadata is not a
// capturing group, because it should not ever be used in version
// comparison.

createToken('FULLPLAIN', `v?${src[t.MAINVERSION]
}${src[t.PRERELEASE]}?${
  src[t.BUILD]}?`)

createToken('FULL', `^${src[t.FULLPLAIN]}$`)

// like full, but allows v1.2.3 and =1.2.3, which people do sometimes.
// also, 1.0.0alpha1 (prerelease without the hyphen) which is pretty
// common in the npm registry.
createToken('LOOSEPLAIN', `[v=\\s]*${src[t.MAINVERSIONLOOSE]
}${src[t.PRERELEASELOOSE]}?${
  src[t.BUILD]}?`)

createToken('LOOSE', `^${src[t.LOOSEPLAIN]}$`)

createToken('GTLT', '((?:<|>)?=?)')

// Something like "2.*" or "1.2.x".
// Note that "x.x" is a valid xRange identifer, meaning "any version"
// Only the first item is strictly required.
createToken('XRANGEIDENTIFIERLOOSE', `${src[t.NUMERICIDENTIFIERLOOSE]}|x|X|\\*`)
createToken('XRANGEIDENTIFIER', `${src[t.NUMERICIDENTIFIER]}|x|X|\\*`)

createToken('XRANGEPLAIN', `[v=\\s]*(${src[t.XRANGEIDENTIFIER]})` +
                   `(?:\\.(${src[t.XRANGEIDENTIFIER]})` +
                   `(?:\\.(${src[t.XRANGEIDENTIFIER]})` +
                   `(?:${src[t.PRERELEASE]})?${
                     src[t.BUILD]}?` +
                   `)?)?`)

createToken('XRANGEPLAINLOOSE', `[v=\\s]*(${src[t.XRANGEIDENTIFIERLOOSE]})` +
                        `(?:\\.(${src[t.XRANGEIDENTIFIERLOOSE]})` +
                        `(?:\\.(${src[t.XRANGEIDENTIFIERLOOSE]})` +
                        `(?:${src[t.PRERELEASELOOSE]})?${
                          src[t.BUILD]}?` +
                        `)?)?`)

createToken('XRANGE', `^${src[t.GTLT]}\\s*${src[t.XRANGEPLAIN]}$`)
createToken('XRANGELOOSE', `^${src[t.GTLT]}\\s*${src[t.XRANGEPLAINLOOSE]}$`)

// Coercion.
// Extract anything that could conceivably be a part of a valid semver
createToken('COERCE', `${'(^|[^\\d])' +
              '(\\d{1,'}${MAX_SAFE_COMPONENT_LENGTH}})` +
              `(?:\\.(\\d{1,${MAX_SAFE_COMPONENT_LENGTH}}))?` +
              `(?:\\.(\\d{1,${MAX_SAFE_COMPONENT_LENGTH}}))?` +
              `(?:$|[^\\d])`)
createToken('COERCERTL', src[t.COERCE], true)

// Tilde ranges.
// Meaning is "reasonably at or greater than"
createToken('LONETILDE', '(?:~>?)')

createToken('TILDETRIM', `(\\s*)${src[t.LONETILDE]}\\s+`, true)
exports.tildeTrimReplace = '$1~'

createToken('TILDE', `^${src[t.LONETILDE]}${src[t.XRANGEPLAIN]}$`)
createToken('TILDELOOSE', `^${src[t.LONETILDE]}${src[t.XRANGEPLAINLOOSE]}$`)

// Caret ranges.
// Meaning is "at least and backwards compatible with"
createToken('LONECARET', '(?:\\^)')

createToken('CARETTRIM', `(\\s*)${src[t.LONECARET]}\\s+`, true)
exports.caretTrimReplace = '$1^'

createToken('CARET', `^${src[t.LONECARET]}${src[t.XRANGEPLAIN]}$`)
createToken('CARETLOOSE', `^${src[t.LONECARET]}${src[t.XRANGEPLAINLOOSE]}$`)

// A simple gt/lt/eq thing, or just "" to indicate "any version"
createToken('COMPARATORLOOSE', `^${src[t.GTLT]}\\s*(${src[t.LOOSEPLAIN]})$|^$`)
createToken('COMPARATOR', `^${src[t.GTLT]}\\s*(${src[t.FULLPLAIN]})$|^$`)

// An expression to strip any whitespace between the gtlt and the thing
// it modifies, so that `> 1.2.3` ==> `>1.2.3`
createToken('COMPARATORTRIM', `(\\s*)${src[t.GTLT]
}\\s*(${src[t.LOOSEPLAIN]}|${src[t.XRANGEPLAIN]})`, true)
exports.comparatorTrimReplace = '$1$2$3'

// Something like `1.2.3 - 1.2.4`
// Note that these all use the loose form, because they'll be
// checked against either the strict or loose comparator form
// later.
createToken('HYPHENRANGE', `^\\s*(${src[t.XRANGEPLAIN]})` +
                   `\\s+-\\s+` +
                   `(${src[t.XRANGEPLAIN]})` +
                   `\\s*$`)

createToken('HYPHENRANGELOOSE', `^\\s*(${src[t.XRANGEPLAINLOOSE]})` +
                        `\\s+-\\s+` +
                        `(${src[t.XRANGEPLAINLOOSE]})` +
                        `\\s*$`)

// Star ranges basically just allow anything at all.
createToken('STAR', '(<|>)?=?\\s*\\*')
// >=0.0.0 is like a star
createToken('GTE0', '^\\s*>=\\s*0\.0\.0\\s*$')
createToken('GTE0PRE', '^\\s*>=\\s*0\.0\.0-0\\s*$')


/***/ }),

/***/ "./node_modules/semver/node_modules/lru-cache/index.js":
/*!*************************************************************!*\
  !*** ./node_modules/semver/node_modules/lru-cache/index.js ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


// A linked list to keep track of recently-used-ness
const Yallist = __webpack_require__(/*! yallist */ "./node_modules/semver/node_modules/yallist/yallist.js")

const MAX = Symbol('max')
const LENGTH = Symbol('length')
const LENGTH_CALCULATOR = Symbol('lengthCalculator')
const ALLOW_STALE = Symbol('allowStale')
const MAX_AGE = Symbol('maxAge')
const DISPOSE = Symbol('dispose')
const NO_DISPOSE_ON_SET = Symbol('noDisposeOnSet')
const LRU_LIST = Symbol('lruList')
const CACHE = Symbol('cache')
const UPDATE_AGE_ON_GET = Symbol('updateAgeOnGet')

const naiveLength = () => 1

// lruList is a yallist where the head is the youngest
// item, and the tail is the oldest.  the list contains the Hit
// objects as the entries.
// Each Hit object has a reference to its Yallist.Node.  This
// never changes.
//
// cache is a Map (or PseudoMap) that matches the keys to
// the Yallist.Node object.
class LRUCache {
  constructor (options) {
    if (typeof options === 'number')
      options = { max: options }

    if (!options)
      options = {}

    if (options.max && (typeof options.max !== 'number' || options.max < 0))
      throw new TypeError('max must be a non-negative number')
    // Kind of weird to have a default max of Infinity, but oh well.
    const max = this[MAX] = options.max || Infinity

    const lc = options.length || naiveLength
    this[LENGTH_CALCULATOR] = (typeof lc !== 'function') ? naiveLength : lc
    this[ALLOW_STALE] = options.stale || false
    if (options.maxAge && typeof options.maxAge !== 'number')
      throw new TypeError('maxAge must be a number')
    this[MAX_AGE] = options.maxAge || 0
    this[DISPOSE] = options.dispose
    this[NO_DISPOSE_ON_SET] = options.noDisposeOnSet || false
    this[UPDATE_AGE_ON_GET] = options.updateAgeOnGet || false
    this.reset()
  }

  // resize the cache when the max changes.
  set max (mL) {
    if (typeof mL !== 'number' || mL < 0)
      throw new TypeError('max must be a non-negative number')

    this[MAX] = mL || Infinity
    trim(this)
  }
  get max () {
    return this[MAX]
  }

  set allowStale (allowStale) {
    this[ALLOW_STALE] = !!allowStale
  }
  get allowStale () {
    return this[ALLOW_STALE]
  }

  set maxAge (mA) {
    if (typeof mA !== 'number')
      throw new TypeError('maxAge must be a non-negative number')

    this[MAX_AGE] = mA
    trim(this)
  }
  get maxAge () {
    return this[MAX_AGE]
  }

  // resize the cache when the lengthCalculator changes.
  set lengthCalculator (lC) {
    if (typeof lC !== 'function')
      lC = naiveLength

    if (lC !== this[LENGTH_CALCULATOR]) {
      this[LENGTH_CALCULATOR] = lC
      this[LENGTH] = 0
      this[LRU_LIST].forEach(hit => {
        hit.length = this[LENGTH_CALCULATOR](hit.value, hit.key)
        this[LENGTH] += hit.length
      })
    }
    trim(this)
  }
  get lengthCalculator () { return this[LENGTH_CALCULATOR] }

  get length () { return this[LENGTH] }
  get itemCount () { return this[LRU_LIST].length }

  rforEach (fn, thisp) {
    thisp = thisp || this
    for (let walker = this[LRU_LIST].tail; walker !== null;) {
      const prev = walker.prev
      forEachStep(this, fn, walker, thisp)
      walker = prev
    }
  }

  forEach (fn, thisp) {
    thisp = thisp || this
    for (let walker = this[LRU_LIST].head; walker !== null;) {
      const next = walker.next
      forEachStep(this, fn, walker, thisp)
      walker = next
    }
  }

  keys () {
    return this[LRU_LIST].toArray().map(k => k.key)
  }

  values () {
    return this[LRU_LIST].toArray().map(k => k.value)
  }

  reset () {
    if (this[DISPOSE] &&
        this[LRU_LIST] &&
        this[LRU_LIST].length) {
      this[LRU_LIST].forEach(hit => this[DISPOSE](hit.key, hit.value))
    }

    this[CACHE] = new Map() // hash of items by key
    this[LRU_LIST] = new Yallist() // list of items in order of use recency
    this[LENGTH] = 0 // length of items in the list
  }

  dump () {
    return this[LRU_LIST].map(hit =>
      isStale(this, hit) ? false : {
        k: hit.key,
        v: hit.value,
        e: hit.now + (hit.maxAge || 0)
      }).toArray().filter(h => h)
  }

  dumpLru () {
    return this[LRU_LIST]
  }

  set (key, value, maxAge) {
    maxAge = maxAge || this[MAX_AGE]

    if (maxAge && typeof maxAge !== 'number')
      throw new TypeError('maxAge must be a number')

    const now = maxAge ? Date.now() : 0
    const len = this[LENGTH_CALCULATOR](value, key)

    if (this[CACHE].has(key)) {
      if (len > this[MAX]) {
        del(this, this[CACHE].get(key))
        return false
      }

      const node = this[CACHE].get(key)
      const item = node.value

      // dispose of the old one before overwriting
      // split out into 2 ifs for better coverage tracking
      if (this[DISPOSE]) {
        if (!this[NO_DISPOSE_ON_SET])
          this[DISPOSE](key, item.value)
      }

      item.now = now
      item.maxAge = maxAge
      item.value = value
      this[LENGTH] += len - item.length
      item.length = len
      this.get(key)
      trim(this)
      return true
    }

    const hit = new Entry(key, value, len, now, maxAge)

    // oversized objects fall out of cache automatically.
    if (hit.length > this[MAX]) {
      if (this[DISPOSE])
        this[DISPOSE](key, value)

      return false
    }

    this[LENGTH] += hit.length
    this[LRU_LIST].unshift(hit)
    this[CACHE].set(key, this[LRU_LIST].head)
    trim(this)
    return true
  }

  has (key) {
    if (!this[CACHE].has(key)) return false
    const hit = this[CACHE].get(key).value
    return !isStale(this, hit)
  }

  get (key) {
    return get(this, key, true)
  }

  peek (key) {
    return get(this, key, false)
  }

  pop () {
    const node = this[LRU_LIST].tail
    if (!node)
      return null

    del(this, node)
    return node.value
  }

  del (key) {
    del(this, this[CACHE].get(key))
  }

  load (arr) {
    // reset the cache
    this.reset()

    const now = Date.now()
    // A previous serialized cache has the most recent items first
    for (let l = arr.length - 1; l >= 0; l--) {
      const hit = arr[l]
      const expiresAt = hit.e || 0
      if (expiresAt === 0)
        // the item was created without expiration in a non aged cache
        this.set(hit.k, hit.v)
      else {
        const maxAge = expiresAt - now
        // dont add already expired items
        if (maxAge > 0) {
          this.set(hit.k, hit.v, maxAge)
        }
      }
    }
  }

  prune () {
    this[CACHE].forEach((value, key) => get(this, key, false))
  }
}

const get = (self, key, doUse) => {
  const node = self[CACHE].get(key)
  if (node) {
    const hit = node.value
    if (isStale(self, hit)) {
      del(self, node)
      if (!self[ALLOW_STALE])
        return undefined
    } else {
      if (doUse) {
        if (self[UPDATE_AGE_ON_GET])
          node.value.now = Date.now()
        self[LRU_LIST].unshiftNode(node)
      }
    }
    return hit.value
  }
}

const isStale = (self, hit) => {
  if (!hit || (!hit.maxAge && !self[MAX_AGE]))
    return false

  const diff = Date.now() - hit.now
  return hit.maxAge ? diff > hit.maxAge
    : self[MAX_AGE] && (diff > self[MAX_AGE])
}

const trim = self => {
  if (self[LENGTH] > self[MAX]) {
    for (let walker = self[LRU_LIST].tail;
      self[LENGTH] > self[MAX] && walker !== null;) {
      // We know that we're about to delete this one, and also
      // what the next least recently used key will be, so just
      // go ahead and set it now.
      const prev = walker.prev
      del(self, walker)
      walker = prev
    }
  }
}

const del = (self, node) => {
  if (node) {
    const hit = node.value
    if (self[DISPOSE])
      self[DISPOSE](hit.key, hit.value)

    self[LENGTH] -= hit.length
    self[CACHE].delete(hit.key)
    self[LRU_LIST].removeNode(node)
  }
}

class Entry {
  constructor (key, value, length, now, maxAge) {
    this.key = key
    this.value = value
    this.length = length
    this.now = now
    this.maxAge = maxAge || 0
  }
}

const forEachStep = (self, fn, node, thisp) => {
  let hit = node.value
  if (isStale(self, hit)) {
    del(self, node)
    if (!self[ALLOW_STALE])
      hit = undefined
  }
  if (hit)
    fn.call(thisp, hit.value, hit.key, self)
}

module.exports = LRUCache


/***/ }),

/***/ "./node_modules/semver/node_modules/yallist/iterator.js":
/*!**************************************************************!*\
  !*** ./node_modules/semver/node_modules/yallist/iterator.js ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

module.exports = function (Yallist) {
  Yallist.prototype[Symbol.iterator] = function* () {
    for (let walker = this.head; walker; walker = walker.next) {
      yield walker.value
    }
  }
}


/***/ }),

/***/ "./node_modules/semver/node_modules/yallist/yallist.js":
/*!*************************************************************!*\
  !*** ./node_modules/semver/node_modules/yallist/yallist.js ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

module.exports = Yallist

Yallist.Node = Node
Yallist.create = Yallist

function Yallist (list) {
  var self = this
  if (!(self instanceof Yallist)) {
    self = new Yallist()
  }

  self.tail = null
  self.head = null
  self.length = 0

  if (list && typeof list.forEach === 'function') {
    list.forEach(function (item) {
      self.push(item)
    })
  } else if (arguments.length > 0) {
    for (var i = 0, l = arguments.length; i < l; i++) {
      self.push(arguments[i])
    }
  }

  return self
}

Yallist.prototype.removeNode = function (node) {
  if (node.list !== this) {
    throw new Error('removing node which does not belong to this list')
  }

  var next = node.next
  var prev = node.prev

  if (next) {
    next.prev = prev
  }

  if (prev) {
    prev.next = next
  }

  if (node === this.head) {
    this.head = next
  }
  if (node === this.tail) {
    this.tail = prev
  }

  node.list.length--
  node.next = null
  node.prev = null
  node.list = null

  return next
}

Yallist.prototype.unshiftNode = function (node) {
  if (node === this.head) {
    return
  }

  if (node.list) {
    node.list.removeNode(node)
  }

  var head = this.head
  node.list = this
  node.next = head
  if (head) {
    head.prev = node
  }

  this.head = node
  if (!this.tail) {
    this.tail = node
  }
  this.length++
}

Yallist.prototype.pushNode = function (node) {
  if (node === this.tail) {
    return
  }

  if (node.list) {
    node.list.removeNode(node)
  }

  var tail = this.tail
  node.list = this
  node.prev = tail
  if (tail) {
    tail.next = node
  }

  this.tail = node
  if (!this.head) {
    this.head = node
  }
  this.length++
}

Yallist.prototype.push = function () {
  for (var i = 0, l = arguments.length; i < l; i++) {
    push(this, arguments[i])
  }
  return this.length
}

Yallist.prototype.unshift = function () {
  for (var i = 0, l = arguments.length; i < l; i++) {
    unshift(this, arguments[i])
  }
  return this.length
}

Yallist.prototype.pop = function () {
  if (!this.tail) {
    return undefined
  }

  var res = this.tail.value
  this.tail = this.tail.prev
  if (this.tail) {
    this.tail.next = null
  } else {
    this.head = null
  }
  this.length--
  return res
}

Yallist.prototype.shift = function () {
  if (!this.head) {
    return undefined
  }

  var res = this.head.value
  this.head = this.head.next
  if (this.head) {
    this.head.prev = null
  } else {
    this.tail = null
  }
  this.length--
  return res
}

Yallist.prototype.forEach = function (fn, thisp) {
  thisp = thisp || this
  for (var walker = this.head, i = 0; walker !== null; i++) {
    fn.call(thisp, walker.value, i, this)
    walker = walker.next
  }
}

Yallist.prototype.forEachReverse = function (fn, thisp) {
  thisp = thisp || this
  for (var walker = this.tail, i = this.length - 1; walker !== null; i--) {
    fn.call(thisp, walker.value, i, this)
    walker = walker.prev
  }
}

Yallist.prototype.get = function (n) {
  for (var i = 0, walker = this.head; walker !== null && i < n; i++) {
    // abort out of the list early if we hit a cycle
    walker = walker.next
  }
  if (i === n && walker !== null) {
    return walker.value
  }
}

Yallist.prototype.getReverse = function (n) {
  for (var i = 0, walker = this.tail; walker !== null && i < n; i++) {
    // abort out of the list early if we hit a cycle
    walker = walker.prev
  }
  if (i === n && walker !== null) {
    return walker.value
  }
}

Yallist.prototype.map = function (fn, thisp) {
  thisp = thisp || this
  var res = new Yallist()
  for (var walker = this.head; walker !== null;) {
    res.push(fn.call(thisp, walker.value, this))
    walker = walker.next
  }
  return res
}

Yallist.prototype.mapReverse = function (fn, thisp) {
  thisp = thisp || this
  var res = new Yallist()
  for (var walker = this.tail; walker !== null;) {
    res.push(fn.call(thisp, walker.value, this))
    walker = walker.prev
  }
  return res
}

Yallist.prototype.reduce = function (fn, initial) {
  var acc
  var walker = this.head
  if (arguments.length > 1) {
    acc = initial
  } else if (this.head) {
    walker = this.head.next
    acc = this.head.value
  } else {
    throw new TypeError('Reduce of empty list with no initial value')
  }

  for (var i = 0; walker !== null; i++) {
    acc = fn(acc, walker.value, i)
    walker = walker.next
  }

  return acc
}

Yallist.prototype.reduceReverse = function (fn, initial) {
  var acc
  var walker = this.tail
  if (arguments.length > 1) {
    acc = initial
  } else if (this.tail) {
    walker = this.tail.prev
    acc = this.tail.value
  } else {
    throw new TypeError('Reduce of empty list with no initial value')
  }

  for (var i = this.length - 1; walker !== null; i--) {
    acc = fn(acc, walker.value, i)
    walker = walker.prev
  }

  return acc
}

Yallist.prototype.toArray = function () {
  var arr = new Array(this.length)
  for (var i = 0, walker = this.head; walker !== null; i++) {
    arr[i] = walker.value
    walker = walker.next
  }
  return arr
}

Yallist.prototype.toArrayReverse = function () {
  var arr = new Array(this.length)
  for (var i = 0, walker = this.tail; walker !== null; i++) {
    arr[i] = walker.value
    walker = walker.prev
  }
  return arr
}

Yallist.prototype.slice = function (from, to) {
  to = to || this.length
  if (to < 0) {
    to += this.length
  }
  from = from || 0
  if (from < 0) {
    from += this.length
  }
  var ret = new Yallist()
  if (to < from || to < 0) {
    return ret
  }
  if (from < 0) {
    from = 0
  }
  if (to > this.length) {
    to = this.length
  }
  for (var i = 0, walker = this.head; walker !== null && i < from; i++) {
    walker = walker.next
  }
  for (; walker !== null && i < to; i++, walker = walker.next) {
    ret.push(walker.value)
  }
  return ret
}

Yallist.prototype.sliceReverse = function (from, to) {
  to = to || this.length
  if (to < 0) {
    to += this.length
  }
  from = from || 0
  if (from < 0) {
    from += this.length
  }
  var ret = new Yallist()
  if (to < from || to < 0) {
    return ret
  }
  if (from < 0) {
    from = 0
  }
  if (to > this.length) {
    to = this.length
  }
  for (var i = this.length, walker = this.tail; walker !== null && i > to; i--) {
    walker = walker.prev
  }
  for (; walker !== null && i > from; i--, walker = walker.prev) {
    ret.push(walker.value)
  }
  return ret
}

Yallist.prototype.splice = function (start, deleteCount, ...nodes) {
  if (start > this.length) {
    start = this.length - 1
  }
  if (start < 0) {
    start = this.length + start;
  }

  for (var i = 0, walker = this.head; walker !== null && i < start; i++) {
    walker = walker.next
  }

  var ret = []
  for (var i = 0; walker && i < deleteCount; i++) {
    ret.push(walker.value)
    walker = this.removeNode(walker)
  }
  if (walker === null) {
    walker = this.tail
  }

  if (walker !== this.head && walker !== this.tail) {
    walker = walker.prev
  }

  for (var i = 0; i < nodes.length; i++) {
    walker = insert(this, walker, nodes[i])
  }
  return ret;
}

Yallist.prototype.reverse = function () {
  var head = this.head
  var tail = this.tail
  for (var walker = head; walker !== null; walker = walker.prev) {
    var p = walker.prev
    walker.prev = walker.next
    walker.next = p
  }
  this.head = tail
  this.tail = head
  return this
}

function insert (self, node, value) {
  var inserted = node === self.head ?
    new Node(value, null, node, self) :
    new Node(value, node, node.next, self)

  if (inserted.next === null) {
    self.tail = inserted
  }
  if (inserted.prev === null) {
    self.head = inserted
  }

  self.length++

  return inserted
}

function push (self, item) {
  self.tail = new Node(item, self.tail, null, self)
  if (!self.head) {
    self.head = self.tail
  }
  self.length++
}

function unshift (self, item) {
  self.head = new Node(item, null, self.head, self)
  if (!self.tail) {
    self.tail = self.head
  }
  self.length++
}

function Node (value, prev, next, list) {
  if (!(this instanceof Node)) {
    return new Node(value, prev, next, list)
  }

  this.list = list
  this.value = value

  if (prev) {
    prev.next = this
    this.prev = prev
  } else {
    this.prev = null
  }

  if (next) {
    next.prev = this
    this.next = next
  } else {
    this.next = null
  }
}

try {
  // add if support for Symbol.iterator is present
  __webpack_require__(/*! ./iterator.js */ "./node_modules/semver/node_modules/yallist/iterator.js")(Yallist)
} catch (er) {}


/***/ }),

/***/ "./node_modules/semver/ranges/gtr.js":
/*!*******************************************!*\
  !*** ./node_modules/semver/ranges/gtr.js ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Determine if version is greater than all the versions possible in the range.
const outside = __webpack_require__(/*! ./outside */ "./node_modules/semver/ranges/outside.js")
const gtr = (version, range, options) => outside(version, range, '>', options)
module.exports = gtr


/***/ }),

/***/ "./node_modules/semver/ranges/intersects.js":
/*!**************************************************!*\
  !*** ./node_modules/semver/ranges/intersects.js ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

const Range = __webpack_require__(/*! ../classes/range */ "./node_modules/semver/classes/range.js")
const intersects = (r1, r2, options) => {
  r1 = new Range(r1, options)
  r2 = new Range(r2, options)
  return r1.intersects(r2)
}
module.exports = intersects


/***/ }),

/***/ "./node_modules/semver/ranges/ltr.js":
/*!*******************************************!*\
  !*** ./node_modules/semver/ranges/ltr.js ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

const outside = __webpack_require__(/*! ./outside */ "./node_modules/semver/ranges/outside.js")
// Determine if version is less than all the versions possible in the range
const ltr = (version, range, options) => outside(version, range, '<', options)
module.exports = ltr


/***/ }),

/***/ "./node_modules/semver/ranges/max-satisfying.js":
/*!******************************************************!*\
  !*** ./node_modules/semver/ranges/max-satisfying.js ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

const SemVer = __webpack_require__(/*! ../classes/semver */ "./node_modules/semver/classes/semver.js")
const Range = __webpack_require__(/*! ../classes/range */ "./node_modules/semver/classes/range.js")

const maxSatisfying = (versions, range, options) => {
  let max = null
  let maxSV = null
  let rangeObj = null
  try {
    rangeObj = new Range(range, options)
  } catch (er) {
    return null
  }
  versions.forEach((v) => {
    if (rangeObj.test(v)) {
      // satisfies(v, range, options)
      if (!max || maxSV.compare(v) === -1) {
        // compare(max, v, true)
        max = v
        maxSV = new SemVer(max, options)
      }
    }
  })
  return max
}
module.exports = maxSatisfying


/***/ }),

/***/ "./node_modules/semver/ranges/min-satisfying.js":
/*!******************************************************!*\
  !*** ./node_modules/semver/ranges/min-satisfying.js ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

const SemVer = __webpack_require__(/*! ../classes/semver */ "./node_modules/semver/classes/semver.js")
const Range = __webpack_require__(/*! ../classes/range */ "./node_modules/semver/classes/range.js")
const minSatisfying = (versions, range, options) => {
  let min = null
  let minSV = null
  let rangeObj = null
  try {
    rangeObj = new Range(range, options)
  } catch (er) {
    return null
  }
  versions.forEach((v) => {
    if (rangeObj.test(v)) {
      // satisfies(v, range, options)
      if (!min || minSV.compare(v) === 1) {
        // compare(min, v, true)
        min = v
        minSV = new SemVer(min, options)
      }
    }
  })
  return min
}
module.exports = minSatisfying


/***/ }),

/***/ "./node_modules/semver/ranges/min-version.js":
/*!***************************************************!*\
  !*** ./node_modules/semver/ranges/min-version.js ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

const SemVer = __webpack_require__(/*! ../classes/semver */ "./node_modules/semver/classes/semver.js")
const Range = __webpack_require__(/*! ../classes/range */ "./node_modules/semver/classes/range.js")
const gt = __webpack_require__(/*! ../functions/gt */ "./node_modules/semver/functions/gt.js")

const minVersion = (range, loose) => {
  range = new Range(range, loose)

  let minver = new SemVer('0.0.0')
  if (range.test(minver)) {
    return minver
  }

  minver = new SemVer('0.0.0-0')
  if (range.test(minver)) {
    return minver
  }

  minver = null
  for (let i = 0; i < range.set.length; ++i) {
    const comparators = range.set[i]

    let setMin = null
    comparators.forEach((comparator) => {
      // Clone to avoid manipulating the comparator's semver object.
      const compver = new SemVer(comparator.semver.version)
      switch (comparator.operator) {
        case '>':
          if (compver.prerelease.length === 0) {
            compver.patch++
          } else {
            compver.prerelease.push(0)
          }
          compver.raw = compver.format()
          /* fallthrough */
        case '':
        case '>=':
          if (!setMin || gt(compver, setMin)) {
            setMin = compver
          }
          break
        case '<':
        case '<=':
          /* Ignore maximum versions */
          break
        /* istanbul ignore next */
        default:
          throw new Error(`Unexpected operation: ${comparator.operator}`)
      }
    })
    if (setMin && (!minver || gt(minver, setMin)))
      minver = setMin
  }

  if (minver && range.test(minver)) {
    return minver
  }

  return null
}
module.exports = minVersion


/***/ }),

/***/ "./node_modules/semver/ranges/outside.js":
/*!***********************************************!*\
  !*** ./node_modules/semver/ranges/outside.js ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

const SemVer = __webpack_require__(/*! ../classes/semver */ "./node_modules/semver/classes/semver.js")
const Comparator = __webpack_require__(/*! ../classes/comparator */ "./node_modules/semver/classes/comparator.js")
const {ANY} = Comparator
const Range = __webpack_require__(/*! ../classes/range */ "./node_modules/semver/classes/range.js")
const satisfies = __webpack_require__(/*! ../functions/satisfies */ "./node_modules/semver/functions/satisfies.js")
const gt = __webpack_require__(/*! ../functions/gt */ "./node_modules/semver/functions/gt.js")
const lt = __webpack_require__(/*! ../functions/lt */ "./node_modules/semver/functions/lt.js")
const lte = __webpack_require__(/*! ../functions/lte */ "./node_modules/semver/functions/lte.js")
const gte = __webpack_require__(/*! ../functions/gte */ "./node_modules/semver/functions/gte.js")

const outside = (version, range, hilo, options) => {
  version = new SemVer(version, options)
  range = new Range(range, options)

  let gtfn, ltefn, ltfn, comp, ecomp
  switch (hilo) {
    case '>':
      gtfn = gt
      ltefn = lte
      ltfn = lt
      comp = '>'
      ecomp = '>='
      break
    case '<':
      gtfn = lt
      ltefn = gte
      ltfn = gt
      comp = '<'
      ecomp = '<='
      break
    default:
      throw new TypeError('Must provide a hilo val of "<" or ">"')
  }

  // If it satisfies the range it is not outside
  if (satisfies(version, range, options)) {
    return false
  }

  // From now on, variable terms are as if we're in "gtr" mode.
  // but note that everything is flipped for the "ltr" function.

  for (let i = 0; i < range.set.length; ++i) {
    const comparators = range.set[i]

    let high = null
    let low = null

    comparators.forEach((comparator) => {
      if (comparator.semver === ANY) {
        comparator = new Comparator('>=0.0.0')
      }
      high = high || comparator
      low = low || comparator
      if (gtfn(comparator.semver, high.semver, options)) {
        high = comparator
      } else if (ltfn(comparator.semver, low.semver, options)) {
        low = comparator
      }
    })

    // If the edge version comparator has a operator then our version
    // isn't outside it
    if (high.operator === comp || high.operator === ecomp) {
      return false
    }

    // If the lowest version comparator has an operator and our version
    // is less than it then it isn't higher than the range
    if ((!low.operator || low.operator === comp) &&
        ltefn(version, low.semver)) {
      return false
    } else if (low.operator === ecomp && ltfn(version, low.semver)) {
      return false
    }
  }
  return true
}

module.exports = outside


/***/ }),

/***/ "./node_modules/semver/ranges/simplify.js":
/*!************************************************!*\
  !*** ./node_modules/semver/ranges/simplify.js ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// given a set of versions and a range, create a "simplified" range
// that includes the same versions that the original range does
// If the original range is shorter than the simplified one, return that.
const satisfies = __webpack_require__(/*! ../functions/satisfies.js */ "./node_modules/semver/functions/satisfies.js")
const compare = __webpack_require__(/*! ../functions/compare.js */ "./node_modules/semver/functions/compare.js")
module.exports = (versions, range, options) => {
  const set = []
  let min = null
  let prev = null
  const v = versions.sort((a, b) => compare(a, b, options))
  for (const version of v) {
    const included = satisfies(version, range, options)
    if (included) {
      prev = version
      if (!min)
        min = version
    } else {
      if (prev) {
        set.push([min, prev])
      }
      prev = null
      min = null
    }
  }
  if (min)
    set.push([min, null])

  const ranges = []
  for (const [min, max] of set) {
    if (min === max)
      ranges.push(min)
    else if (!max && min === v[0])
      ranges.push('*')
    else if (!max)
      ranges.push(`>=${min}`)
    else if (min === v[0])
      ranges.push(`<=${max}`)
    else
      ranges.push(`${min} - ${max}`)
  }
  const simplified = ranges.join(' || ')
  const original = typeof range.raw === 'string' ? range.raw : String(range)
  return simplified.length < original.length ? simplified : range
}


/***/ }),

/***/ "./node_modules/semver/ranges/subset.js":
/*!**********************************************!*\
  !*** ./node_modules/semver/ranges/subset.js ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

const Range = __webpack_require__(/*! ../classes/range.js */ "./node_modules/semver/classes/range.js")
const { ANY } = __webpack_require__(/*! ../classes/comparator.js */ "./node_modules/semver/classes/comparator.js")
const satisfies = __webpack_require__(/*! ../functions/satisfies.js */ "./node_modules/semver/functions/satisfies.js")
const compare = __webpack_require__(/*! ../functions/compare.js */ "./node_modules/semver/functions/compare.js")

// Complex range `r1 || r2 || ...` is a subset of `R1 || R2 || ...` iff:
// - Every simple range `r1, r2, ...` is a subset of some `R1, R2, ...`
//
// Simple range `c1 c2 ...` is a subset of simple range `C1 C2 ...` iff:
// - If c is only the ANY comparator
//   - If C is only the ANY comparator, return true
//   - Else return false
// - Let EQ be the set of = comparators in c
// - If EQ is more than one, return true (null set)
// - Let GT be the highest > or >= comparator in c
// - Let LT be the lowest < or <= comparator in c
// - If GT and LT, and GT.semver > LT.semver, return true (null set)
// - If EQ
//   - If GT, and EQ does not satisfy GT, return true (null set)
//   - If LT, and EQ does not satisfy LT, return true (null set)
//   - If EQ satisfies every C, return true
//   - Else return false
// - If GT
//   - If GT.semver is lower than any > or >= comp in C, return false
//   - If GT is >=, and GT.semver does not satisfy every C, return false
// - If LT
//   - If LT.semver is greater than any < or <= comp in C, return false
//   - If LT is <=, and LT.semver does not satisfy every C, return false
// - If any C is a = range, and GT or LT are set, return false
// - Else return true

const subset = (sub, dom, options) => {
  if (sub === dom)
    return true

  sub = new Range(sub, options)
  dom = new Range(dom, options)
  let sawNonNull = false

  OUTER: for (const simpleSub of sub.set) {
    for (const simpleDom of dom.set) {
      const isSub = simpleSubset(simpleSub, simpleDom, options)
      sawNonNull = sawNonNull || isSub !== null
      if (isSub)
        continue OUTER
    }
    // the null set is a subset of everything, but null simple ranges in
    // a complex range should be ignored.  so if we saw a non-null range,
    // then we know this isn't a subset, but if EVERY simple range was null,
    // then it is a subset.
    if (sawNonNull)
      return false
  }
  return true
}

const simpleSubset = (sub, dom, options) => {
  if (sub === dom)
    return true

  if (sub.length === 1 && sub[0].semver === ANY)
    return dom.length === 1 && dom[0].semver === ANY

  const eqSet = new Set()
  let gt, lt
  for (const c of sub) {
    if (c.operator === '>' || c.operator === '>=')
      gt = higherGT(gt, c, options)
    else if (c.operator === '<' || c.operator === '<=')
      lt = lowerLT(lt, c, options)
    else
      eqSet.add(c.semver)
  }

  if (eqSet.size > 1)
    return null

  let gtltComp
  if (gt && lt) {
    gtltComp = compare(gt.semver, lt.semver, options)
    if (gtltComp > 0)
      return null
    else if (gtltComp === 0 && (gt.operator !== '>=' || lt.operator !== '<='))
      return null
  }

  // will iterate one or zero times
  for (const eq of eqSet) {
    if (gt && !satisfies(eq, String(gt), options))
      return null

    if (lt && !satisfies(eq, String(lt), options))
      return null

    for (const c of dom) {
      if (!satisfies(eq, String(c), options))
        return false
    }

    return true
  }

  let higher, lower
  let hasDomLT, hasDomGT
  for (const c of dom) {
    hasDomGT = hasDomGT || c.operator === '>' || c.operator === '>='
    hasDomLT = hasDomLT || c.operator === '<' || c.operator === '<='
    if (gt) {
      if (c.operator === '>' || c.operator === '>=') {
        higher = higherGT(gt, c, options)
        if (higher === c && higher !== gt)
          return false
      } else if (gt.operator === '>=' && !satisfies(gt.semver, String(c), options))
        return false
    }
    if (lt) {
      if (c.operator === '<' || c.operator === '<=') {
        lower = lowerLT(lt, c, options)
        if (lower === c && lower !== lt)
          return false
      } else if (lt.operator === '<=' && !satisfies(lt.semver, String(c), options))
        return false
    }
    if (!c.operator && (lt || gt) && gtltComp !== 0)
      return false
  }

  // if there was a < or >, and nothing in the dom, then must be false
  // UNLESS it was limited by another range in the other direction.
  // Eg, >1.0.0 <1.0.1 is still a subset of <2.0.0
  if (gt && hasDomLT && !lt && gtltComp !== 0)
    return false

  if (lt && hasDomGT && !gt && gtltComp !== 0)
    return false

  return true
}

// >=1.2.3 is lower than >1.2.3
const higherGT = (a, b, options) => {
  if (!a)
    return b
  const comp = compare(a.semver, b.semver, options)
  return comp > 0 ? a
    : comp < 0 ? b
    : b.operator === '>' && a.operator === '>=' ? b
    : a
}

// <=1.2.3 is higher than <1.2.3
const lowerLT = (a, b, options) => {
  if (!a)
    return b
  const comp = compare(a.semver, b.semver, options)
  return comp < 0 ? a
    : comp > 0 ? b
    : b.operator === '<' && a.operator === '<=' ? b
    : a
}

module.exports = subset


/***/ }),

/***/ "./node_modules/semver/ranges/to-comparators.js":
/*!******************************************************!*\
  !*** ./node_modules/semver/ranges/to-comparators.js ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

const Range = __webpack_require__(/*! ../classes/range */ "./node_modules/semver/classes/range.js")

// Mostly just for testing and legacy API reasons
const toComparators = (range, options) =>
  new Range(range, options).set
    .map(comp => comp.map(c => c.value).join(' ').trim().split(' '))

module.exports = toComparators


/***/ }),

/***/ "./node_modules/semver/ranges/valid.js":
/*!*********************************************!*\
  !*** ./node_modules/semver/ranges/valid.js ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

const Range = __webpack_require__(/*! ../classes/range */ "./node_modules/semver/classes/range.js")
const validRange = (range, options) => {
  try {
    // Return '*' instead of '' so that truthiness works.
    // This will throw if it's invalid anyway
    return new Range(range, options).range || '*'
  } catch (er) {
    return null
  }
}
module.exports = validRange


/***/ }),

/***/ "./src/export.js":
/*!***********************!*\
  !*** ./src/export.js ***!
  \***********************/
/*! exports provided: exportArtboards, animaPluginDetection, runPluginCommandWithIdentifier, isFrameworkVersionSameAsJS */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(Promise, fetch, FormData) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "exportArtboards", function() { return exportArtboards; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "animaPluginDetection", function() { return animaPluginDetection; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "runPluginCommandWithIdentifier", function() { return runPluginCommandWithIdentifier; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isFrameworkVersionSameAsJS", function() { return isFrameworkVersionSameAsJS; });
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/asyncToGenerator */ "./node_modules/@babel/runtime/helpers/asyncToGenerator.js");
/* harmony import */ var _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var sketch__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! sketch */ "sketch");
/* harmony import */ var sketch__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(sketch__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var sketch_async__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! sketch/async */ "sketch/async");
/* harmony import */ var sketch_async__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(sketch_async__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _skpm_console__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @skpm/console */ "./node_modules/@skpm/console/index.js");
/* harmony import */ var _skpm_console__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_skpm_console__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _helpers_Helper__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./helpers/Helper */ "./src/helpers/Helper.js");
/* harmony import */ var _manifest_json__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./manifest.json */ "./src/manifest.json");
var _manifest_json__WEBPACK_IMPORTED_MODULE_6___namespace = /*#__PURE__*/__webpack_require__.t(/*! ./manifest.json */ "./src/manifest.json", 1);
/* harmony import */ var _helpers_ArtboardHelper__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./helpers/ArtboardHelper */ "./src/helpers/ArtboardHelper.js");
/* harmony import */ var _helpers_UIHelper__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./helpers/UIHelper */ "./src/helpers/UIHelper.js");
/* harmony import */ var _helpers_DocumentSettingsHelper__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./helpers/DocumentSettingsHelper */ "./src/helpers/DocumentSettingsHelper.js");



function _createForOfIteratorHelper(o, allowArrayLike) { var it; if (typeof Symbol === "undefined" || o[Symbol.iterator] == null) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = o[Symbol.iterator](); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it.return != null) it.return(); } finally { if (didErr) throw err; } } }; }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }









var console = _skpm_console__WEBPACK_IMPORTED_MODULE_4___default()();
var OVERFLOW_URL = 'http://127.0.0.1';
var PLUGIN_NAME = 'sketch';
var APP_BUNDLE_ID = 'io.overflow.mac.app';
var exportArtboards = /*#__PURE__*/function () {
  var _ref = _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1___default()( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee(context, selectedDocument, currentPage, selectedArtboards) {
    var docUuid, syncPath, exportOptions, selectedArtboardsObjects, isOperationCancelled, window, fiber, NibUI, nib, alert, cancelButton, handleReturnCode, overflowParsedResponse, overflowUrl, currentSelectedArtboardsCount, currentIteration, progressBar, progressMsg, createArtboardObjectPromise, _iterator, _step, artboard;

    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            handleReturnCode = function _handleReturnCode(returnCode) {
              if (returnCode == NSAlertFirstButtonReturn) {
                isOperationCancelled = true;
                console.log("Cancel");
              }
            };

            docUuid = _helpers_DocumentSettingsHelper__WEBPACK_IMPORTED_MODULE_9__["default"].ensureDocUuid(selectedDocument);
            syncPath = _helpers_Helper__WEBPACK_IMPORTED_MODULE_5__["default"].createSyncDirectory(docUuid);
            exportOptions = _helpers_DocumentSettingsHelper__WEBPACK_IMPORTED_MODULE_9__["default"].ensureDocExportOptions(selectedDocument);
            console.log(syncPath);
            selectedArtboardsObjects = [];
            isOperationCancelled = false;
            window = context.document.window();
            fiber = sketch_async__WEBPACK_IMPORTED_MODULE_3___default.a.createFiber();
            NibUI = __webpack_require__(/*! ./nib-views/LoadingBar.xib */ "./src/nib-views/LoadingBar.xib");
            nib = NibUI();
            alert = NSAlert.alloc().init();
            alert.addButtonWithTitle("Cancel");
            alert.setMessageText("");
            cancelButton = alert.buttons().objectAtIndex(0);
            cancelButton.hidden = true;
            alert.messageText.hidden = true;
            alert.informativeText.hidden = true;
            alert.setIcon(context.plugin.iconInfo().image());
            alert.setAccessoryView(nib.getRoot());
            alert.setAlertStyle(NSAlertStyleWarning);
            alert.beginSheetModalForWindow_completionHandler(window, __mocha__.createBlock_function('v16@?0q8', function (returnCode) {
              try {
                handleReturnCode(returnCode);
              } catch (err) {
                console.error(err);
              }

              NSApp.endSheet(alert);

              if (fiber) {
                fiber.cleanup();
              }
            }));
            nib.progressMsg.stringValue = 'Establishing Connection';
            _context.next = 25;
            return detectOverflowApp(context, alert);

          case 25:
            overflowParsedResponse = _context.sent;

            if (!(overflowParsedResponse === null)) {
              _context.next = 29;
              break;
            }

            fiber.cleanup();
            return _context.abrupt("return");

          case 29:
            overflowUrl = overflowParsedResponse.overflowUrl;
            currentSelectedArtboardsCount = selectedArtboards.length;
            currentIteration = 1;

            progressBar = function progressBar(currentIterationNow) {
              return new Promise(function (resolve, reject) {
                try {
                  nib.progressBar.doubleValue = currentIterationNow / currentSelectedArtboardsCount * 0.9 * 100;
                  resolve();
                } catch (e) {
                  reject();
                }
              });
            };

            progressMsg = function progressMsg(msg) {
              return new Promise(function (resolve, reject) {
                try {
                  nib.progressMsg.stringValue = msg;
                  resolve();
                } catch (e) {
                  reject();
                }
              });
            };

            createArtboardObjectPromise = function createArtboardObjectPromise(artboard) {
              return new Promise(function (resolve, reject) {
                try {
                  selectedArtboardsObjects.push(_helpers_ArtboardHelper__WEBPACK_IMPORTED_MODULE_7__["default"].createArtboardObject(artboard, selectedDocument, exportOptions.includeLinks));
                  resolve();
                } catch (e) {
                  reject();
                }
              });
            };

            _context.prev = 35;
            _iterator = _createForOfIteratorHelper(selectedArtboards);
            _context.prev = 37;

            _iterator.s();

          case 39:
            if ((_step = _iterator.n()).done) {
              _context.next = 55;
              break;
            }

            artboard = _step.value;

            if (!isOperationCancelled) {
              _context.next = 43;
              break;
            }

            return _context.abrupt("return");

          case 43:
            _context.next = 45;
            return progressMsg('Exporting ' + artboard.name);

          case 45:
            _context.next = 47;
            return createArtboardObjectPromise(artboard);

          case 47:
            _context.next = 49;
            return progressBar(currentIteration);

          case 49:
            if (!isOperationCancelled) {
              _context.next = 51;
              break;
            }

            return _context.abrupt("return");

          case 51:
            _helpers_ArtboardHelper__WEBPACK_IMPORTED_MODULE_7__["default"].exportArtboardImage(artboard, syncPath, exportOptions.exportSize);
            currentIteration++;

          case 53:
            _context.next = 39;
            break;

          case 55:
            _context.next = 60;
            break;

          case 57:
            _context.prev = 57;
            _context.t0 = _context["catch"](37);

            _iterator.e(_context.t0);

          case 60:
            _context.prev = 60;

            _iterator.f();

            return _context.finish(60);

          case 63:
            _context.next = 71;
            break;

          case 65:
            _context.prev = 65;
            _context.t1 = _context["catch"](35);
            NSApp.endSheet(alert.window());
            fiber.cleanup();
            _helpers_UIHelper__WEBPACK_IMPORTED_MODULE_8__["default"].showErrorParsingFailed(context);
            return _context.abrupt("return");

          case 71:
            if (!isOperationCancelled) {
              _context.next = 75;
              break;
            }

            NSApp.endSheet(alert.window());
            fiber.cleanup();
            return _context.abrupt("return");

          case 75:
            nib.progressMsg.stringValue = 'Sending data to Overflow';
            nib.progressBar.doubleValue = 90;
            _context.prev = 77;
            _context.next = 80;
            return sendDataToOverflow(overflowUrl, currentPage, selectedArtboardsObjects, syncPath, exportOptions);

          case 80:
            _context.next = 88;
            break;

          case 82:
            _context.prev = 82;
            _context.t2 = _context["catch"](77);
            NSApp.endSheet(alert.window());
            fiber.cleanup();
            _helpers_UIHelper__WEBPACK_IMPORTED_MODULE_8__["default"].showErrorParsingFailed(context);
            return _context.abrupt("return");

          case 88:
            nib.progressBar.doubleValue = 100;
            NSApp.endSheet(alert.window());
            fiber.cleanup();

          case 91:
          case "end":
            return _context.stop();
        }
      }
    }, _callee, null, [[35, 65], [37, 57, 60, 63], [77, 82]]);
  }));

  return function exportArtboards(_x, _x2, _x3, _x4) {
    return _ref.apply(this, arguments);
  };
}();

function detectOverflowApp(_x5, _x6) {
  return _detectOverflowApp.apply(this, arguments);
}

function _detectOverflowApp() {
  _detectOverflowApp = _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1___default()( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee2(context, alert) {
    var overflowResponse, appExists, wait, overflowParsedResponse, isAppCompatibleWithPlugin;
    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _context2.next = 2;
            return detectOverflowAddress();

          case 2:
            overflowResponse = _context2.sent;

            if (!(overflowResponse === null)) {
              _context2.next = 11;
              break;
            }

            appExists = showAppNotInstalled(context);

            if (appExists) {
              _context2.next = 8;
              break;
            }

            NSApp.endSheet(alert.window());
            return _context2.abrupt("return", null);

          case 8:
            // delay until overflow is opened
            wait = function wait() {
              return new Promise(function (resolve) {
                setTimeout(function () {
                  resolve();
                }, 3000);
              });
            };

            _context2.next = 11;
            return wait();

          case 11:
            _context2.next = 13;
            return detectOverflowAddress();

          case 13:
            overflowResponse = _context2.sent;

            if (!(overflowResponse === null)) {
              _context2.next = 18;
              break;
            }

            NSApp.endSheet(alert.window());
            _helpers_UIHelper__WEBPACK_IMPORTED_MODULE_8__["default"].showErrorOverflowNotOpened(context);
            return _context2.abrupt("return", null);

          case 18:
            overflowParsedResponse = _helpers_Helper__WEBPACK_IMPORTED_MODULE_5__["default"].parseOverflowPingResponse(overflowResponse);
            isAppCompatibleWithPlugin = _helpers_Helper__WEBPACK_IMPORTED_MODULE_5__["default"].appVersionCompatible(overflowParsedResponse.overflowResponse, _manifest_json__WEBPACK_IMPORTED_MODULE_6__.overflow.overflowAppMinVersion, _manifest_json__WEBPACK_IMPORTED_MODULE_6__.overflow.appName);

            if (isAppCompatibleWithPlugin) {
              _context2.next = 24;
              break;
            }

            NSApp.endSheet(alert.window());
            _helpers_UIHelper__WEBPACK_IMPORTED_MODULE_8__["default"].showErrorOverflowNotCompatible(context);
            return _context2.abrupt("return", null);

          case 24:
            return _context2.abrupt("return", overflowParsedResponse);

          case 25:
          case "end":
            return _context2.stop();
        }
      }
    }, _callee2);
  }));
  return _detectOverflowApp.apply(this, arguments);
}

function detectOverflowAddress() {
  return _detectOverflowAddress.apply(this, arguments);
}

function _detectOverflowAddress() {
  _detectOverflowAddress = _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1___default()( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee3() {
    var portRange, i;
    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            portRange = _helpers_Helper__WEBPACK_IMPORTED_MODULE_5__["default"].getPortsRange();
            i = 0;

          case 2:
            if (!(i < portRange.length)) {
              _context3.next = 14;
              break;
            }

            _context3.prev = 3;
            _context3.next = 6;
            return Promise.all(portRange[i].map(function (port) {
              return isOverflow(port);
            }));

          case 6:
            _context3.next = 11;
            break;

          case 8:
            _context3.prev = 8;
            _context3.t0 = _context3["catch"](3);
            return _context3.abrupt("return", _context3.t0.message);

          case 11:
            i++;
            _context3.next = 2;
            break;

          case 14:
            return _context3.abrupt("return", null);

          case 15:
          case "end":
            return _context3.stop();
        }
      }
    }, _callee3, null, [[3, 8]]);
  }));
  return _detectOverflowAddress.apply(this, arguments);
}

function isOverflow(_x7) {
  return _isOverflow.apply(this, arguments);
}

function _isOverflow() {
  _isOverflow = _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1___default()( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee4(port) {
    var urlWithoutPath, json, response, responseJson;
    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            urlWithoutPath = "".concat(OVERFLOW_URL, ":").concat(port);
            json = {};
            _context4.prev = 2;
            _context4.next = 5;
            return fetch("".concat(OVERFLOW_URL, ":").concat(port, "/ping?plugin=").concat(PLUGIN_NAME));

          case 5:
            response = _context4.sent;
            _context4.next = 8;
            return response.json();

          case 8:
            json = _context4.sent;
            console.log(json);
            _context4.next = 16;
            break;

          case 12:
            _context4.prev = 12;
            _context4.t0 = _context4["catch"](2);
            console.log(_context4.t0);
            return _context4.abrupt("return", null);

          case 16:
            responseJson = {
              overflowUrl: "".concat(urlWithoutPath, "/sync"),
              overflowResponse: json
            };
            throw new Error("".concat(JSON.stringify(responseJson)));

          case 18:
          case "end":
            return _context4.stop();
        }
      }
    }, _callee4, null, [[2, 12]]);
  }));
  return _isOverflow.apply(this, arguments);
}

function sendDataToOverflow(_x8, _x9, _x10, _x11, _x12) {
  return _sendDataToOverflow.apply(this, arguments);
}

function _sendDataToOverflow() {
  _sendDataToOverflow = _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1___default()( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee5(overflowUrl, currentPage, selectedArtboardsObjects, syncPath, exportOptions) {
    var dataToBeSent, formData;
    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee5$(_context5) {
      while (1) {
        switch (_context5.prev = _context5.next) {
          case 0:
            dataToBeSent = {
              info: {
                about: "Overflow.io Sketch Export",
                toolVersion: sketch__WEBPACK_IMPORTED_MODULE_2___default.a.version.sketch + '',
                version: _manifest_json__WEBPACK_IMPORTED_MODULE_6__.version,
                syncId: _helpers_Helper__WEBPACK_IMPORTED_MODULE_5__["default"].uuidv4(),
                tempPath: syncPath,
                flows: exportOptions.includeLinks,
                density: exportOptions.exportSize
              },
              pages: [{
                name: currentPage.name,
                screens: selectedArtboardsObjects
              }]
            };
            formData = new FormData();
            formData.append('doc', JSON.stringify(dataToBeSent));
            formData.append('path', syncPath);
            formData.append('integrationType', PLUGIN_NAME);
            _context5.prev = 5;
            _context5.next = 8;
            return fetch(overflowUrl, {
              method: 'POST',
              body: formData
            });

          case 8:
            _context5.next = 14;
            break;

          case 10:
            _context5.prev = 10;
            _context5.t0 = _context5["catch"](5);
            console.log(_context5.t0);
            throw _context5.t0;

          case 14:
          case "end":
            return _context5.stop();
        }
      }
    }, _callee5, null, [[5, 10]]);
  }));
  return _sendDataToOverflow.apply(this, arguments);
}

function showAppNotInstalled(context) {
  var workspace = NSWorkspace.sharedWorkspace();
  var bundleId = APP_BUNDLE_ID;
  var applicationPath = workspace.absolutePathForAppBundleWithIdentifier(bundleId);

  if (!applicationPath) {
    _helpers_UIHelper__WEBPACK_IMPORTED_MODULE_8__["default"].showErrorOverflowAppNotInstalled(context);
    return false;
  }

  workspace.openFile_withApplication_andDeactivate(null, applicationPath, true);
  return true;
}

var animaPluginDetection = function animaPluginDetection(context) {
  var appMenu = NSApp.mainMenu();
  var sketchTotalMenus = NSApplication.sharedApplication().mainMenu().numberOfItems();
  var animaPrepareExportIndex = -1;
  var animaMenu;

  for (var i = 0; i < sketchTotalMenus; i++) {
    var pluginsMenuParent = appMenu.itemAtIndex(i);
    var pluginsMenu = pluginsMenuParent.submenu();

    for (var _i = 0; _i < pluginsMenu.itemArray().length; _i++) {
      var pluginsMenuItem = pluginsMenu.itemAtIndex(_i);
      var title = String(pluginsMenuItem.title());

      if (title.toLowerCase().includes('anima toolkit')) {
        animaMenu = pluginsMenuItem.submenu();

        for (var j = 0; j < animaMenu.itemArray().length; j++) {
          var subMenuTitle = animaMenu.itemAtIndex(j).title();

          if (subMenuTitle.toLowerCase().includes('prepare export')) {
            animaPrepareExportIndex = j;
            console.log('Prepare export at ' + animaPrepareExportIndex);
            break;
          }
        }
      }

      if (animaPrepareExportIndex !== -1) {
        break;
      }
    }
  }

  var userSelection = _helpers_UIHelper__WEBPACK_IMPORTED_MODULE_8__["ANIMA_USER_SELECTION_CONTINUE"];
  var animaExists = false;

  if (animaPrepareExportIndex !== -1) {
    userSelection = _helpers_UIHelper__WEBPACK_IMPORTED_MODULE_8__["default"].showAnimaExistsWarning(context);

    if (userSelection === _helpers_UIHelper__WEBPACK_IMPORTED_MODULE_8__["ANIMA_USER_SELECTION_PREPARE_EXPORT"]) {
      try {
        runPluginCommandWithIdentifier(context, 'com.animaapp.duplicate-detach', 'AnimaToolkitPlugin.sketchplugin');
        userSelection = _helpers_UIHelper__WEBPACK_IMPORTED_MODULE_8__["ANIMA_USER_SELECTION_CONTINUE"];
        animaExists = true;
      } catch (e) {
        console.log(e);
      }
    }
  }

  return {
    userSelection: userSelection,
    animaExists: animaExists
  };
};
var runPluginCommandWithIdentifier = function runPluginCommandWithIdentifier(context, commandIdentifier, pluginFilename) {
  var overflowCurrentPluginPath = context.plugin.url().path();
  var pluginToRunPath = _helpers_Helper__WEBPACK_IMPORTED_MODULE_5__["default"].pluginPathCreation(overflowCurrentPluginPath, pluginFilename);
  NSApp.delegate().runPluginCommandWithIdentifier_fromBundleAtURL_context(commandIdentifier, NSURL.fileURLWithPath(pluginToRunPath), context);
};
var isFrameworkVersionSameAsJS = function isFrameworkVersionSameAsJS(context, jsVersion, needsRestart) {
  var frameworkVersion = "0.0";

  try {
    frameworkVersion = overflowSketchPanel.getFrameworkVersion();
  } catch (e) {
    needsRestart = true;
  }

  if (frameworkVersion != jsVersion && needsRestart) {
    _helpers_UIHelper__WEBPACK_IMPORTED_MODULE_8__["default"].showErrorSketchNeedRestart(context);
    return false;
  }

  return true;
};
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@skpm/promise/index.js */ "./node_modules/@skpm/promise/index.js"), __webpack_require__(/*! ./node_modules/@skpm/builder/node_modules/sketch-polyfill-fetch/lib/index.js */ "./node_modules/@skpm/builder/node_modules/sketch-polyfill-fetch/lib/index.js"), __webpack_require__(/*! ./node_modules/@skpm/builder/node_modules/sketch-polyfill-fetch/lib/form-data.js */ "./node_modules/@skpm/builder/node_modules/sketch-polyfill-fetch/lib/form-data.js")))

/***/ }),

/***/ "./src/helpers/ArtboardHelper.js":
/*!***************************************!*\
  !*** ./src/helpers/ArtboardHelper.js ***!
  \***************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ArtboardHelper; });
/* harmony import */ var _babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/toConsumableArray */ "./node_modules/@babel/runtime/helpers/toConsumableArray.js");
/* harmony import */ var _babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/classCallCheck */ "./node_modules/@babel/runtime/helpers/classCallCheck.js");
/* harmony import */ var _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @babel/runtime/helpers/createClass */ "./node_modules/@babel/runtime/helpers/createClass.js");
/* harmony import */ var _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _skpm_fs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @skpm/fs */ "./node_modules/@skpm/fs/index.js");
/* harmony import */ var _skpm_fs__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_skpm_fs__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _Helper__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./Helper */ "./src/helpers/Helper.js");
/* harmony import */ var _LayerHelper__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./LayerHelper */ "./src/helpers/LayerHelper.js");
/* harmony import */ var sketch_dom__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! sketch/dom */ "sketch/dom");
/* harmony import */ var sketch_dom__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(sketch_dom__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _skpm_console__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @skpm/console */ "./node_modules/@skpm/console/index.js");
/* harmony import */ var _skpm_console__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_skpm_console__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _PluginSettingsHelper__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./PluginSettingsHelper */ "./src/helpers/PluginSettingsHelper.js");









var console = _skpm_console__WEBPACK_IMPORTED_MODULE_7___default()();

var ArtboardHelper = /*#__PURE__*/function () {
  function ArtboardHelper() {
    _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1___default()(this, ArtboardHelper);
  }

  _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_2___default()(ArtboardHelper, null, [{
    key: "createArtboardObject",
    value: function createArtboardObject(artboard, selectedDocument, includeLinks) {
      var selectedPage = selectedDocument.selectedPage;
      var dummyPage = this.createDummyPage(selectedDocument);
      var dummyArtboard = this.copyPasteTheArtboardToPage(dummyPage, artboard);
      var items = [];
      this.includeLinks = includeLinks;

      try {
        items = this.processArtboardChildren(dummyArtboard.layers, // selectedDocument,
        artboard.layers, undefined, undefined, artboard);
      } catch (e) {
        console.log(e);
        console.log('Artboard name that crashed: ' + artboard.name);
        dummyPage.remove();
        selectedPage.selected = true;
        throw new Error('Something went wrong');
      }

      dummyPage.remove();
      selectedPage.selected = true;
      var bounds = _LayerHelper__WEBPACK_IMPORTED_MODULE_5__["default"].getLayerBounds(artboard);
      var artboardObject = {
        id: artboard.id,
        title: artboard.name,
        position: {
          x: artboard.frame.x,
          y: artboard.frame.y
        },
        size: bounds.size,
        layers: items,
        backgroundColor: _Helper__WEBPACK_IMPORTED_MODULE_4__["default"].colorToRGBA(artboard.background.color),
        flow: includeLinks ? _LayerHelper__WEBPACK_IMPORTED_MODULE_5__["default"].getFlowDetails(artboard) : null
      };
      return artboardObject;
    }
  }, {
    key: "createDummyDocument",
    value: function createDummyDocument() {
      var document = new sketch_dom__WEBPACK_IMPORTED_MODULE_6__["Document"]();
      return document;
    }
  }, {
    key: "createDummyPage",
    value: function createDummyPage(selectedDocument) {
      var page = new sketch_dom__WEBPACK_IMPORTED_MODULE_6__["Page"]();
      selectedDocument.pages.push(page);
      return page;
    }
  }, {
    key: "copyPasteTheArtboardToPage",
    value: function copyPasteTheArtboardToPage(newDummyPage, artboard) {
      var copiedArtboard = sketch_dom__WEBPACK_IMPORTED_MODULE_6__["Artboard"].fromNative(artboard.sketchObject.copy());
      newDummyPage.layers.push(copiedArtboard);
      var artboardFromNewDocument = newDummyPage.layers.filter(function (layer) {
        return layer.type === 'Artboard' || layer.type === 'SymbolMaster';
      })[0];
      artboardFromNewDocument.frame = artboard.frame;
      return artboardFromNewDocument;
    }
  }, {
    key: "exportArtboardImage",
    value: function exportArtboardImage(artboard, syncPath, exportAssetsScale) {
      var exportImageOptions = {
        formats: 'png',
        'use-id-for-name': true,
        output: syncPath,
        overwriting: true,
        scales: exportAssetsScale
      };

      if (exportAssetsScale > 1) {
        exportImageOptions.scales = "" + exportAssetsScale;
      }

      sketch_dom__WEBPACK_IMPORTED_MODULE_6___default.a.export(artboard, exportImageOptions);

      if (exportAssetsScale > 1) {
        var oldFileName = syncPath + artboard.id + "@" + exportAssetsScale + "x.png";
        var newFileName = syncPath + artboard.id + ".png";
        _skpm_fs__WEBPACK_IMPORTED_MODULE_3___default.a.renameSync(oldFileName, newFileName);
      }
    }
  }, {
    key: "processArtboardChildren",
    value: function processArtboardChildren(layers, originalLayers, symbolParentInstanceID, maskParentLayer) {
      var items = [];
      var layersCount = layers.length;
      var maskParentsLayerQueue = [];
      var currentRecursionMaskParent = maskParentLayer;
      var currentIterationSymbolParentInstanceID = symbolParentInstanceID;

      if (originalLayers === undefined) {
        return items;
      }

      for (var i = 0; i < layersCount; i++) {
        var currentLayer = layers[i];
        var currentOriginalLayer = originalLayers[i];

        if (currentOriginalLayer === undefined) {
          continue;
        }

        if (currentLayer.hidden) {
          continue;
        } // define current layer attributes


        var isMaskLayer = currentLayer.sketchObject.hasClippingMask();
        var isInstanceOfSymbol = currentLayer.type.toLowerCase() === 'symbolinstance'; // check if layer is a mask layer

        var maskFirstLayer = null;

        if (isMaskLayer) {
          // print("is mask layer " + layer);
          maskFirstLayer = _LayerHelper__WEBPACK_IMPORTED_MODULE_5__["default"].getLayerProperties(currentLayer, currentOriginalLayer.id, currentRecursionMaskParent, this.includeLinks); //(originalSymbolLayer) ? getLayerProperties(originalSymbolLayer, [originalSymbolLayer objectID], maskParentLayer) :

          maskParentsLayerQueue.push(currentRecursionMaskParent);
          currentRecursionMaskParent = Object.assign({}, maskFirstLayer);
        } // check if is layer under mask and if the mask should break here


        var shouldMaskBreak = currentLayer.sketchObject.shouldBreakMaskChain();

        if (currentRecursionMaskParent && shouldMaskBreak) {
          maskFirstLayer = null;
          currentRecursionMaskParent = maskParentsLayerQueue.pop();
        } // Return if mask is hidden -> mask's inner layers will not be exported


        if (currentRecursionMaskParent && currentRecursionMaskParent.hidden) {
          continue;
        }

        var originalObjectID = currentOriginalLayer.id;

        if (typeof symbolParentInstanceID !== "undefined" && symbolParentInstanceID !== null) {
          originalObjectID = symbolParentInstanceID + "-" + currentOriginalLayer.id;
        }

        var layerObject = _LayerHelper__WEBPACK_IMPORTED_MODULE_5__["default"].getLayerProperties(currentLayer, originalObjectID, currentRecursionMaskParent, this.includeLinks);
        items.push(layerObject);
        var childLayers = currentLayer.layers ? currentLayer.layers : undefined;
        var childLayersOriginal = currentOriginalLayer.layers ? currentOriginalLayer.layers : undefined;

        if (isInstanceOfSymbol) {
          var symbolMasterOriginal = currentLayer.master;

          if (symbolMasterOriginal) {
            childLayersOriginal = symbolMasterOriginal.layers;
          }

          if (!childLayersOriginal) {
            continue;
          }

          symbolParentInstanceID = originalObjectID;
          var detachedCopiedSymbolInstance = currentLayer.detach();

          if (detachedCopiedSymbolInstance && detachedCopiedSymbolInstance.layers) {
            childLayers = detachedCopiedSymbolInstance.layers; // handle include background problem with skethc that on detach creates a new layer (the background layer)
            // that is not included within the original master symbol

            if (childLayersOriginal.length != childLayers.length && this.backgroundEnabled(symbolMasterOriginal)) {
              childLayers.splice(0, 1);
            }
          } // if (childLayers && childLayers.length == 1 && LayerHelper.isGroup(childLayers[0]) && this.countSubLayers(childLayersOriginal) != this.countSubLayers(childLayers)) {
          //     childLayers = childLayers[0].layers;
          // }


          currentLayer = detachedCopiedSymbolInstance;
        }

        if (_LayerHelper__WEBPACK_IMPORTED_MODULE_5__["default"].isGroup(currentLayer)) {
          var childItems = this.processArtboardChildren(childLayers, childLayersOriginal, symbolParentInstanceID, currentRecursionMaskParent);
          items.push.apply(items, _babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0___default()(childItems));
        }

        symbolParentInstanceID = currentIterationSymbolParentInstanceID;
      }

      return items;
    }
  }, {
    key: "countSubLayers",
    value: function countSubLayers(sublayer, countedSublayers) {
      countedSublayers = 0;

      for (var j = 0; j < sublayer.length; j++) {
        var sublayersSublayer = sublayer[j];
        countedSublayers++;

        if (_LayerHelper__WEBPACK_IMPORTED_MODULE_5__["default"].isGroup(sublayersSublayer)) {
          countedSublayers += this.countSubLayers(sublayersSublayer.layers, countedSublayers);
        }
      }

      return countedSublayers;
    }
  }, {
    key: "backgroundEnabled",
    value: function backgroundEnabled(symbolSource) {
      if (symbolSource.background.enabled || symbolSource.background.includedInInstance) {
        return true;
      }

      return false;
    }
  }, {
    key: "getUniqueArtboardsArrayFromLayers",
    value: function getUniqueArtboardsArrayFromLayers(selectedLayers) {
      var uniqueArtboards = [];
      selectedLayers.forEach(function (layer) {
        var artboard = layer.getParentArtboard();

        if (artboard === undefined && (layer.type.toLowerCase() === 'artboard' || layer.type.toLowerCase() === 'symbolmaster')) {
          artboard = layer;
        }

        if (artboard !== undefined) {
          var artboardExists = uniqueArtboards.filter(function (selectedArtoard) {
            return selectedArtoard.id === artboard.id;
          }).length > 0;

          if (!artboardExists) {
            uniqueArtboards.push(artboard);
          }
        }
      });
      return uniqueArtboards;
    }
  }, {
    key: "prepareSelectionChangedParameters",
    value: function prepareSelectionChangedParameters(userSelection) {
      var selectedArtboards = ArtboardHelper.getUniqueArtboardsArrayFromLayers(userSelection);
      var messageToShow = '';

      switch (selectedArtboards.length) {
        case 0:
          messageToShow = 'Select one or more artboards or a layer inside an artboard.';
          break;

        case 1:
          messageToShow = 'Selected artboard: ' + selectedArtboards[0].name;
          break;

        default:
          messageToShow = "".concat(selectedArtboards.length, " artboards selected");
      }

      var selectedArtboardsNames = selectedArtboards.map(function (artboard) {
        return artboard.name;
      });
      var showPanel = _PluginSettingsHelper__WEBPACK_IMPORTED_MODULE_8__["default"].ensureShowHideUI();
      return {
        selectedArtboardsNames: selectedArtboardsNames,
        messageToShow: messageToShow,
        showPanel: showPanel
      };
    }
    /***
     * This is the previous implementation without copying the artboard to a new page
     * Call example
     * const items = this.processArtboardChildren(
        //     artboard.layers,
        //     selectedDocument,
        //     undefined,
        //     undefined,
        //     artboard
        // );
     */
    // static processArtboardChildren(layers, originalLayersForSymbol, symbolParentInstanceID, maskParentLayer) {
    //
    //     let items = [];
    //
    //     if (!originalLayersForSymbol) {
    //         originalLayersForSymbol = [];
    //     }
    //
    //     const layersCount = layers.length;
    //
    //     const maskParentsLayerQueue = [];
    //
    //     let currentRecursionMaskParent = maskParentLayer;
    //
    //     for (let i = 0; i < layersCount; i++) {
    //
    //         let currentLayer = layers[i];
    //
    //         if (currentLayer.hidden) {
    //             continue;
    //         }
    //
    //         const originalSymbolLayer = originalLayersForSymbol[i];
    //
    //         const isMaskLayer = currentLayer.sketchObject.hasClippingMask();
    //         const isInstanceOfSymbol = currentLayer.type.toLowerCase() === 'symbolinstance';
    //
    //         // check if layer is a mask layer
    //         let maskFirstLayer = null;
    //
    //         if (isMaskLayer) {
    //             // print("is mask layer " + layer);
    //             maskFirstLayer = LayerHelper.getLayerProperties(currentLayer, currentLayer.id, currentRecursionMaskParent); //(originalSymbolLayer) ? getLayerProperties(originalSymbolLayer, [originalSymbolLayer objectID], maskParentLayer) :
    //             maskParentsLayerQueue.push(currentRecursionMaskParent);
    //             currentRecursionMaskParent = Object.assign({}, maskFirstLayer);
    //         }
    //
    //         // check if is layer under mask and if the mask should break here
    //         const shouldMaskBreak = currentLayer.sketchObject.shouldBreakMaskChain();
    //
    //         if (currentRecursionMaskParent && shouldMaskBreak) {
    //             maskFirstLayer = null;
    //             currentRecursionMaskParent = maskParentsLayerQueue.pop();
    //         }
    //
    //         if (currentRecursionMaskParent && currentRecursionMaskParent.hidden) {
    //             continue;
    //         }
    //
    //         let originalObjectID = currentLayer.id;
    //
    //         if (originalSymbolLayer) {
    //             if (typeof symbolParentInstanceID === "undefined" || symbolParentInstanceID == null) {
    //                 originalObjectID = originalSymbolLayer.id;
    //             } else {
    //                 originalObjectID = symbolParentInstanceID + "-" + originalSymbolLayer.id;
    //             }
    //         }
    //
    //
    //         let childLayers = currentLayer.layers
    //         let copyOfSymbol = null;
    //         let detachedCopiedSymbolInstance = null;
    //         let originalSymbolChildren = null;
    //
    //         if (isInstanceOfSymbol) {
    //
    //             let symbolMaster = originalSymbolLayer ? originalSymbolLayer.master : currentLayer.master;
    //
    //             originalSymbolChildren = symbolMaster.layers;
    //             symbolParentInstanceID = originalObjectID;
    //
    //             copyOfSymbol = currentLayer.duplicate();
    //             detachedCopiedSymbolInstance = copyOfSymbol.detach();
    //             console.log(detachedCopiedSymbolInstance);
    //
    //             if (detachedCopiedSymbolInstance && detachedCopiedSymbolInstance.layers) {
    //                 childLayers = detachedCopiedSymbolInstance.layers;
    //                 if (originalSymbolChildren.length != childLayers.length) {
    //                     childLayers.splice(0,1);
    //                 }
    //             }
    //
    //             currentLayer = detachedCopiedSymbolInstance;
    //
    //         }
    //
    //         const layerObject = LayerHelper.getLayerProperties(currentLayer, originalObjectID, currentRecursionMaskParent);
    //
    //         items.push(layerObject);
    //
    //         if (LayerHelper.isGroup(currentLayer)) {
    //             const childItems = this.processArtboardChildren(childLayers, originalSymbolChildren ? originalSymbolChildren : null , symbolParentInstanceID , currentRecursionMaskParent);
    //             items.push(...childItems);
    //         }
    //
    //         if (detachedCopiedSymbolInstance) {
    //             // copyOfSymbol.remove();
    //             detachedCopiedSymbolInstance.remove();
    //         }
    //
    //
    //     }
    //
    //     return items;
    //
    // }

  }]);

  return ArtboardHelper;
}();



/***/ }),

/***/ "./src/helpers/DocumentSettingsHelper.js":
/*!***********************************************!*\
  !*** ./src/helpers/DocumentSettingsHelper.js ***!
  \***********************************************/
/*! exports provided: DOC_UUID_CD, DOC_EXPORT_SIZE_CD, DOC_EXPORT_LINKS_CD, DOC_EXPORT_SIZE_DEFAULT, DOC_EXPORT_INCLUDE_LINKS_DEFAULT, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DOC_UUID_CD", function() { return DOC_UUID_CD; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DOC_EXPORT_SIZE_CD", function() { return DOC_EXPORT_SIZE_CD; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DOC_EXPORT_LINKS_CD", function() { return DOC_EXPORT_LINKS_CD; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DOC_EXPORT_SIZE_DEFAULT", function() { return DOC_EXPORT_SIZE_DEFAULT; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DOC_EXPORT_INCLUDE_LINKS_DEFAULT", function() { return DOC_EXPORT_INCLUDE_LINKS_DEFAULT; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return DocumentSettingsHelper; });
/* harmony import */ var _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/classCallCheck */ "./node_modules/@babel/runtime/helpers/classCallCheck.js");
/* harmony import */ var _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/createClass */ "./node_modules/@babel/runtime/helpers/createClass.js");
/* harmony import */ var _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Helper__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Helper */ "./src/helpers/Helper.js");
/* harmony import */ var sketch_settings__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! sketch/settings */ "sketch/settings");
/* harmony import */ var sketch_settings__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(sketch_settings__WEBPACK_IMPORTED_MODULE_3__);




var DOC_UUID_CD = 'OVERFLOW_DOC_UUID';
var DOC_EXPORT_SIZE_CD = 'OVERFLOW_DOC_EXPORT_SIZE';
var DOC_EXPORT_LINKS_CD = 'OVERFLOW_DOC_EXPORT_LINKS';
var DOC_EXPORT_SIZE_DEFAULT = 1;
var DOC_EXPORT_INCLUDE_LINKS_DEFAULT = 0;
var DOC_SHOW_HIDE_RIGHT_PANEL_CD = 'OVERFLOW_DOC_SHOW_HIDE_RIGHT_PANEL';

var DocumentSettingsHelper = /*#__PURE__*/function () {
  function DocumentSettingsHelper() {
    _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0___default()(this, DocumentSettingsHelper);
  }

  _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1___default()(DocumentSettingsHelper, null, [{
    key: "ensureDocUuid",
    value: function ensureDocUuid(selectedDocument) {
      var docUuid = this.getDocumentUuid(selectedDocument);

      if (!docUuid) {
        docUuid = _Helper__WEBPACK_IMPORTED_MODULE_2__["default"].uuidv4();
        this.setDocumentUuid(selectedDocument, docUuid);
      }

      this.ensureDocExportOptions(selectedDocument);
      return docUuid;
    }
  }, {
    key: "setDocumentUuid",
    value: function setDocumentUuid(selectedDocument, uuid) {
      sketch_settings__WEBPACK_IMPORTED_MODULE_3___default.a.setDocumentSettingForKey(selectedDocument, DOC_UUID_CD, uuid);
    }
  }, {
    key: "getDocumentUuid",
    value: function getDocumentUuid(selectedDocument) {
      // returns undefined if not exists
      var docUuid = sketch_settings__WEBPACK_IMPORTED_MODULE_3___default.a.documentSettingForKey(selectedDocument, DOC_UUID_CD);
      return docUuid;
    }
  }, {
    key: "ensureDocExportOptions",
    value: function ensureDocExportOptions(selectedDocument) {
      var defaultIncludeLinks = DOC_EXPORT_INCLUDE_LINKS_DEFAULT;
      var defaultExportSize = DOC_EXPORT_SIZE_DEFAULT;
      var exportSize = this.getDocumentExportSize(selectedDocument);

      if (exportSize === undefined) {
        exportSize = this.setDocumentExportSize(selectedDocument, defaultExportSize);
      }

      var includeLinks = this.getDocumentExportLinks(selectedDocument);

      if (includeLinks === undefined) {
        includeLinks = this.setDocumentExportLinks(selectedDocument, defaultIncludeLinks);
      }

      return {
        exportSize: exportSize,
        includeLinks: includeLinks
      };
    }
  }, {
    key: "getDocumentExportSize",
    value: function getDocumentExportSize(selectedDocument) {
      // returns undefined if not exists
      var exportSize = sketch_settings__WEBPACK_IMPORTED_MODULE_3___default.a.documentSettingForKey(selectedDocument, DOC_EXPORT_SIZE_CD);
      return exportSize;
    }
  }, {
    key: "setDocumentExportSize",
    value: function setDocumentExportSize(selectedDocument, exportSize) {
      // returns undefined if not exists
      sketch_settings__WEBPACK_IMPORTED_MODULE_3___default.a.setDocumentSettingForKey(selectedDocument, DOC_EXPORT_SIZE_CD, exportSize);
      return exportSize;
    }
  }, {
    key: "getDocumentExportLinks",
    value: function getDocumentExportLinks(selectedDocument) {
      // returns undefined if not exists
      var includeLinks = sketch_settings__WEBPACK_IMPORTED_MODULE_3___default.a.documentSettingForKey(selectedDocument, DOC_EXPORT_LINKS_CD);
      return includeLinks;
    }
  }, {
    key: "setDocumentExportLinks",
    value: function setDocumentExportLinks(selectedDocument, includeLinks) {
      sketch_settings__WEBPACK_IMPORTED_MODULE_3___default.a.setDocumentSettingForKey(selectedDocument, DOC_EXPORT_LINKS_CD, includeLinks);
      return includeLinks;
    }
  }, {
    key: "setDocumentExportOptions",
    value: function setDocumentExportOptions(selectedDocument, exportSize, includeLinks) {
      this.setDocumentExportSize(selectedDocument, exportSize);
      this.setDocumentExportLinks(selectedDocument, includeLinks);
    }
  }]);

  return DocumentSettingsHelper;
}();



/***/ }),

/***/ "./src/helpers/Helper.js":
/*!*******************************!*\
  !*** ./src/helpers/Helper.js ***!
  \*******************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Helper; });
/* harmony import */ var _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/classCallCheck */ "./node_modules/@babel/runtime/helpers/classCallCheck.js");
/* harmony import */ var _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/createClass */ "./node_modules/@babel/runtime/helpers/createClass.js");
/* harmony import */ var _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var sketch_dom__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! sketch/dom */ "sketch/dom");
/* harmony import */ var sketch_dom__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(sketch_dom__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _HexToRgba__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./HexToRgba */ "./src/helpers/HexToRgba.js");
/* harmony import */ var _HexToRgba__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_HexToRgba__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _skpm_fs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @skpm/fs */ "./node_modules/@skpm/fs/index.js");
/* harmony import */ var _skpm_fs__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_skpm_fs__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var semver__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! semver */ "./node_modules/semver/index.js");
/* harmony import */ var semver__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(semver__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _ArtboardHelper__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./ArtboardHelper */ "./src/helpers/ArtboardHelper.js");








var Helper = /*#__PURE__*/function () {
  function Helper() {
    _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0___default()(this, Helper);
  }

  _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1___default()(Helper, null, [{
    key: "uuidv4",
    value: function uuidv4() {
      return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function (c) {
        var r = Math.random() * 16 | 0,
            v = c == "x" ? r : r & 0x3 | 0x8;
        return v.toString(16);
      });
    }
  }, {
    key: "colorToRGBA",
    value: function colorToRGBA(hexColor) {
      return _HexToRgba__WEBPACK_IMPORTED_MODULE_3___default()(hexColor);
    }
  }, {
    key: "getPortsRange",
    value: function getPortsRange() {
      var allPorts = [];
      var batchPorts = [];
      var firstPort = 25000;
      var lastPort = 25050;
      var batch = 20;

      for (var i = firstPort; i <= lastPort; i++) {
        allPorts.push(i);
      }

      for (var _i = 0; _i < allPorts.length; _i += batch) {
        batchPorts.push(allPorts.slice(_i, _i + batch));
      }

      return batchPorts;
    }
  }, {
    key: "createSyncDirectory",
    value: function createSyncDirectory(docUuid) {
      var tempPath = NSTemporaryDirectory();
      var syncPath = tempPath + docUuid + '/';
      var pathExists = _skpm_fs__WEBPACK_IMPORTED_MODULE_4___default.a.existsSync(syncPath);

      if (!pathExists) {
        _skpm_fs__WEBPACK_IMPORTED_MODULE_4___default.a.mkdirSync(tempPath + docUuid);
      }

      return syncPath;
    }
  }, {
    key: "initialCheckForDocumentPage",
    value: function initialCheckForDocumentPage() {
      var selectedDocument = sketch_dom__WEBPACK_IMPORTED_MODULE_2__["Document"].getSelectedDocument();

      if (!selectedDocument) {
        return false;
      }

      var currentPage = selectedDocument.selectedPage;

      if (!currentPage) {
        return false;
      }

      return true;
    }
  }, {
    key: "formatScale",
    value: function formatScale(num, defaultNumber) {
      var formattedStringNum = num.replace(/(x|X).*/g, '');
      var number = Number(formattedStringNum);

      if (isNaN(number)) {
        return defaultNumber;
      }

      number = (Math.round(number * 100) / 100).toFixed(2);
      return parseFloat('' + number);
    }
  }, {
    key: "isScaleFormatCorrect",
    value: function isScaleFormatCorrect(num) {
      if (num === undefined || num === null) {
        return false;
      }

      var formattedStringNum = num.replace(/(x|X).*/g, '');
      var number = Number(formattedStringNum);

      if (isNaN(number)) {
        return false;
      }

      return true;
    }
  }, {
    key: "formatIncludeLinks",
    value: function formatIncludeLinks(exportLinks, defaultBoolean) {
      if (exportLinks === undefined || exportLinks === null) {
        return defaultBoolean;
      }

      var exportLinksFormatted = Number(exportLinks);

      if (isNaN(exportLinksFormatted) || exportLinksFormatted > 1) {
        return defaultBoolean;
      }

      return exportLinksFormatted;
    }
  }, {
    key: "isIncludeLinksFormatCorrect",
    value: function isIncludeLinksFormatCorrect(exportLinks) {
      if (exportLinks === undefined || exportLinks === null) {
        return false;
      }

      var exportLinksFormatted = Number(exportLinks);

      if (isNaN(exportLinksFormatted) || exportLinksFormatted > 1) {
        return false;
      }

      return true;
    }
  }, {
    key: "pluginPathCreation",
    value: function pluginPathCreation(overflowPluginPath, pluginFilename) {
      var commonInnerPathForPlugins = 'com.bohemiancoding.sketch3/Plugins';

      try {
        var infoDictionary = NSBundle.mainBundle().infoDictionary();
        var sketchIdentifier = infoDictionary.objectForKey('CFBundleIdentifier');
        commonInnerPathForPlugins = "".concat(sketchIdentifier, "/Plugins");
      } catch (e) {}

      var pluginPath = '';

      if (overflowPluginPath.endsWith('/')) {
        overflowPluginPath = overflowPluginPath.substring(0, overflowPluginPath.length - 1);
      }

      var splitOverflowPath = overflowPluginPath.split('/'); // remove overflow plugin name

      splitOverflowPath.pop();

      if (overflowPluginPath.includes(commonInnerPathForPlugins)) {
        splitOverflowPath.push(pluginFilename);
        pluginPath = splitOverflowPath.join('/');
      } else {
        var templatePluginsPath = '/Library/Application Support/com.bohemiancoding.sketch3/Plugins/';
        var commontSplitPath = splitOverflowPath.slice(0, 3);
        pluginPath = commontSplitPath.join('/') + templatePluginsPath + pluginFilename;
      }

      return pluginPath;
    }
  }, {
    key: "parseOverflowPingResponse",
    value: function parseOverflowPingResponse(overflowPingResponse) {
      var parsedResponse = {
        overflowUrl: null,
        overflowResponse: null
      }; // example response
      // overflowDetails: {
      //     appName: 'overflow',
      //     version: '',
      //     env: '', 'development' | 'staging' | 'production';
      // },

      try {
        parsedResponse = JSON.parse(overflowPingResponse);
      } catch (e) {}

      return parsedResponse;
    }
  }, {
    key: "appVersionCompatible",
    value: function appVersionCompatible(overflowResponseDetails, overflowAppMinVersion, appName) {
      var currentAppVersion = overflowResponseDetails.version.split('-')[0];
      var minAppVersion = overflowAppMinVersion;
      var isCompatible = semver__WEBPACK_IMPORTED_MODULE_5___default.a.satisfies(currentAppVersion, ">=".concat(minAppVersion));

      if (overflowResponseDetails.env === 'development') {
        isCompatible = true;
      }

      if (isCompatible && overflowResponseDetails.appName !== appName) {
        isCompatible = false;
      }

      return isCompatible;
    }
  }]);

  return Helper;
}();



/***/ }),

/***/ "./src/helpers/HexToRgba.js":
/*!**********************************!*\
  !*** ./src/helpers/HexToRgba.js ***!
  \**********************************/
/*! no static exports found */
/***/ (function(module, exports) {

var removeHash = function removeHash(hex) {
  return hex.charAt(0) === '#' ? hex.slice(1) : hex;
};

var parseHex = function parseHex(nakedHex) {
  var isShort = nakedHex.length === 3 || nakedHex.length === 4;
  var twoDigitHexR = isShort ? "".concat(nakedHex.slice(0, 1)).concat(nakedHex.slice(0, 1)) : nakedHex.slice(0, 2);
  var twoDigitHexG = isShort ? "".concat(nakedHex.slice(1, 2)).concat(nakedHex.slice(1, 2)) : nakedHex.slice(2, 4);
  var twoDigitHexB = isShort ? "".concat(nakedHex.slice(2, 3)).concat(nakedHex.slice(2, 3)) : nakedHex.slice(4, 6);
  var twoDigitHexA = (isShort ? "".concat(nakedHex.slice(3, 4)).concat(nakedHex.slice(3, 4)) : nakedHex.slice(6, 8)) || 'ff'; // const numericA = +((parseInt(a, 16) / 255).toFixed(2));

  return {
    r: twoDigitHexR,
    g: twoDigitHexG,
    b: twoDigitHexB,
    a: twoDigitHexA
  };
};

var hexToDecimal = function hexToDecimal(hex) {
  return parseInt(hex, 16);
};

var hexesToDecimals = function hexesToDecimals(_ref) {
  var r = _ref.r,
      g = _ref.g,
      b = _ref.b,
      a = _ref.a;
  return {
    r: hexToDecimal(r),
    g: hexToDecimal(g),
    b: hexToDecimal(b),
    a: +(hexToDecimal(a) / 255).toFixed(2)
  };
};

var isNumeric = function isNumeric(n) {
  return !isNaN(parseFloat(n)) && isFinite(n);
}; // eslint-disable-line no-restricted-globals, max-len


var formatRgb = function formatRgb(decimalObject, parameterA) {
  var r = decimalObject.r,
      g = decimalObject.g,
      b = decimalObject.b,
      parsedA = decimalObject.a;
  var a = isNumeric(parameterA) ? parameterA : parsedA;
  return "rgba(".concat(r, ", ").concat(g, ", ").concat(b, ", ").concat(a, ")");
};
/**
 * Turns an old-fashioned css hex color value into a rgb color value.
 *
 * If you specify an alpha value, you'll get a rgba() value instead.
 *
 * @param The hex value to convert. ('123456'. '#123456', ''123', '#123')
 * @param An alpha value to apply. (optional) ('0.5', '0.25')
 * @return An rgb or rgba value. ('rgb(11, 22, 33)'. 'rgba(11, 22, 33, 0.5)')
 */


var hexToRgba = function hexToRgba(hex, a) {
  var hashlessHex = removeHash(hex);
  var hexObject = parseHex(hashlessHex);
  var decimalObject = hexesToDecimals(hexObject);
  return formatRgb(decimalObject, a);
};

module.exports = hexToRgba;

/***/ }),

/***/ "./src/helpers/LayerHelper.js":
/*!************************************!*\
  !*** ./src/helpers/LayerHelper.js ***!
  \************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return LayerHelper; });
/* harmony import */ var _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/classCallCheck */ "./node_modules/@babel/runtime/helpers/classCallCheck.js");
/* harmony import */ var _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/createClass */ "./node_modules/@babel/runtime/helpers/createClass.js");
/* harmony import */ var _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var sketch_dom__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! sketch/dom */ "sketch/dom");
/* harmony import */ var sketch_dom__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(sketch_dom__WEBPACK_IMPORTED_MODULE_2__);




var LayerHelper = /*#__PURE__*/function () {
  function LayerHelper() {
    _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0___default()(this, LayerHelper);
  }

  _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1___default()(LayerHelper, null, [{
    key: "getLayerProperties",
    value: function getLayerProperties(layer, sliceID, maskParentLayer, includeLinks) {
      var sliceName = '';

      try {
        sliceName = encodeURIComponent(layer.name);
      } catch (e) {
        // added for UTF-16 error
        sliceName = '?';
      }

      var bounds = this.getLayerBounds(layer);

      if (maskParentLayer) {
        bounds = this.getMaskSubLayerCorrectBounds(maskParentLayer, layer);
      }

      var exportedPosition = {
        x: bounds.origin.x,
        y: bounds.origin.y
      };
      var exportedSize = {
        width: bounds.size.width,
        height: bounds.size.height
      };
      var layerItem = {
        id: "" + this.hashLayerId(sliceID),
        name: "" + sliceName,
        isGroup: this.isGroup(layer) ? 1 : 0,
        size: exportedSize,
        position: exportedPosition,
        path: "" + sliceName,
        pathID: "" + this.hashLayerId(sliceID),
        flow: includeLinks ? this.getFlowDetails(layer) : null
      };
      return layerItem;
    } // In sketch v97 absoluteRect() method doesnt exist anymore
    // so it goes into our fallback logic to calculate the absolute size

  }, {
    key: "getLayerBounds",
    value: function getLayerBounds(layer) {
      var absoluteSize = {
        origin: {},
        size: {}
      };

      try {
        var absoluteRect = layer.sketchObject.absoluteRect();
        absoluteSize.origin.x = absoluteRect.x();
        absoluteSize.origin.y = absoluteRect.y();
        absoluteSize.size.height = absoluteRect.height();
        absoluteSize.size.width = absoluteRect.width();
      } catch (err) {
        var _absoluteRect = layer.frame.changeBasis({
          from: layer.parent
        });

        absoluteSize.origin.x = _absoluteRect.x;
        absoluteSize.origin.y = _absoluteRect.y;
        absoluteSize.size.height = _absoluteRect.height;
        absoluteSize.size.width = _absoluteRect.width;
      }

      return absoluteSize;
    }
  }, {
    key: "getMaskSubLayerCorrectBounds",
    value: function getMaskSubLayerCorrectBounds(maskLayer, childLayer) {
      var childLayerBounds = this.getLayerBounds(childLayer);
      var childLayerXYAxes = {
        x1: 0,
        x2: 0,
        y1: 0,
        y2: 0
      }; // find correct y1 position of child layer

      if (childLayerBounds.origin.y < maskLayer.position.y) {
        childLayerXYAxes.y1 = maskLayer.position.y;
      } else {
        childLayerXYAxes.y1 = childLayerBounds.origin.y;
      } // find correct y2 position of child layer


      var childLayerY2 = childLayerBounds.origin.y + childLayerBounds.size.height;
      var maskLayerY2 = maskLayer.position.y + maskLayer.size.height;

      if (childLayerY2 > maskLayerY2) {
        childLayerXYAxes.y2 = maskLayerY2;
      } else {
        childLayerXYAxes.y2 = childLayerY2;
      } // find correct x1 position of child layer


      if (childLayerBounds.origin.x < maskLayer.position.x) {
        childLayerXYAxes.x1 = maskLayer.position.x;
      } else {
        childLayerXYAxes.x1 = childLayerBounds.origin.x;
      } // find correct x2 position of child layer


      var childLayerX2 = childLayerBounds.origin.x + childLayerBounds.size.width;
      var maskLayerX2 = maskLayer.position.x + maskLayer.size.width;

      if (childLayerX2 > maskLayerX2) {
        childLayerXYAxes.x2 = maskLayerX2;
      } else {
        childLayerXYAxes.x2 = childLayerX2;
      }

      var position = {
        x: childLayerXYAxes.x1,
        y: childLayerXYAxes.y1
      };
      var size = {
        width: childLayerXYAxes.x2 - childLayerXYAxes.x1,
        height: childLayerXYAxes.y2 - childLayerXYAxes.y1
      };
      return {
        origin: position,
        size: size
      };
    }
  }, {
    key: "hashLayerId",
    value: function hashLayerId(layerID) {
      if (layerID.split("-").length == 5) {
        return layerID;
      }

      var hash = 0,
          i,
          chr;
      if (layerID.length === 0) return hash;

      for (i = 0; i < layerID.length; i++) {
        chr = layerID.charCodeAt(i);
        hash = (hash << 5) - hash + chr;
        hash |= 0; // Convert to 32bit integer
      }

      return hash;
    }
  }, {
    key: "isGroup",
    value: function isGroup(layer) {
      var isGroup = false;

      try {
        var isGroupOrArtboard = layer.type.trim() === 'group' || layer.type.trim() === 'artboard';

        if (isGroupOrArtboard || layer.layers.length > 0) {
          isGroup = true;
        }
      } catch (e) {}

      return isGroup;
    }
  }, {
    key: "getFlowDetails",
    value: function getFlowDetails(layer) {
      var flowTargetDetails = null;
      var flow = null;

      try {
        flow = layer.flow;
      } catch (err) {
        return flowTargetDetails;
      }

      if (flow) {
        flowTargetDetails = {
          screenId: flow.targetId === sketch_dom__WEBPACK_IMPORTED_MODULE_2__["Flow"].BackTarget ? null : flow.targetId,
          transitionName: flow.animationType
        };
      }

      return flowTargetDetails;
    }
  }]);

  return LayerHelper;
}();



/***/ }),

/***/ "./src/helpers/PluginSettingsHelper.js":
/*!*********************************************!*\
  !*** ./src/helpers/PluginSettingsHelper.js ***!
  \*********************************************/
/*! exports provided: PLUGIN_SHOW_HIDE_UI_DEFAULT, PLUGIN_SHOW_HIDE_UI, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PLUGIN_SHOW_HIDE_UI_DEFAULT", function() { return PLUGIN_SHOW_HIDE_UI_DEFAULT; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PLUGIN_SHOW_HIDE_UI", function() { return PLUGIN_SHOW_HIDE_UI; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return PluginSettingsHelper; });
/* harmony import */ var _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/classCallCheck */ "./node_modules/@babel/runtime/helpers/classCallCheck.js");
/* harmony import */ var _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/createClass */ "./node_modules/@babel/runtime/helpers/createClass.js");
/* harmony import */ var _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var sketch_settings__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! sketch/settings */ "sketch/settings");
/* harmony import */ var sketch_settings__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(sketch_settings__WEBPACK_IMPORTED_MODULE_2__);



var PLUGIN_SHOW_HIDE_UI_DEFAULT = 1;
var PLUGIN_SHOW_HIDE_UI = 'OVERFLOW_SHOW_HIDE_UI';

var PluginSettingsHelper = /*#__PURE__*/function () {
  function PluginSettingsHelper() {
    _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0___default()(this, PluginSettingsHelper);
  }

  _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1___default()(PluginSettingsHelper, null, [{
    key: "ensureShowHideUI",
    value: function ensureShowHideUI() {
      var showUI = this.getPluginShowHideUI();

      if (showUI === undefined) {
        showUI = this.setPluginShowHideUI(PLUGIN_SHOW_HIDE_UI_DEFAULT);
      }

      return showUI;
    }
  }, {
    key: "setPluginShowHideUI",
    value: function setPluginShowHideUI(value) {
      sketch_settings__WEBPACK_IMPORTED_MODULE_2___default.a.setSettingForKey(PLUGIN_SHOW_HIDE_UI, value);
      return value;
    }
  }, {
    key: "getPluginShowHideUI",
    value: function getPluginShowHideUI() {
      // returns undefined if not exists
      var showUI = sketch_settings__WEBPACK_IMPORTED_MODULE_2___default.a.settingForKey(PLUGIN_SHOW_HIDE_UI);
      return showUI;
    }
  }]);

  return PluginSettingsHelper;
}();



/***/ }),

/***/ "./src/helpers/UIHelper.js":
/*!*********************************!*\
  !*** ./src/helpers/UIHelper.js ***!
  \*********************************/
/*! exports provided: ANIMA_USER_SELECTION_CONTINUE, ANIMA_USER_SELECTION_PREPARE_EXPORT, ANIMA_USER_SELECTION_CANCEL, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ANIMA_USER_SELECTION_CONTINUE", function() { return ANIMA_USER_SELECTION_CONTINUE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ANIMA_USER_SELECTION_PREPARE_EXPORT", function() { return ANIMA_USER_SELECTION_PREPARE_EXPORT; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ANIMA_USER_SELECTION_CANCEL", function() { return ANIMA_USER_SELECTION_CANCEL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return UIHelper; });
/* harmony import */ var _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/classCallCheck */ "./node_modules/@babel/runtime/helpers/classCallCheck.js");
/* harmony import */ var _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/createClass */ "./node_modules/@babel/runtime/helpers/createClass.js");
/* harmony import */ var _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1__);


var ANIMA_USER_SELECTION_CONTINUE = 'ANIMA_USER_SELECTION_CONTINUE';
var ANIMA_USER_SELECTION_PREPARE_EXPORT = 'ANIMA_USER_SELECTION_PREPARE_EXPORT';
var ANIMA_USER_SELECTION_CANCEL = 'ANIMA_USER_SELECTION_CANCEL';

var UIHelper = /*#__PURE__*/function () {
  function UIHelper() {
    _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0___default()(this, UIHelper);
  }

  _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1___default()(UIHelper, null, [{
    key: "showErrorNoPageSelected",
    value: function showErrorNoPageSelected(context) {
      var title = "No page selected";
      this.commonWarningAlertShow(context, title, '');
    }
  }, {
    key: "showErrorNoArtboardsSelected",
    value: function showErrorNoArtboardsSelected(context) {
      var title = "No artboard selected";
      var content = "Please select the artboards you want to sync to Overflow.\n\n☝️ Selecting a layer inside the artboard should be enough.";
      this.commonWarningAlertShow(context, title, content);
    }
  }, {
    key: "showErrorOverflowNotOpened",
    value: function showErrorOverflowNotOpened(context) {
      var title = "Overflow not opened";
      var content = "A connection with Overflow couldn't be established. Please ensure that Overflow is open and re-sync.";
      this.commonWarningAlertShow(context, title, content);
    }
  }, {
    key: "showErrorOverflowNotCompatible",
    value: function showErrorOverflowNotCompatible(context) {
      var title = "Sync to Overflow";
      var content = "Your current Overflow App version is not compatible with this plugin. Please update your Overflow App and sync again.";
      this.commonWarningAlertShow(context, title, content);
    }
  }, {
    key: "showErrorParsingFailed",
    value: function showErrorParsingFailed(context) {
      var title = "Sync to Overflow";
      var content = "We encountered an error while trying to sync your artboards. Please contact Overflow support to troubleshoot the issue.";
      var userSelection = this.commonWarningAlertShow(context, title, content, 'Contact Support');

      if (userSelection != NSAlertFirstButtonReturn) {
        try {
          NSWorkspace.sharedWorkspace().openURL(NSURL.URLWithString("https://support.overflow.io/hc/en-us/requests/new"));
        } catch (e) {}
      }
    }
  }, {
    key: "showErrorOverflowAppNotInstalled",
    value: function showErrorOverflowAppNotInstalled(context) {
      var title = "Could not find Overflow Desktop App";
      var content = "Please make sure that you installed and launched it: https://overflow.io/download.";
      this.commonWarningAlertShow(context, title, content);
    }
  }, {
    key: "showAnimaExistsWarning",
    value: function showAnimaExistsWarning(context) {
      var title = "Anima Plugin detected";
      var content = "We have found that you are using the Anima Plugin which is known to be causing issues when exporting. You can either continue with the current document or use the Anima \"Prepare Export for other Plugins\" feature to ensure your export works as expected.";
      var userSelection = this.commonWarningAlertShow(context, title, content, 'Continue', 'Cancel', 'Use Anima \"Prepare Export\"');
      var userSelectionReturned = ANIMA_USER_SELECTION_CANCEL;

      switch (userSelection) {
        case NSAlertFirstButtonReturn:
          userSelectionReturned = ANIMA_USER_SELECTION_PREPARE_EXPORT;
          break;

        case NSAlertSecondButtonReturn:
          userSelectionReturned = ANIMA_USER_SELECTION_CONTINUE;
          break;
      }

      return userSelectionReturned;
    }
  }, {
    key: "showErrorSketchNeedRestart",
    value: function showErrorSketchNeedRestart(context) {
      var title = "Sketch needs to be restarted";
      var content = "Please restart Sketch in order for the Overflow Plugin update to be applied.";
      this.commonWarningAlertShow(context, title, content);
    }
  }, {
    key: "commonWarningAlertShow",
    value: function commonWarningAlertShow(context, title, content, secondaryButton, thirdButton, okNewName) {
      var alert = NSAlert.alloc().init();
      alert.addButtonWithTitle(!okNewName ? "OK" : okNewName);

      if (secondaryButton) {
        alert.addButtonWithTitle(secondaryButton);
      }

      if (thirdButton) {
        alert.addButtonWithTitle(thirdButton);
      }

      alert.setMessageText(title);

      if (content !== '') {
        alert.setInformativeText(content);
      }

      alert.setIcon(context.plugin.iconInfo().image());
      alert.setAlertStyle(NSAlertStyleWarning);
      var userSelection = alert.runModal();
      return userSelection;
    }
  }]);

  return UIHelper;
}();



/***/ }),

/***/ "./src/main.js":
/*!*********************!*\
  !*** ./src/main.js ***!
  \*********************/
/*! exports provided: onExportAllArboards, onExportSelectedArtboards, userOptionsUI, showHideUI, onStartup, onOpenDocument, onSelectionChanged, getExportOptions, setExportOptions, handleOldPluginIdentifiersForPluginUpdate */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onExportAllArboards", function() { return onExportAllArboards; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onExportSelectedArtboards", function() { return onExportSelectedArtboards; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "userOptionsUI", function() { return userOptionsUI; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "showHideUI", function() { return showHideUI; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onStartup", function() { return onStartup; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onOpenDocument", function() { return onOpenDocument; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSelectionChanged", function() { return onSelectionChanged; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getExportOptions", function() { return getExportOptions; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setExportOptions", function() { return setExportOptions; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "handleOldPluginIdentifiersForPluginUpdate", function() { return handleOldPluginIdentifiersForPluginUpdate; });
/* harmony import */ var _babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/toConsumableArray */ "./node_modules/@babel/runtime/helpers/toConsumableArray.js");
/* harmony import */ var _babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @babel/runtime/helpers/asyncToGenerator */ "./node_modules/@babel/runtime/helpers/asyncToGenerator.js");
/* harmony import */ var _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var sketch_dom__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! sketch/dom */ "sketch/dom");
/* harmony import */ var sketch_dom__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(sketch_dom__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var sketch__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! sketch */ "sketch");
/* harmony import */ var sketch__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(sketch__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _helpers_Helper__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./helpers/Helper */ "./src/helpers/Helper.js");
/* harmony import */ var _helpers_UIHelper__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./helpers/UIHelper */ "./src/helpers/UIHelper.js");
/* harmony import */ var _helpers_ArtboardHelper__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./helpers/ArtboardHelper */ "./src/helpers/ArtboardHelper.js");
/* harmony import */ var _export__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./export */ "./src/export.js");
/* harmony import */ var _options__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./options */ "./src/options.js");
/* harmony import */ var _helpers_PluginSettingsHelper__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./helpers/PluginSettingsHelper */ "./src/helpers/PluginSettingsHelper.js");
/* harmony import */ var _helpers_DocumentSettingsHelper__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./helpers/DocumentSettingsHelper */ "./src/helpers/DocumentSettingsHelper.js");
/* harmony import */ var _manifest_json__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./manifest.json */ "./src/manifest.json");
var _manifest_json__WEBPACK_IMPORTED_MODULE_12___namespace = /*#__PURE__*/__webpack_require__.t(/*! ./manifest.json */ "./src/manifest.json", 1);
/* harmony import */ var _skpm_console__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @skpm/console */ "./node_modules/@skpm/console/index.js");
/* harmony import */ var _skpm_console__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_skpm_console__WEBPACK_IMPORTED_MODULE_13__);



;












var console = _skpm_console__WEBPACK_IMPORTED_MODULE_13___default()();
var FRAMEWORK_NAME = 'overflowSketchPanel'; // change if there is breaking change between the plugin and the right panel framework

var NEEDS_RESTART = true;
var onExportAllArboards = /*#__PURE__*/function () {
  var _ref = _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_2___default()( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default.a.mark(function _callee(context) {
    var isPageSelected, _animaPluginDetection, userSelection, animaExists, currentSelectedDocument, currentPage, currentPageArtboards;

    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default.a.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            isPageSelected = _helpers_Helper__WEBPACK_IMPORTED_MODULE_5__["default"].initialCheckForDocumentPage();

            if (isPageSelected) {
              _context.next = 4;
              break;
            }

            _helpers_UIHelper__WEBPACK_IMPORTED_MODULE_6__["default"].showErrorNoPageSelected(context);
            return _context.abrupt("return");

          case 4:
            if (Object(_export__WEBPACK_IMPORTED_MODULE_8__["isFrameworkVersionSameAsJS"])(context, _manifest_json__WEBPACK_IMPORTED_MODULE_12__.version, NEEDS_RESTART)) {
              _context.next = 6;
              break;
            }

            return _context.abrupt("return");

          case 6:
            _animaPluginDetection = Object(_export__WEBPACK_IMPORTED_MODULE_8__["animaPluginDetection"])(context), userSelection = _animaPluginDetection.userSelection, animaExists = _animaPluginDetection.animaExists;

            if (!(userSelection === _helpers_UIHelper__WEBPACK_IMPORTED_MODULE_6__["ANIMA_USER_SELECTION_CANCEL"])) {
              _context.next = 9;
              break;
            }

            return _context.abrupt("return");

          case 9:
            currentSelectedDocument = sketch_dom__WEBPACK_IMPORTED_MODULE_3__["Document"].getSelectedDocument();
            currentPage = currentSelectedDocument.selectedPage;
            currentPageArtboards = currentPage.layers.filter(function (layer) {
              return layer.type === 'Artboard';
            });
            _context.next = 14;
            return Object(_export__WEBPACK_IMPORTED_MODULE_8__["exportArtboards"])(context, currentSelectedDocument, currentPage, currentPageArtboards);

          case 14:
            if (animaExists) {
              currentSelectedDocument.close();
            }

          case 15:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));

  return function onExportAllArboards(_x) {
    return _ref.apply(this, arguments);
  };
}();
var onExportSelectedArtboards = /*#__PURE__*/function () {
  var _ref2 = _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_2___default()( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default.a.mark(function _callee2(context) {
    var isPageSelected, selectedDocument, currentPage, userLayersSelection, selectedArtboards, selectedArtboardsToBeExported, _animaPluginDetection2, userSelection, animaExists, selectedArtboardIds;

    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default.a.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            isPageSelected = _helpers_Helper__WEBPACK_IMPORTED_MODULE_5__["default"].initialCheckForDocumentPage();

            if (isPageSelected) {
              _context2.next = 4;
              break;
            }

            _helpers_UIHelper__WEBPACK_IMPORTED_MODULE_6__["default"].showErrorNoPageSelected(context);
            return _context2.abrupt("return");

          case 4:
            if (Object(_export__WEBPACK_IMPORTED_MODULE_8__["isFrameworkVersionSameAsJS"])(context, _manifest_json__WEBPACK_IMPORTED_MODULE_12__.version, NEEDS_RESTART)) {
              _context2.next = 6;
              break;
            }

            return _context2.abrupt("return");

          case 6:
            selectedDocument = sketch_dom__WEBPACK_IMPORTED_MODULE_3__["Document"].getSelectedDocument();
            currentPage = selectedDocument.selectedPage;
            userLayersSelection = selectedDocument.selectedLayers;
            selectedArtboards = _helpers_ArtboardHelper__WEBPACK_IMPORTED_MODULE_7__["default"].getUniqueArtboardsArrayFromLayers(userLayersSelection);

            if (!(selectedArtboards.length === 0)) {
              _context2.next = 13;
              break;
            }

            _helpers_UIHelper__WEBPACK_IMPORTED_MODULE_6__["default"].showErrorNoArtboardsSelected(context);
            return _context2.abrupt("return");

          case 13:
            selectedArtboardsToBeExported = _babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0___default()(selectedArtboards);
            _animaPluginDetection2 = Object(_export__WEBPACK_IMPORTED_MODULE_8__["animaPluginDetection"])(context), userSelection = _animaPluginDetection2.userSelection, animaExists = _animaPluginDetection2.animaExists;

            if (!(userSelection === _helpers_UIHelper__WEBPACK_IMPORTED_MODULE_6__["ANIMA_USER_SELECTION_CANCEL"])) {
              _context2.next = 17;
              break;
            }

            return _context2.abrupt("return");

          case 17:
            if (animaExists) {
              selectedDocument = sketch_dom__WEBPACK_IMPORTED_MODULE_3__["Document"].getSelectedDocument();
              currentPage = selectedDocument.selectedPage;
              selectedArtboardsToBeExported = [];
              selectedArtboardIds = selectedArtboards.map(function (a) {
                return a.id;
              });
              currentPage.layers.forEach(function (layer) {
                var exists = selectedArtboardIds.includes(layer.id);

                if (exists) {
                  selectedArtboardsToBeExported.push(layer);
                }
              });
            }

            _context2.next = 20;
            return Object(_export__WEBPACK_IMPORTED_MODULE_8__["exportArtboards"])(context, selectedDocument, currentPage, selectedArtboardsToBeExported);

          case 20:
            if (animaExists) {
              selectedDocument.close();
            }

          case 21:
          case "end":
            return _context2.stop();
        }
      }
    }, _callee2);
  }));

  return function onExportSelectedArtboards(_x2) {
    return _ref2.apply(this, arguments);
  };
}();
var userOptionsUI = /*#__PURE__*/function () {
  var _ref3 = _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_2___default()( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default.a.mark(function _callee3(context) {
    var isPageSelected, selectedDocument;
    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default.a.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            isPageSelected = _helpers_Helper__WEBPACK_IMPORTED_MODULE_5__["default"].initialCheckForDocumentPage();

            if (isPageSelected) {
              _context3.next = 4;
              break;
            }

            _helpers_UIHelper__WEBPACK_IMPORTED_MODULE_6__["default"].showErrorNoPageSelected(context);
            return _context3.abrupt("return");

          case 4:
            selectedDocument = sketch_dom__WEBPACK_IMPORTED_MODULE_3__["Document"].getSelectedDocument();
            Object(_options__WEBPACK_IMPORTED_MODULE_9__["showOptions"])(context, selectedDocument);

          case 6:
          case "end":
            return _context3.stop();
        }
      }
    }, _callee3);
  }));

  return function userOptionsUI(_x3) {
    return _ref3.apply(this, arguments);
  };
}();
var showHideUI = /*#__PURE__*/function () {
  var _ref4 = _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_2___default()( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default.a.mark(function _callee4(context) {
    var showUI;
    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default.a.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            showUI = _helpers_PluginSettingsHelper__WEBPACK_IMPORTED_MODULE_10__["default"].ensureShowHideUI();
            _helpers_PluginSettingsHelper__WEBPACK_IMPORTED_MODULE_10__["default"].setPluginShowHideUI(!showUI);
            onSelectionChanged(context);

          case 3:
          case "end":
            return _context4.stop();
        }
      }
    }, _callee4);
  }));

  return function showHideUI(_x4) {
    return _ref4.apply(this, arguments);
  };
}();
var onStartup = function onStartup(context) {
  var overflowFrameworkParentPath = context.plugin.urlForResourceNamed(FRAMEWORK_NAME + '.framework').path().stringByDeletingLastPathComponent();
  var mocha = Mocha.sharedRuntime();
  var directory = overflowFrameworkParentPath;

  if (mocha.valueForKey(FRAMEWORK_NAME)) {
    print("😎 loadFramework: `" + FRAMEWORK_NAME + "` already loaded.");
    onSelectionChanged(context);
    return true;
  } else if (mocha.loadFrameworkWithName_inDirectory(FRAMEWORK_NAME, directory)) {
    print("✅ loadFramework: `" + FRAMEWORK_NAME + "` success!");
    mocha.setValue_forKey_(true, FRAMEWORK_NAME);
    onSelectionChanged(context);
    return true;
  } else {
    print("❌ loadFramework: `" + FRAMEWORK_NAME + "` failed!: " + directory + ". Please define overflowFrameworkParentPath if you're trying to @import in a custom plugin");
    return false;
  }
};
var onOpenDocument = function onOpenDocument(context) {
  var selectedDocument = sketch_dom__WEBPACK_IMPORTED_MODULE_3__["Document"].getSelectedDocument();
  _helpers_DocumentSettingsHelper__WEBPACK_IMPORTED_MODULE_11__["default"].ensureDocUuid(selectedDocument);
  overflowSketchPanel.initWithContext(context);
};
var onSelectionChanged = function onSelectionChanged(context) {
  var userSelection = sketch_dom__WEBPACK_IMPORTED_MODULE_3__["Document"].getSelectedDocument().selectedLayers;

  var _ArtboardHelper$prepa = _helpers_ArtboardHelper__WEBPACK_IMPORTED_MODULE_7__["default"].prepareSelectionChangedParameters(userSelection),
      selectedArtboardsNames = _ArtboardHelper$prepa.selectedArtboardsNames,
      messageToShow = _ArtboardHelper$prepa.messageToShow,
      showPanel = _ArtboardHelper$prepa.showPanel;

  overflowSketchPanel.onSelectionChanged_selectedArtboardsNames_messageToShow_show(context, selectedArtboardsNames, messageToShow, showPanel);
};
var getExportOptions = function getExportOptions() {
  var selectedDocument = sketch_dom__WEBPACK_IMPORTED_MODULE_3__["Document"].getSelectedDocument();

  var _DocumentSettingsHelp = _helpers_DocumentSettingsHelper__WEBPACK_IMPORTED_MODULE_11__["default"].ensureDocExportOptions(selectedDocument),
      exportSize = _DocumentSettingsHelp.exportSize,
      includeLinks = _DocumentSettingsHelp.includeLinks;

  console.log("".concat(exportSize, ",").concat(includeLinks));
  return;
};
var setExportOptions = function setExportOptions(context) {
  var selectedDocument = sketch_dom__WEBPACK_IMPORTED_MODULE_3__["Document"].getSelectedDocument();

  if (_helpers_Helper__WEBPACK_IMPORTED_MODULE_5__["default"].isScaleFormatCorrect(context.exportSize)) {
    _helpers_DocumentSettingsHelper__WEBPACK_IMPORTED_MODULE_11__["default"].setDocumentExportSize(selectedDocument, _helpers_Helper__WEBPACK_IMPORTED_MODULE_5__["default"].formatScale(context.exportSize, _helpers_DocumentSettingsHelper__WEBPACK_IMPORTED_MODULE_11__["DOC_EXPORT_SIZE_DEFAULT"]));
  }

  if (_helpers_Helper__WEBPACK_IMPORTED_MODULE_5__["default"].isIncludeLinksFormatCorrect(context.includeLinks)) {
    _helpers_DocumentSettingsHelper__WEBPACK_IMPORTED_MODULE_11__["default"].setDocumentExportLinks(selectedDocument, _helpers_Helper__WEBPACK_IMPORTED_MODULE_5__["default"].formatIncludeLinks(context.includeLinks, _helpers_DocumentSettingsHelper__WEBPACK_IMPORTED_MODULE_11__["DOC_EXPORT_INCLUDE_LINKS_DEFAULT"]));
  }
};
var handleOldPluginIdentifiersForPluginUpdate = function handleOldPluginIdentifiersForPluginUpdate(context) {
  Object(_export__WEBPACK_IMPORTED_MODULE_8__["isFrameworkVersionSameAsJS"])(context, _manifest_json__WEBPACK_IMPORTED_MODULE_12__.version, true);
};

/***/ }),

/***/ "./src/manifest.json":
/*!***************************!*\
  !*** ./src/manifest.json ***!
  \***************************/
/*! exports provided: name, description, $schema, icon, version, identifier, homepage, appcast, author, compatibleVersion, overflow, commands, menu, default */
/***/ (function(module) {

module.exports = JSON.parse("{\"name\":\"Overflow Plugin\",\"description\":\"Overflow is a new design tool that brings together flow diagramming and rapid prototyping to create, present and share digital designs in an interactive and engaging way.\",\"$schema\":\"https://raw.githubusercontent.com/sketch-hq/SketchAPI/develop/docs/sketch-plugin-manifest-schema.json\",\"icon\":\"icon.png\",\"version\":\"0.2.8\",\"identifier\":\"io.overflow.sketchpanel\",\"homepage\":\"https://overflow.io\",\"appcast\":\"https://raw.githubusercontent.com/overflowapp/overflow-sketch-plugin/master/.appcast.xml\",\"author\":\"Overflow.io\",\"compatibleVersion\":\"53\",\"overflow\":{\"overflowAppMinVersion\":\"1.16.2\",\"appName\":\"overflow\"},\"commands\":[{\"script\":\"./main.js\",\"handlers\":{\"actions\":{\"Startup\":\"onStartup\",\"OpenDocument\":\"onOpenDocument\",\"SelectionChanged.finish\":\"onSelectionChanged\"}}},{\"name\":\"Sync all artboards in current page\",\"identifier\":\"overflow.export-all\",\"shortcut\":\"ctrl shift E\",\"script\":\"./main.js\",\"handler\":\"onExportAllArboards\"},{\"name\":\"Sync selected artboards\",\"identifier\":\"overflow.export-selected\",\"shortcut\":\"ctrl shift S\",\"script\":\"./main.js\",\"handler\":\"onExportSelectedArtboards\"},{\"name\":\"Options...\",\"identifier\":\"overflow.options\",\"shortcut\":\"\",\"script\":\"./main.js\",\"handler\":\"userOptionsUI\"},{\"name\":\"Show/Hide UI\",\"identifier\":\"overflow.show-hide-ui\",\"shortcut\":\"\",\"script\":\"./main.js\",\"handler\":\"showHideUI\"},{\"name\":\"GetExportOptions\",\"identifier\":\"overflow.overflow.options.get\",\"script\":\"./main.js\",\"handler\":\"getExportOptions\"},{\"name\":\"SetExportOptions\",\"identifier\":\"overflow.overflow.options.set\",\"script\":\"./main.js\",\"handler\":\"setExportOptions\"},{\"identifier\":\"export_all\",\"script\":\"./main.js\",\"handler\":\"onExportAllArboards\"},{\"identifier\":\"export_selected\",\"script\":\"./main.js\",\"handler\":\"handleOldPluginIdentifiersForPluginUpdate\"},{\"identifier\":\"options\",\"script\":\"./main.js\",\"handler\":\"handleOldPluginIdentifiersForPluginUpdate\"},{\"identifier\":\"show_hide_ui\",\"script\":\"./main.js\",\"handler\":\"handleOldPluginIdentifiersForPluginUpdate\"}],\"menu\":{\"title\":\"Overflow Plugin\",\"items\":[\"overflow.export-all\",\"overflow.export-selected\",\"-\",\"overflow.show-hide-ui\",\"overflow.options\"]}}");

/***/ }),

/***/ "./src/nib-views/LoadingBar.xib":
/*!**************************************!*\
  !*** ./src/nib-views/LoadingBar.xib ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! ./node_modules/@skpm/nib-loader/lib/nib-class.js */ "./node_modules/@skpm/nib-loader/lib/nib-class.js").bind(this, '_webpack_resources/88ecafbebdb024fc907001e1feb5bfbd.nib');

/***/ }),

/***/ "./src/nib-views/Options.xib":
/*!***********************************!*\
  !*** ./src/nib-views/Options.xib ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! ./node_modules/@skpm/nib-loader/lib/nib-class.js */ "./node_modules/@skpm/nib-loader/lib/nib-class.js").bind(this, '_webpack_resources/ebd9a3a20c4ad9cacf811e69e8fc2ba4.nib');

/***/ }),

/***/ "./src/options.js":
/*!************************!*\
  !*** ./src/options.js ***!
  \************************/
/*! exports provided: showOptions */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "showOptions", function() { return showOptions; });
/* harmony import */ var _helpers_Helper__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./helpers/Helper */ "./src/helpers/Helper.js");
/* harmony import */ var _helpers_DocumentSettingsHelper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./helpers/DocumentSettingsHelper */ "./src/helpers/DocumentSettingsHelper.js");
// import Console from "@skpm/console"

 // const console = Console();

var showOptions = function showOptions(context, selectedDocument) {
  var exportOptions = _helpers_DocumentSettingsHelper__WEBPACK_IMPORTED_MODULE_1__["default"].ensureDocExportOptions(selectedDocument);

  var NibUI = __webpack_require__(/*! ./nib-views/Options.xib */ "./src/nib-views/Options.xib");

  var nib = NibUI();
  nib.exportSize.stringValue = exportOptions.exportSize + 'x';
  nib.includeLinks.stringValue = String(exportOptions.includeLinks);
  var alert = NSAlert.alloc().init();
  alert.addButtonWithTitle("Save");
  alert.addButtonWithTitle("Cancel");
  alert.setMessageText("Overflow Sync Options");
  alert.informativeText.hidden = true;
  alert.setIcon(context.plugin.iconInfo().image());
  alert.setAccessoryView(nib.getRoot());
  alert.setAlertStyle(NSAlertStyleWarning);
  var userSelection = alert.runModal();

  if (userSelection === NSAlertFirstButtonReturn) {
    var exportSize = nib.exportSize.stringValue();
    var includeLinks = nib.includeLinks.stringValue();
    var exportSizeTobeSaved = _helpers_Helper__WEBPACK_IMPORTED_MODULE_0__["default"].formatScale(exportSize, _helpers_DocumentSettingsHelper__WEBPACK_IMPORTED_MODULE_1__["DOC_EXPORT_SIZE_DEFAULT"]);
    var includeLinksTobeSaved = _helpers_Helper__WEBPACK_IMPORTED_MODULE_0__["default"].formatIncludeLinks(includeLinks, _helpers_DocumentSettingsHelper__WEBPACK_IMPORTED_MODULE_1__["DOC_EXPORT_INCLUDE_LINKS_DEFAULT"]);
    _helpers_DocumentSettingsHelper__WEBPACK_IMPORTED_MODULE_1__["default"].setDocumentExportOptions(selectedDocument, exportSizeTobeSaved, includeLinksTobeSaved);
  }
};

/***/ }),

/***/ "buffer":
/*!*************************!*\
  !*** external "buffer" ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("buffer");

/***/ }),

/***/ "sketch":
/*!*************************!*\
  !*** external "sketch" ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch");

/***/ }),

/***/ "sketch/async":
/*!*******************************!*\
  !*** external "sketch/async" ***!
  \*******************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch/async");

/***/ }),

/***/ "sketch/dom":
/*!*****************************!*\
  !*** external "sketch/dom" ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch/dom");

/***/ }),

/***/ "sketch/settings":
/*!**********************************!*\
  !*** external "sketch/settings" ***!
  \**********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch/settings");

/***/ }),

/***/ "util":
/*!***********************!*\
  !*** external "util" ***!
  \***********************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("util");

/***/ })

/******/ });
    if (key === 'default' && typeof exports === 'function') {
      exports(context);
    } else if (typeof exports[key] !== 'function') {
      throw new Error('Missing export named "' + key + '". Your command should contain something like `export function " + key +"() {}`.');
    } else {
      exports[key](context);
    }
  } catch (err) {
    if (typeof process !== 'undefined' && process.listenerCount && process.listenerCount('uncaughtException')) {
      process.emit("uncaughtException", err, "uncaughtException");
    } else {
      throw err
    }
  }
}
globalThis['onStartup'] = __skpm_run.bind(this, 'onStartup');
globalThis['onOpenDocument'] = __skpm_run.bind(this, 'onOpenDocument');
globalThis['onSelectionChanged'] = __skpm_run.bind(this, 'onSelectionChanged');
globalThis['onRun'] = __skpm_run.bind(this, 'default');
globalThis['onExportAllArboards'] = __skpm_run.bind(this, 'onExportAllArboards');
globalThis['onExportSelectedArtboards'] = __skpm_run.bind(this, 'onExportSelectedArtboards');
globalThis['userOptionsUI'] = __skpm_run.bind(this, 'userOptionsUI');
globalThis['showHideUI'] = __skpm_run.bind(this, 'showHideUI');
globalThis['getExportOptions'] = __skpm_run.bind(this, 'getExportOptions');
globalThis['setExportOptions'] = __skpm_run.bind(this, 'setExportOptions');
globalThis['onExportAllArboards'] = __skpm_run.bind(this, 'onExportAllArboards');
globalThis['handleOldPluginIdentifiersForPluginUpdate'] = __skpm_run.bind(this, 'handleOldPluginIdentifiersForPluginUpdate');
globalThis['handleOldPluginIdentifiersForPluginUpdate'] = __skpm_run.bind(this, 'handleOldPluginIdentifiersForPluginUpdate');
globalThis['handleOldPluginIdentifiersForPluginUpdate'] = __skpm_run.bind(this, 'handleOldPluginIdentifiersForPluginUpdate')

//# sourceMappingURL=__main.js.map