/*
// To load this framework, add the following code in your manifest.json

"commands": [
:
:
{
    "script" : "overflowSketchPanel.framework/overflowSketchPanel.js",
    "handlers" : {
        "actions" : {
            "Startup" : "onStartup",
            "OpenDocument":"onOpenDocument",
            "SelectionChanged.finish" : "onSelectionChanged"
        }
    }
}
]
*/

@import "common.js";
@import "export_all.js";
@import "manifest.json";


var doc;
var myContext;
var docUUID="";
var contextParams={};
var ovrProcessFile="";
var processStep=1;
var bundleId="io.overflow.mac.app";
var totalArtboardsToProcess=0;
var processingArtboardNo=0;
var currentArtboardTitle="";
var density=1.0;
var requiredDensity=3.0;

var onStartup = function(context) {
	myContext=context;
  var overflowSketchPanel_FrameworkPath = overflowSketchPanel_FrameworkPath || COScript.currentCOScript().env().scriptURL.path().stringByDeletingLastPathComponent().stringByDeletingLastPathComponent().stringByDeletingLastPathComponent();
	
  var overflowSketchPanel_Log = overflowSketchPanel_Log || log;
  (function() {
    var mocha = Mocha.sharedRuntime();
    var frameworkName = "overflowSketchPanel";
    var directory = overflowSketchPanel_FrameworkPath;
    if (mocha.valueForKey(frameworkName)) {
      print("😎 loadFramework: `" + frameworkName + "` already loaded.");
//      isFrameworkVersionSameAsJS();
   	    //alert("1 "+frameworkName+" "+bundleId)
      return true;
    } else if ([mocha loadFrameworkWithName:frameworkName inDirectory:directory]) {
        //alert("2 "+frameworkName+" "+bundleId)
      print("✅ loadFramework: `" + frameworkName + "` success!");
      mocha.setValue_forKey_(true, frameworkName);
      return true;
    } else {
   //alert("3 "+frameworkName+" "+bundleId)
      print("❌ loadFramework: `" + frameworkName + "` failed!: " + directory + ". Please define overflowSketchPanel_FrameworkPath if you're trying to @import in a custom plugin");
      return false;
    }
  })();
};
var onOpenDocument = function(context) {
	log("onOpenDocument")
    setDocId(context);
	overflowSketchPanel.initWithContext(context);
};

var onSelectionChanged = function(context) {
	log("onSelectionChanged")
	myContext=context;
	//setDocId(context);
	overflowSketchPanel.onSelectionChanged(context);
};

var userOptionsAboutUI = function(context) {
    log("userOptionsAboutUI")
    myContext=context;
    overflowSketchPanel.showUserOptionsForUI(context);
};

var showHideUI = function(context) {
    log("userShowHideUI")
    myContext=context;
    overflowSketchPanel.showHideUI(context);
};

var onExportAllArboards=function(context){
	//alert (context.x);
	processStep=1;
	doExport(context,"all");
}

var onExportSelectedArboards=function(context){
	processStep=1;
	doExport(context,"selected");
}


var onProcess = function(context) {
	log("onProcess")
    myContext=context;
    doc=context.document;
    
    if (context.path) {
        
        var currentDoc=[[doc fileURL] path];
        var contextPathFromElectron = encodeURI(context.path)
        
//        print('currentDoc path ' + currentDoc)
//        print('context path ' + context.path)
        
        if(currentDoc.trim() != context.path.trim() ){
            
            print('Context path from electron ' + contextPathFromElectron);
            var openedDocuments = require('sketch/dom').getDocuments();
            
            var index = openedDocuments.findIndex( function (openedDocument) {
                return openedDocument.path == contextPathFromElectron
            });
            
            if (index == -1) {
                print("Document is not opened")
                return;
            }
            
            var pathToCreate = 'file://'+contextPathFromElectron;
            
            var docPath = [NSURL URLWithString:pathToCreate];
//            print('NSURL ' + docPath)
            
            var err;
            var documentToExport = [[NSDocumentController sharedDocumentController] documentForURL:docPath];
//            print('Document to export ' + documentToExport)
//            print('Current Document to export ' + context.document)
            
            context.document = documentToExport;
            myContext=context;
            doc=context.document;
            context.selection = [documentToExport previousSelectedLayers];
        }
        
    }
    
	processStep=2;
	
	var docUUID=getDocId(doc,context);
	if(!docUUID){
		print("docUUID not found");
		return;
	}
	//check for context
	var temporaryDirectory = NSTemporaryDirectory();
	var ovrProcessFile=temporaryDirectory+docUUID+".ovrprocess";
	var file_manager = [NSFileManager defaultManager];
	if (![file_manager fileExistsAtPath:ovrProcessFile]) {
		print("ovrprocess file "+ovrProcessFile+" not found")
		return;
	}
	var contextParamsString=[NSString stringWithContentsOfFile:ovrProcessFile encoding:NSUTF8StringEncoding error:nil];
	contextParams=JSON.parse(contextParamsString);
	
	var currentDoc=[[doc fileURL] path];
	if(currentDoc!=contextParams.doc){
		print("Document mismatch")
		return;
	}
	if(contextParams.density){
		density=contextParams.density; // actual project density
	}
	if(contextParams.exportDensity){
		requiredDensity=contextParams.exportDensity;
	}
	doExport(context,"process");
};




function doExport(context,exportType){

	doc = context.document;
	var command = context.command;
	var selection=context.selection;
	if(context.newSelection){
		selection=context.newSelection;
	}
	
    
	var userSelectionsFilePath = nil;
	docUUID= setDocId(context)
	if(!isDocSaved()){return}
    if(!isFrameworkVersionSameAsJS()){return}
    
	   var artboardEnum={};
	   if(exportType=="process"){
           artboardEnum= artboardsFromArboardIds(context,contextParams.artboardDetails);
	   }else if(exportType=="all"){
           overflowSketchPanel.saveArtboardsDetailsForSync_selectedArtboards_(context, null);
           artboardEnum= artboardsFromPage(context);
	   }else{
           artboardEnum= artboardsFromSelection(context);
	   }
	   
	   var validArtboardObjs=artboardEnum.artboardObjs;
	   var validArtboardIds=artboardEnum.artboardIds;
	   
	
	if (![validArtboardIds count]) {
		if(exportType=="selected"){
			[NSApp displayDialog:@"Please select the artboards you want to sync to Overflow.\n\n☝️ Selecting a layer inside the artboard should be enough." withTitle:@"No artboard selected"];
		}else if(exportType=="selected"){
			[NSApp displayDialog:@"This page does not contain any artboards." withTitle:@"No artboards found"];
			
		}else if(exportType=="process"){
            print(" ****** no artboards to process ***"); //probably return exit code
	   }
		return;
	}
	
	//alert(docStruct);
	pickOutFolder()
	var name = "info.json";
    
    var userOptions = nil;
	var temporaryDirectory = outFolder;
	path = temporaryDirectory+name;
	
	temporaryDirectory = nil;
	name = nil;
	
	var docStruct={}
	
    
    try {
        docStruct=export_main(context,validArtboardObjs,exportType,contextParams.artboardDetails,requiredDensity,contextParams.includeFlows);
    } catch (e) {
        print(e)
        // -184 to find the error line in code
        writeErrorToFile("Error from export_main " + e, docUUID);
        throw e;
    }
    
    
	if(exportType=="process"){
		
	}else{
		name = [docUUID stringByAppendingPathExtension:@"ovrsketchinfo"];
		temporaryDirectory = NSTemporaryDirectory();
		path = [temporaryDirectory stringByAppendingPathComponent:name];
        
        var frameworkNameForDevCheck = "overflowSketchPanel";
        var tempFileName = "";
        if(frameworkNameForDevCheck.indexOf("Dev") > -1) {
            tempFileName = [NSString stringWithFormat:@"%@-details-dev", docUUID];
        } else {
            tempFileName = [NSString stringWithFormat:@"%@-details", docUUID];
        }
        
        userSelectionsFilePath = [temporaryDirectory stringByAppendingPathComponent:[tempFileName stringByAppendingPathExtension:@"plist"]]];
        
        userOptions = [NSDictionary dictionaryWithContentsOfFile:userSelectionsFilePath];
        
        if (!userOptions){
            
            if (exportType != "process" && exportType != "all") {
                overflowSketchPanel.saveArtboardsDetailsForSync_selectedArtboards_(context, validArtboardObjs);
            }
            
            userOptions = [NSDictionary dictionaryWithContentsOfFile:userSelectionsFilePath];
        
        }
        
        
        
	}
	
	var sketchVersion = [[NSBundle mainBundle] objectForInfoDictionaryKey:@"CFBundleShortVersionString"];
	var sketchtoolPath = [[NSBundle mainBundle] pathForResource:@"sketchtool" ofType:nil inDirectory:@"sketchtool/bin"];
	var sketchmigratePath = [[NSBundle mainBundle] pathForResource:@"sketchmigrate" ofType:nil inDirectory:@"sketchtool/bin"];
    
    var appPath = [[NSBundle mainBundle] builtInPlugInsPath];
    var appPathArray = appPath.split("/");
    appPathArray.splice(appPathArray.length - 2, 2); // removes /Contents/PlugIns
    
	var directives = [NSMutableDictionary dictionary];
	[directives setObject:[[doc fileURL] path] forKey:@"path"];
    [directives setObject:appPathArray.join("/") forKey:@"appPath"];
    [directives setObject:version forKey:@"pluginVersion"];

	if (sketchVersion) {
		[directives setObject:sketchVersion forKey:@"version"];
	}
	if (sketchtoolPath) {
		[directives setObject:sketchtoolPath forKey:@"sketchtoolPath"];
	}
	if (sketchmigratePath) {
		[directives setObject:sketchmigratePath forKey:@"sketchmigratePath"];
	}
    
    var docExportOptions = getDocExportOptions(doc,context);
    
    if (docExportOptions) {
        [directives setObject:docExportOptions.exportDensity forKey:@"exportDensity"];
        [directives setObject:docExportOptions.includeFlows forKey:@"includeFlows"];
    }
    
    if (userOptions && userOptions.screensDensity) {
        [directives setObject:userOptions.screensDensity forKey:@"artboardDetails"];
    }
    
    
    
    
    
	[directives setObject:docStruct forKey:@"document"];
	sketchVersion = nil;
	sketchmigratePath = nil;
	sketchtoolPath = nil;
	validArtboardIds = nil;
	[directives writeToFile:path atomically:false];
	directives = nil;
	if(exportType=="process"){
		buildArchive();
	}else{
		var workspace = [NSWorkspace sharedWorkspace];
		var bundleId="io.overflow.mac.app";
		var applicationPath = [workspace absolutePathForAppBundleWithIdentifier:bundleId];
		if (!applicationPath) {
			[NSApp displayDialog:@"Please make sure that you installed and launched it: https://overflow.io/download" withTitle:"Could not find Overflow Desktop App"];
			return;
		}
		
//        [doc showMessage:@"Launching Overflow! with "+ path];
		
		[workspace openFile:path withApplication:applicationPath andDeactivate:true];
		workspace = nil;
		applicationPath = nil;
		path = nil;

	}
}

var artboardsFromSelection=function(context){

	   var artboardObjs=[[context valueForKey:@"selection"] valueForKeyPath:@"parentArtboard"];
	   var artboardIds = [[context valueForKey:@"selection"] valueForKeyPath:@"parentArtboard.@distinctUnionOfObjects.objectID"];
		var rartboardObjs=[[NSMutableArray alloc] init];
		var rartboardIds=[[NSMutableArray alloc] init];
		for (var j=0; j < [artboardObjs count]; j++) {
			var obj = [artboardObjs objectAtIndex:j]
			if([obj isKindOfClass:[MSArtboardGroup class]]){
				[rartboardObjs addObject:obj];
			}
		}
		for (var j=0; j < [artboardIds count]; j++) {
			var obj = [artboardIds objectAtIndex:j]
			if([obj isKindOfClass:[NSString class]]){
				[rartboardIds addObject:obj];
			}else{
				//alert([obj class]);
			}
	}
	   return {"artboardObjs":rartboardObjs,"artboardIds":rartboardIds}
}
var artboardsFromPage=function(context){
	   artboardIds = [[doc valueForKey:@"currentPage"] valueForKeyPath:@"artboards.@distinctUnionOfObjects.objectID"];
	   artboardObjs=[[doc valueForKey:@"currentPage"] valueForKeyPath:@"artboards"];
	   return {"artboardObjs":artboardObjs,"artboardIds":artboardIds}
}
var artboardsFromArboardIds=function(context,artboardsDetails){
	   var validArtboardIds = [NSMutableArray array];
	   var validArtboardObjs = [NSMutableArray array];
	   artboardObjs=[[doc valueForKey:@"currentPage"] valueForKeyPath:@"artboards"];
	   var loop = [artboardObjs objectEnumerator];
	   while (artboardObj = [loop nextObject]) {
           var artboardId=[artboardObj valueForKeyPath:@"objectID"];
            if ([artboardId isKindOfClass:[NSString class]]) {
                if(isArrayElement(artboardsDetails,artboardId)){
                    [validArtboardIds addObject:artboardId];
                    [validArtboardObjs addObject:artboardObj];
                }
            }
	   }
	   
	   loop = nil;
	   
	   return {"artboardObjs":validArtboardObjs,"artboardIds":validArtboardIds}
}

var isArrayElement=function(array,element){
	for(var n=0;n<array.length;n++){
		if(array[n].id==element){
			return true;
		}
	}
	return false;
}
	   
var isDocSaved=function(){
   if (![doc fileURL] || [doc isDraft]) {
		[NSApp displayDialog:@"Please save the document before exporting to Overflow." withTitle:@"Document not saved"];
		return false;
   }
   if ([doc isDocumentEdited]) {
	   var alertDialog = [NSAlert alertWithMessageText:@"Document not saved" defaultButton:@"Save and Continue" alternateButton:@"Cancel" otherButton:@"Continue" informativeTextWithFormat:@"To capture the latest changes in this Sketch document, Overflow needs to save it first.\n\n☝️ This might take a bit, depending on the document size."];
	   
	   var response = [alertDialog runModal];
	   if (response == NSAlertDefaultReturn) {
	   [doc showMessage:@"Saving document…"];
	   
	   [doc saveDocument:nil];
	   while ([doc isDocumentEdited]) {
				[[NSRunLoop currentRunLoop] runMode:NSDefaultRunLoopMode beforeDate:[NSDate distantFuture]];
	   }
	   }
	   
	   else if (response == NSAlertAlternateReturn) {
	   return false;
	   }
	   
	   response = nil;
	   alertDialog = nil;
   }
	   
   return true;
}

var writeErrorToFile= function(errorMsg, documentID){
    var tempFileDir = NSTemporaryDirectory();
    var fileName = [NSString stringWithFormat:"%@-ErrorData.txt", documentID];
    var pathForErrorFile = [tempFileDir stringByAppendingPathComponent:fileName];
    var string = JSON.stringify(errorMsg);
    var content = [NSString stringWithFormat:"%@", string]; ;
    [content writeToFile:pathForErrorFile atomically:false encoding:NSStringEncodingConversionAllowLossy error:nil];
}


var isFrameworkVersionSameAsJS=function(){
    
    var frameworkVersion = "0.0";
    var needsRestart = false;

    try {
        frameworkVersion = overflowSketchPanel.getFrameworkVersion();
        // needsRestart = false; change it when  we need to restart plugin at the future
    } catch (e){
		needsRestart = true;
    }
    
    
    if(frameworkVersion != version && needsRestart){
        
        var alertDialog = [NSAlert alertWithMessageText:@"Sketch needs to be restarted" defaultButton:@"OK" alternateButton:nil otherButton:nil informativeTextWithFormat:@"Please restart Sketch in order for the Overflow plugin update to be applied "];
        var response = [alertDialog runModal];
        if (response != NSAlertDefaultReturn) {
            return false;
        } else if (response == NSAlertDefaultReturn) {
            return false;
        }
        
        response = nil;
        alertDialog = nil;
        
    }

    return true;

};


// not used
var fileForVersionCheck = function (){
    
    var name = "overflowVersionCheck.plist";
    var path = NSTemporaryDirectory() + name;
    var data = [NSMutableDictionary dictionary];
    [data setObject:version forKey:@"version"];
    [data writeToFile:path atomically:false];
    data = nil;
    
}

var setDocId=function(context){
	var doc = context.document;
    
    if (doc == null) {
        doc = context.actionContext.document;
    }
    
	var command = context.command;
	var docUUID=getDocId(doc,context);
    
	if(!docUUID){
		docUUID=[[NSUUID UUID] UUIDString];
		[command setValue:docUUID forKey:@"docUUID" onLayer:[[doc pages] objectAtIndex:0] forPluginIdentifier:@"io.proto.overflow-test1"]
	}
    
    var docExportOptions = getDocExportOptions(doc,context);
    
    if (!docExportOptions){
        setDocDefaultExportOptions(doc,context);
    }
    
	return docUUID;
}

var getDocId=function(doc,context){
	var command = context.command;
	docUUID=[command valueForKey:@"docUUID" onLayer:[[doc pages] objectAtIndex:0] forPluginIdentifier:@"io.proto.overflow-test1"];
	return docUUID;
}

var getDocExportOptions=function(doc,context){
    
    var command = context.command;
    var exportOptions = [command valueForKey:@"__XCODE_PLUGIN_IDENTIFIER__:docExportOptions" onLayer:[[doc pages] objectAtIndex:0] forPluginIdentifier:@"__XCODE_PLUGIN_IDENTIFIER__"];
    
    try {
        var docExportOptions = [NSMutableDictionary dictionary];
        [docExportOptions setObject:exportOptions.exportDensity forKey:@"exportDensity"];
        [docExportOptions setObject:exportOptions.includeFlows forKey:@"includeFlows"];
        return docExportOptions;
    }catch (e) {
        return null;
    }
    
}


var getPreviousExportOptionsFromFile = function(doc,context){
    
    var docUUID = getDocId(doc,context);
    // read user options in case the file created with null docUUID
    var tempFileName = "";
    var frameworkNameForDevCheck = "overflowSketchPanel";
    if(frameworkNameForDevCheck.indexOf("Dev") > -1) {
        tempFileName = [NSString stringWithFormat:@"%@-details-dev", docUUID];
    } else {
        tempFileName = [NSString stringWithFormat:@"%@-details", docUUID];
    }
    
    var temporaryDirectory = NSTemporaryDirectory();
    var userSelectionsFilePath = [temporaryDirectory stringByAppendingPathComponent:[tempFileName stringByAppendingPathExtension:@"plist"]]];
    
    var userOptionsFromTempFile = [NSDictionary dictionaryWithContentsOfFile:userSelectionsFilePath];
    
    return userOptionsFromTempFile;
    
}

var setDocDefaultExportOptions=function(doc,context){
    
    var exportOptionsFromTempFile = getPreviousExportOptionsFromFile(doc,context);
    
    var exportDensity = [NSNumber numberWithInteger:1];
    var includeFlows = [NSNumber numberWithBool:false];
    
    if (exportOptionsFromTempFile && exportOptionsFromTempFile.exportDensity) {
        exportDensity = exportOptionsFromTempFile.exportDensity;
    }
    
    if(exportOptionsFromTempFile && exportOptionsFromTempFile.includeFlows){
        includeFlows = exportOptionsFromTempFile.includeFlows
    }
    
    var docExportOptions = [NSMutableDictionary dictionary];
    [docExportOptions setObject:exportDensity forKey:@"exportDensity"];
    [docExportOptions setObject:includeFlows forKey:@"includeFlows"];
    
    var command = context.command;
    [command setValue:docExportOptions forKey:@"__XCODE_PLUGIN_IDENTIFIER__:docExportOptions" onLayer:[[doc pages] objectAtIndex:0] forPluginIdentifier:@"__XCODE_PLUGIN_IDENTIFIER__"];
    getDocExportOptions(doc,context);
}


var sketchFunction=function(context){
	//context.document.showMessage("running Sketch function! ");
	//log(context);
	//alert("heheh");
	doExport(context,"selected");
}

var sketchFunctionFromUI=function(context){
	//log("sketchFunctionFromUI")
	//log(myContext);
	//sketchFunction(myContext.actionContext);
	sketchFunction(context);
	//myContext.actionContext.document.showMessage("running Sketch function from UI Panel!");
}

function openOverflowApp_unused(){
	var workspace = [NSWorkspace sharedWorkspace];
	if(1==1){
		var applicationPath = [workspace absolutePathForAppBundleWithIdentifier:bundleId];
		if (!applicationPath) {
			[NSApp displayDialog:@"Please make sure that you installed and launched it: https://overflow.io/download" withTitle:"Could not find Overflow Desktop App"];
			return;
		}
		
	}
	
	[doc showMessage:@"Launching Overflow! with "+ path];
	
	[workspace openFile:path withApplication:applicationPath andDeactivate:true];
	workspace = nil;
	applicationPath = nil;
	path = nil;
}



