/**

LICENSE AGREEMENT FOR Export to Proto.io PLUGIN

Copyright (c) 2015, PROTOIO INC All rights reserved.

BSD-2-Clause License: http://opensource.org/licenses/BSD-2-Clause
Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

---


**/



var message = "";
var sourceFolder="";
var fileName="";
var docName="";
var hiddenLayersInPage=[];
var initialPage=0;
var outFolder=null;
var outFolderToSandbox=null;
var outPackageFile=null;
var outPackageFolder=null;
var screens=[];
var totalArboardsInAllPages=0;
var exportMode="all";
var exportInvisible=false;
var currentArtboard;
var duplicateFileNameWarning=false;
var apVersion=true;
var minimalExportMode=false;
var version="0.1.18";
var debugMode=false;
var export_scale=1.0; //for layers
var export_assets_scale=1.0; //for exported images (we need them to be @3)
var exportSelectedItemsOnly=false;
var startTime;
var endTime;
var exportType="";
var logFileName="";
var createArhiveOnComplete=false;
var stopFileName="";
var includeFlows = false;
var originalParentArtboard;

function loopPages(doc){
	log ("Looping pages");
	var pagesCount=[[doc pages] count];
	for (var i=0;i<pagesCount;i++){
		var page=[[doc pages] objectAtIndex:i];
		log ("Page index "+i+": "+[page name]);
		hiddenLayersInPage=[];
		loopArtboardsInPage(doc,page);
		unhideHiddenLayersInPage();
	}
	if(totalArboardsInAllPages==0){
	    alert("No Artboards were found to export!");
	}else{
    finishExport();
  }
}


function loopSelectedArboards(aArtboards, artboardsDensities){
    hiddenLayersInPage=[];
    var artboardsCount=aArtboards.length;
	totalArtboardsToProcess=artboardsCount;
	var startTime = Date.now();
    for (var i=0;i<artboardsCount;i++){
      var artboard=aArtboards[i];
      var artboardId=[artboard objectID];
      var screenTitle=[artboard name];
      var backgroundColor= colorToRGBA([artboard backgroundColor]);
      //log("   Artboard index "+i+": "+screenTitle);
		processingArtboardNo++;
		currentArtboardTitle=screenTitle;
		logToFile('"progress":{"totalArtboardCount": '+totalArtboardsToProcess+',"currentArtboardNumber":'+processingArtboardNo+',"currentArtboardTitle": "'+currentArtboardTitle+'","message":""}');
    
        var currentArtboardDensity = findObjectByKey(artboardsDensities, artboardId);
        
        if (!currentArtboardDensity) {
            continue;
        }
        
        export_scale=1/currentArtboardDensity;

      var items=exportArtboard(artboard);
		if(stopFileExists()){
			break;
		}

      var layerUICoordinates=getUICoordinates(artboard);
      var position={'x':""+(layerUICoordinates.x * export_scale),'y':""+(layerUICoordinates.y * export_scale)}
      var size={'width':""+(layerUICoordinates.width *export_scale),'height':""+(layerUICoordinates.height*export_scale)}
      var  newScreen = {
              'id':""+artboardId,
              'title': "" + screenTitle,
              'position': position,
              'size':size,
              'layers':items,
              'backgroundColor':backgroundColor
      }

      screens.push(newScreen);
    }
    var processTime = Date.now() - startTime;
    print("Process time " + processTime)
    unhideHiddenLayersInPage();
	if(stopFileExists()){
		stopProcess();
		return;
	}

	// uncomment for debugging ( writes returned data to overflow)
//     var logFileName=NSTemporaryDirectory()+docUUID+".txt";
//    print(logFileName);
//     var string = JSON.stringify(screens);
//     var content = [NSString stringWithFormat:"%@", string]; ;
//     [content writeToFile:[NSString stringWithFormat:"%@", logFileName] atomically:false encoding:NSStringEncodingConversionAllowLossy error:nil];


  return finishExport();
}

function finishExport(){
	
    if(exportSelectedItemsOnly){
      buildAssetsFolder();
    }else{
        log("Finished exporting:");
		var pageId=[[doc currentPage] objectID];
		var pageName=[[doc currentPage] name];
		var output=JSON.stringify({info:{"about":"Overflow.io Sketch Panel Export","version":version},pages:[{'id':""+pageId,'name':""+pageName,screens:screens}]});
        print("JSON generated");
		log("JSON generated");
		return output;
		
   }
    
}

function findObjectByKey(array, value) {
    for (var i = 0; i < array.length; i++) {
        if (array[i].id == value) {
            return array[i].density;
        }
    }
    return null;
}

function writeOutput(output){
	var outString = [NSString stringWithFormat:"%@", output],
	filePath =  outFolder+"info.json";
	log("Writing JSON output");
	[outString writeToFile:filePath atomically:true encoding:NSUTF8StringEncoding error:nil];
	log("wrote output to "+filePath);
	buildArchive();
	return output;
 
}

function unhideHiddenLayersInPage(){
	hiddenItemsCount=hiddenLayersInPage.length;
	for(var i=0;i<hiddenItemsCount;i++){
		var currentLayer=hiddenLayersInPage[i];
		[currentLayer setIsVisible:true];
	}
}

function loopArtboardsInPage(doc,page){
	[doc setCurrentPage:page]
	var artboardsCount=[[page artboards] count]
	totalArboardsInAllPages+=artboardsCount;
	for (var i=0;i<artboardsCount;i++){
		var artboard=[[page artboards] objectAtIndex:i];
		var artboardId=[artboard objectID];
		var screenTitle=[artboard name];
		var backgroundColor= colorToRGBA([artboard backgroundColor]);
		log("   Artboard index "+i+": "+screenTitle);
		var items=exportArtboard(artboard);
		if(stopFileExists()){
			stopProcess();
			return;
		}
		var layerUICoordinates=getUICoordinates(artboard);
		// var artboardRulerBase=[parentArtboard rulerBase];
		//layerUICoordinates.x=layerUICoordinates.x+artboardRulerBase.x;
		//layerUICoordinates.y=layerUICoordinates.y+artboardRulerBase.y;
        var position={'x':""+layerUICoordinates.x,'y':""+layerUICoordinates.y}

        var size={'width':""+layerUICoordinates.width,'height':""+layerUICoordinates.height}
		var  newScreen = {
            'id':""+artboardId,
            'title': "" + screenTitle,
            'position': position,
            'size':size,
            'layers':items,
            'backgroundColor':backgroundColor
        }

		screens.push(newScreen);

	}
}



function exportArtboard(artboard){
	var artboardName=[artboard name];
	log("      processing artboard "+artboardName);
	currentArtboard=artboard;
	outFile=outFolder+"screen-"+artboardName+".png";
	// export_layer(artboard,"","");
	log("      exporting artboard "+artboardName+" as "+outFile);
    // print("      exporting artboard "+artboardName+" as "+outFile);``
    try{
        exportArtboardImage(artboard);
        // print(artboard)
        originalParentArtboard = artboard;
        var exportableChildren=processExportableChildren([artboard layers],"","");
//        print("exportableChildren " + exportableChildren);
    } catch (e){
        print("Inside export main " + e);
        throw e;
    }
	
	// print(exportableChildren);
	return exportableChildren;
}

function processExportableChildren(layers, originalLayersForSymbol, symbolParentInstanceID, maskParentLayer) {

    if (stopFileExists()) {
        return {};
    }

    var items = [];

    if ([layers count] == 0) {
        return items;
    }

    var layersCount = [layers count];
    
    if (!originalLayersForSymbol) {
        originalLayersForSymbol = [];
    }

    var maskParentsLayerQueue = [];

    for (var i = 0; i < layersCount; i++) {

        var layer = [layers objectAtIndex:i];

        if (![layer isVisible]) {
            continue;
        }

//        print("in loop mask parent layer " + JSON.stringify(maskParentLayer));
        var originalSymbolLayer = originalLayersForSymbol[i];

        var isMaskLayer = [layer hasClippingMask];

        // check if layer is a mask layer
        var maskFirstLayer = null;

        if (isMaskLayer) {
            // print("is mask layer " + layer);
            maskFirstLayer = getLayerProperties(layer, [layer objectID], maskParentLayer, true); //(originalSymbolLayer) ? getLayerProperties(originalSymbolLayer, [originalSymbolLayer objectID], maskParentLayer) :
            maskParentsLayerQueue.push(maskParentLayer);
            maskParentLayer = Object.assign({}, maskFirstLayer);

        }

        // check if is layer under mask and if the mask should break here
        var shouldMaskBreak = [layer shouldBreakMaskChain];
        if (maskParentLayer && shouldMaskBreak) {
            maskFirstLayer = null;
            maskParentLayer = maskParentsLayerQueue.pop();
        }

        if ( maskParentLayer && !isMaskSublayerVisible(layer, maskParentLayer) ) {
            continue;
        }

        // check if layer is symbol
        var isInstanceOfSymbol = isSymbolInstance(layer);
//        print( "isInstanceOfSymbol " + isInstanceOfSymbol )

        if (is_group(layer) || isInstanceOfSymbol) {
            
//            print("group " + layer);

            var originalObjectID = (originalSymbolLayer) ? [originalSymbolLayer objectID] : [layer objectID];
            if (isInstanceOfSymbol) {

                if (typeof symbolParentInstanceID == "undefined" || symbolParentInstanceID == null) {
                    symbolParentInstanceID = originalObjectID;
                } else {
                    symbolParentInstanceID = symbolParentInstanceID + "-" + originalObjectID;
                }
                
//                print("Layer name: " +  [layer name] + " id: " + symbolParentInstanceID)

                if (symbolParentInstanceID) {
                    originalObjectID = symbolParentInstanceID;
                }

                //copy symbol to arboard and process it
                originalSymbolLayer = [layer symbolMaster]; //[[[layer symbolMaster] layers] objectAtIndex: 0];
                
                var symbolMaster = ([layer isMemberOfClass:[MSSymbolMaster class]]) ? true : false;
                
                var includeBackgroundColorInInstance = 0;
                var hasBackgroundColor = 0;
                
                try{
                    
                    if (symbolMaster) {
                        includeBackgroundColorInInstance = [originalSymbolLayer includeBackgroundColorInInstance];
                        hasBackgroundColor = [originalSymbolLayer hasBackgroundColor];
                    } else {
                        includeBackgroundColorInInstance = [[layer symbolMaster] includeBackgroundColorInInstance];
                        hasBackgroundColor = [[layer symbolMaster] hasBackgroundColor];
                    }
                    
//                    if (includeBackgroundColorInInstance) {
//                        if (symbolMaster) {
//                            [originalSymbolLayer setIncludeBackgroundColorInInstance: false];
//                        } else {
//                            [[layer symbolMaster] setIncludeBackgroundColorInInstance: false];
//                        }
//                    }
                }catch(err){
                        
                }

                var originalSymbolChildren = (originalSymbolLayer) ? [originalSymbolLayer layers] : [[layer symbolMaster] layers];

                if (originalSymbolChildren && [originalSymbolChildren count] == 1 && is_group([originalSymbolChildren objectAtIndex: 0]))
                {
                    [[[originalSymbolChildren objectAtIndex:0] exportOptions ] removeAllExportFormats];
                }

                var layer_copy = detachSymbolAsAGroup([layer duplicate]);// detachStylesAndReplaceWithGroupRecursively: false];
                var childLayers = [[NSArray alloc] init];
                if (layer_copy && [layer_copy layers]) {
                    childLayers = [layer_copy layers];
//                    print("Has background color " + hasBackgroundColor);
                    if (hasBackgroundColor && includeBackgroundColorInInstance) {
//                        print("Splice executed ");
                        childLayers.splice(0,1);
                    }
                }

                // print("Parent id " + symbolParentInstanceID + " name " + [layer name]);


                var countSymbolSublayers = function countSubLayers(sublayer, countedSublayers) {

                    countedSublayers = 0;

                    for (var j = 0; j < sublayer.length; j++) {

                        var sublayersSublayer = sublayer[j];

                        countedSublayers++;
                        if (is_group(sublayersSublayer)) {
                            countedSublayers += countSubLayers([sublayersSublayer layers], countedSublayers);
                        }

                    }

                    return countedSublayers;

                };

                // print("counted sublayers Original " + countSymbolSublayers(originalSymbolChildren));
                // print("counted sublayers " + countSymbolSublayers(childLayers));


                if (originalSymbolChildren && [originalSymbolChildren count] == 1 && is_group([originalSymbolChildren objectAtIndex: 0 ]) && countSymbolSublayers(originalSymbolChildren) != countSymbolSublayers(childLayers))
                {

                    originalSymbolLayer = [originalSymbolChildren objectAtIndex:0];
                    originalSymbolChildren = [[originalSymbolChildren objectAtIndex:0] layers];

                }

                // print( "Group original name " + [originalSymbolLayer class] + " " + [originalSymbolLayer name]);
                // print( "Group name " + [layer class] + " " + [layer_copy name]);
                // print( "Original Symbol layers " + originalSymbolChildren );
                // print( "Copied Symbol layers " + childLayers );
                var childItems = processExportableChildren(childLayers, originalSymbolChildren, symbolParentInstanceID, maskParentLayer);
                
//                if (includeBackgroundColorInInstance) {
//                    if (symbolMaster) {
//                        [originalSymbolLayer setIncludeBackgroundColorInInstance: true];
//                    } else {
//                        [[layer symbolMaster] setIncludeBackgroundColorInInstance: true];
//                    }
//                }

            }  else {
                // print( "Group name no instance " + originalObjectID + " " + [layer name]);
                var childItems = [];
                if (originalSymbolLayer) {
                    childItems = processExportableChildren([layer layers], [originalSymbolLayer layers], symbolParentInstanceID, maskParentLayer);
                } else {
                    childItems = processExportableChildren([layer layers], null , null ,maskParentLayer);

                }


            }


            var groupID = originalObjectID;
            var childItemsCount = childItems.length;

            var newExportedItem = getLayerProperties(layer, groupID,maskParentLayer);
            addExtraDetailsOnJsonObj(layer, newExportedItem);

            items.push(newExportedItem);

             for (var n = 0; n < childItemsCount; n++) {
                 items.push(childItems[n]);
             }

            if (isInstanceOfSymbol) {

                var res = symbolParentInstanceID.split("-");

                if (res.length == 5) {
                    symbolParentInstanceID = null;
                } else if (res.length >= 10 && res.length % 5 == 0) {

                    // slice the last five elements of the array to get current inner symbol unique id
                    res = res.slice(0, res.length - 5);
                    symbolParentInstanceID = res.join('-');
                }

                if (layer_copy) {
                    [layer_copy removeFromParent];
                }
            }

        } else {

            // print("export_layer " + [layer name]);
            var exportedItem = export_layer(layer, originalSymbolLayer, symbolParentInstanceID, maskParentLayer);
            items.push(exportedItem);

        }

    }
    return items;
}



function specialLayerName(layer){
  var layerName=[layer name];
  if([layerName substringToIndex:1]=="@"){
    return true;
  }
  return false;
}

function getMaskSubLayerCorrectBounds(maskLayer, childLayer) {


    var childLayerBounds = getLayerBounds(childLayer);
    
    // print( "maskLayer" + JSON.stringify(maskLayer));
    // print("getMaskSubLayerCorrectBounds"+ JSON.stringify(childLayerBounds));

    var childLayerXYAxes = {
        x1: 0,
        x2: 0,
        y1: 0,
        y2: 0
    };

    // find correct y1 position of child layer
    if (childLayerBounds.origin.y < maskLayer.position.y) {
        childLayerXYAxes.y1 = maskLayer.position.y;
    } else {
        childLayerXYAxes.y1 = childLayerBounds.origin.y;
    }

    // find correct y2 position of child layer
    var childLayerY2 = childLayerBounds.origin.y + childLayerBounds.size.height;
    var maskLayerY2 = maskLayer.position.y + maskLayer.size.height;

    if (childLayerY2 > maskLayerY2) {
        childLayerXYAxes.y2 = maskLayerY2;
    } else {
        childLayerXYAxes.y2 = childLayerY2;
    }

    // find correct x1 position of child layer
    if (childLayerBounds.origin.x < maskLayer.position.x) {
        childLayerXYAxes.x1 = maskLayer.position.x;
    } else {
        childLayerXYAxes.x1 = childLayerBounds.origin.x;
    }

    // find correct x2 position of child layer
    var childLayerX2 =
        childLayerBounds.origin.x + childLayerBounds.size.width;
    var maskLayerX2 = maskLayer.position.x + maskLayer.size.width;

    if (childLayerX2 > maskLayerX2) {
        childLayerXYAxes.x2 = maskLayerX2;
    } else {
        childLayerXYAxes.x2 = childLayerX2;
    }

    var position = {
        x: childLayerXYAxes.x1,
        y: childLayerXYAxes.y1
    };

    var size = {
        width: childLayerXYAxes.x2 - childLayerXYAxes.x1,
        height: childLayerXYAxes.y2 - childLayerXYAxes.y1
    };

    return { position: position, size: size };
}

function exportArtboardImage(artboard){

    var sliceId= [artboard objectID];
//    // print( "Layer name " + originalSymbolLayer + " " + [ogLayer name]);
    var sliceName=[artboard name];
    var className=[artboard className]; //alexiso
    var fileName=[artboard name]+"~"+className+"~"+sliceId+".png";
    
    try{
        var sketch = require('sketch/dom');
        
        var exportImageOptions = {
        formats: 'png',
            'use-id-for-name': true,
        output: outFolder
        }
        
        if ( export_assets_scale > 1) {
            exportImageOptions.scales = "" + export_assets_scale;
        }
        
        sketch.export(artboard,exportImageOptions);
        
        if (export_assets_scale > 1) {
            
            fileName = outFolder + sliceId + "@" + export_assets_scale + "x.png";
            var newPath = outFolder + sliceId + ".png";
            [[NSFileManager defaultManager] moveItemAtPath:fileName toPath:newPath error:nil];
            
        }
        
    } catch (e) {
        // for sketch version 48 and older
        exportArtboardImageOlder(artboard);
    }
    




}

function exportArtboardImageOlder(artboard){
    
    print("Artboard older export")
    var sliceId= [artboard objectID];
    var sliceName=[artboard name];
    var className=[artboard className]; //alexiso
    var fileName=[artboard name]+"~"+className+"~"+sliceId+".png";
    
    var layer_copy = [artboard duplicate];
    
    [layer_copy removeFromParent];
    
    [[doc currentPage] addLayers: [layer_copy]];
    [[layer_copy frame] setX:-99999];
    [[layer_copy frame] setY:-99999];
    
    
    
    if(([layer_copy className]=="MSArtboardGroup" || [layer_copy className]=="MSSymbolMaster")){
        fileName=sliceId+".png";
    }
    fileName=escapeFilename(fileName);
    var outFile=outFolder+fileName;
    
    if(([layer_copy className]=="MSArtboardGroup" || [layer_copy className]=="MSSymbolMaster")){
        
        
        if ( !([layer_copy hasBackgroundColor] && ![layer_copy includeBackgroundColorInExport] ) ) {
            [layer_copy setIncludeBackgroundColorInExport:true];
            [layer_copy setHasBackgroundColor:true];
        }
        
        
        
        
        if ([file_manager fileExistsAtPath:outFile]) {
            log("Duplicate layer name: "+fileName);
            //duplicateFileNameWarning=true;
        }
        
        
        
        //       [layer_copy backgroundColor]
        // BOOL _hasBackgroundColor;
        //   BOOL _includeBackgroundColorInExport;
        var exportOptions=[layer_copy exportOptions]
        try{
            [[exportOptions sizes] removeAllObjects];
            var exportSize = [exportOptions addExportSize]
        }catch(e){
            //compatibility with Sketch 3.5
            try{
                [[exportOptions exportFormats] removeAllObjects];
            }catch(e){
                //compatibility with Sketch 3.9
                [exportOptions removeAllExportFormats];
            }
            var exportSize = [exportOptions addExportFormat]
        }
        
        //[exportSize setScale:export_scale]
        [exportSize setScale:export_assets_scale]
        
        try{
            var exportSizes=[exportOptions sizes]
        }catch(e){
            //compatibility with Sketch 3.5
            var exportSizes=[exportOptions exportFormats]
        }
        
        try {
            slice = [[MSSliceMaker slicesFromExportableLayer:layer_copy sizes:exportSizes] firstObject];
        }catch(e){
            try{
                //compatibility with Sketch 3.4
                slice = [[MSSliceMaker slicesFromExportableLayer:layer_copy sizes:exportSizes useIDForName:false] firstObject];
            }catch(e){
                //compatibility with Sketch 3.5
                slice=[[MSExportRequest exportRequestsFromExportableLayer:layer_copy exportFormats:exportSizes useIDForName:false] firstObject];
            }
            
        }
        
        
        [doc saveArtboardOrSlice:slice toFile:outFile];
        
        
        
    }
    
    [layer_copy removeFromParent];
    return;
    
    
}

function export_layer(ogLayer, originalSymbolLayer, symbolParentInstanceID,maskParentLayer){

    var sliceId= (originalSymbolLayer) ? [originalSymbolLayer objectID] : [ogLayer objectID];

    if (symbolParentInstanceID) {
      sliceId = symbolParentInstanceID + "-" + sliceId;
    }

    var newExportedItem = getLayerProperties(ogLayer, sliceId, maskParentLayer);
    addExtraDetailsOnJsonObj(ogLayer, newExportedItem);


    return newExportedItem;

}

function getLayerProperties(layer, sliceID, maskParentLayer, excludeExportScale){


    // print( "getLayerProperties layer" + layer);
    // print("getLayerProperties maskParentLayer"+ maskParentLayer);
    var sliceName= '';
    
    try{
        sliceName= encodeURIComponent([layer name]);
    } catch (e) {
        var layerNameTemp = [layer name];
        // added for UTF-16 error
        sliceName= '?';
    }
    
    var bounds = getLayerBounds(layer);

    if (maskParentLayer) {
        var maskChildLayerCorrectBounds = getMaskSubLayerCorrectBounds(maskParentLayer, layer);
        bounds.origin.x = maskChildLayerCorrectBounds.position.x;
        bounds.origin.y = maskChildLayerCorrectBounds.position.y;
        bounds.size.width = maskChildLayerCorrectBounds.size.width;
        bounds.size.height = maskChildLayerCorrectBounds.size.height;
    }

    // print("Expoirt scale " + export_scale)

    var exportScale = (excludeExportScale) ? 1 : export_scale;

    var exportedPosition = {
        'x': bounds.origin.x * exportScale,
        'y': bounds.origin.y * exportScale
    };

    var exportedSize = {
        'width': bounds.size.width * exportScale,
        'height': bounds.size.height * exportScale
    };


    var newExportedItem={
        'id':""+hashLayerId(sliceID),
        'name':"" + sliceName,
        'isGroup': is_group(layer) ? "1":"0" ,
        'size':exportedSize,
        'position':exportedPosition,
        'path':"" + sliceName,
        'pathID':"" + hashLayerId(sliceID)
    };

    return newExportedItem;

}

function getLayerBounds(layer){
    
    try {
        var coords=getUICoordinates(layer);
    } catch (e){
        var coords = getUICoordinates_exp(layer);
    }
    var artboardOriginalRulerBase=[currentArtboard rulerBase];
    var artboardOrigCoords=getUICoordinates_exp(currentArtboard);

    var bounds = {};
    bounds.origin = {};
    bounds.size = {};
    bounds.origin.x = coords.x -(-artboardOriginalRulerBase.x+artboardOrigCoords.x);
    bounds.origin.y = coords.y -(-artboardOriginalRulerBase.y+artboardOrigCoords.y);

    bounds.size.width = [[layer absoluteRect] width];
    bounds.size.height = [[layer absoluteRect] height];

    return bounds;

}

function addExtraDetailsOnJsonObj(ogLayer, itemObj) {



    // ckeck if layer has a flow
    var flowDetails = getFlowDetails(ogLayer);
    if (flowDetails) {
        itemObj.flow = flowDetails;
    }

    // check if layer is hotspot
    var isHotSpot = getHotspotDetails(ogLayer);
    if (isHotSpot) {
        itemObj.isHotspot = true;
    }

    return itemObj

}

function getHotspotDetails(ogLayer){

    var isHotspot = false;

    if ([ogLayer className]=="MSHotspotLayer" && [ogLayer isActive] ) {
        isHotspot = true;
    }

    return isHotspot;

}

function getFlowDetails(ogLayer){
    
    if( !includeFlows) {
        return null;
    }

	var flowTargetDetails = null;
    var flow = null;

    // for sketch versions < 49
    try {
        flow = ogLayer.flow();
    }
    catch(err) {
        return flowTargetDetails;
    }

    if (flow) {
        flowTargetDetails = {};
        flowTargetDetails.destinationArtboardID = "" + [flow destinationArtboardID] + "";
        flowTargetDetails.transitionType = [flow animationType];
        flowTargetDetails.transitionName = getTransitionName([flow animationType]);

        // print([ogLayer name]);
        // print([[flow destinationArtboard] name]);
        // print([[flow destinationArtboard] objectID]);
        // print(flowTargetDetails.transitionType);
        // print(flowTargetDetails.transitionName);
    }



    return flowTargetDetails;

}

function isMaskSublayerVisible(layer, firstMaskLayer){

    var childLayer = getLayerBounds(layer);

    if ( childLayer.origin.x + childLayer.size.width < firstMaskLayer.position.x || childLayer.origin.x > firstMaskLayer.position.x + firstMaskLayer.size.width) {
        return false;
    } else if ( childLayer.origin.y + childLayer.size.height < firstMaskLayer.position.y || childLayer.origin.y > firstMaskLayer.position.y + firstMaskLayer.size.height ) {
        return false;
    }

    return true;

}

function getTransitionName(transitionNumber) {

    var transitionNameFromNumber = "other";

    switch (transitionNumber) {

        case -1: transitionNameFromNumber = "none"; // no animation
            break;
        case 0: transitionNameFromNumber = "slideFromRight"; // Slide from the right
            break;
        case 1: transitionNameFromNumber = "slideFromLeft"; // Slide from the left
            break;
        case 2: transitionNameFromNumber = "slideFromBottom"; // Slide from the bottom
            break;
        case 3: transitionNameFromNumber = "slideFromTop"; // Slide from the top
            break;
        default:
			break;
    }


    return transitionNameFromNumber;

}


function getUICoordinates_exp (layer){
    // This returns the *exact* coordinates you see on Sketch's inspector
    var  f = [layer frame],
      x = [[layer absoluteRect] x],
      y = [[layer absoluteRect] y],
     ui = {
      x: x,
      y:y,
      width: f.width(),
      height: f.height()
    }
    return ui
  }

function getUICoordinates (layer){

    // This returns the *exact* coordinates you see on Sketch's inspector
    var  f = [layer frame],
      x = [[layer absoluteRect] rulerX],
      y = [[layer absoluteRect] rulerY],
     ui = {
      x: x,
      y:y,
      width: f.width(),
      height: f.height()
    }

    return ui
  }

function is_group(layer) {
  return [layer isMemberOfClass:[MSLayerGroup class]] || [layer isMemberOfClass:[MSArtboardGroup class]];
}

function hashLayerId(layerID){

    if(layerID.split("-").length == 5){
        return layerID;
    }

    var hash = 0, i, chr;
    if (layerID.length === 0) return hash;
    for (i = 0; i < layerID.length; i++) {
        chr   = layerID.charCodeAt(i);
        hash  = ((hash << 5) - hash) + chr;
        hash |= 0; // Convert to 32bit integer
    }
    return hash;

}

function isSymbolInstance(layer){

    // check is its class is MSSymbol
    var isSymbol = [layer isMemberOfClass:[MSSymbolInstance class]];

//    print("Is symbol " + isSymbol)

    // if is symbol check using detach as a group gives back layers - error with some symbols that on detach return undefined (in sketch they disappear)
    if (isSymbol) {
        
        var copyLayer = [layer duplicate];
//        print(copyLayer)
        try {
            copyLayer = detachSymbolAsAGroup(copyLayer);// [copyLayer detachStylesAndReplaceWithGroupRecursively: false];
            [copyLayer layers];
        } catch (error){
            // if (copyLayer){
            //     print("symbol with error " + [copyLayer name]);
            // }
            isSymbol = false;
        }

        if (copyLayer) {
            copyLayer.removeFromParent();
        }

    }


    return isSymbol;

	// return [layer isMemberOfClass:[MSSymbolInstance class]] ];
}

function detachSymbolAsAGroup(layer) {
    var newGroupFromSymbol = null;
    
    try {
        // support for sketch version <= 52.2
        newGroupFromSymbol = [layer detachByReplacingWithGroup];
//        print(" <= 52.2 ");
    } catch(error) {
        try {
            // support for sketch version >= 53
            newGroupFromSymbol = [layer detachStylesAndReplaceWithGroupRecursively: false];
//            print(" >= 53 ");
        } catch(newError){
            newGroupFromSymbol = null
        }
    }
    
    return newGroupFromSymbol;
    
}

function isSymbol(layer){
	return [layer isMemberOfClass:[MSSymbolInstance class]] ];
}

function initFolders(){
	file_manager = [NSFileManager defaultManager];
	if ([file_manager fileExistsAtPath:outFolder]) {
    	[file_manager removeItemAtPath:outFolder error:nil];
  	}
	[file_manager createDirectoryAtPath:outFolder withIntermediateDirectories:true attributes:nil error:nil];
}

function initLogging(){
	logFileName=NSTemporaryDirectory()+docUUID+".ovrlog"
	//[file_manager createFileAtPath:logFileName contents:nil attributes:nil];
}

function initStopFile(){
	stopFileName=NSTemporaryDirectory()+docUUID+".ovrstop"
	file_manager = [NSFileManager defaultManager];
	if(stopFileExists()){
		[file_manager removeItemAtPath:stopFileName error:nil];
	}
}

function stopFileExists(){
	file_manager = [NSFileManager defaultManager];
	return [file_manager fileExistsAtPath:stopFileName];
}

function stopProcess(){
	if(debugMode){
		alert("Processing stopped");
	}
	if(stopFileExists()){
	   file_manager = [NSFileManager defaultManager];
	   [file_manager removeItemAtPath:stopFileName error:nil];
   }
}
	   
function logToFile(message){
	//var outString = [NSString stringWithFormat:@"%@",output],
	var str = [NSString stringWithFormat:@"%@\n",message];
//    print(message);
	
	var myHandle = [NSFileHandle fileHandleForWritingAtPath:logFileName];
	[myHandle seekToEndOfFile];
	[myHandle writeData:[str dataUsingEncoding:NSUTF8StringEncoding]];
    [myHandle closeFile];
	
}

function pickOutFolder(){
	var export_to_path=NSTemporaryDirectory();
	var export_to_file=docUUID;//docName;
	outFolderToSandbox=export_to_path;
	outFolder=export_to_path+export_to_file+".ovrtemp/";
	outPackageFolder=export_to_path;
	outPackageFile=export_to_file;
	return true;
}

function pickOutFolder_old(){
	
	
    if ([doc fileURL] == null) {
      alert("You need to save your document first.");
      return false;
    } else {

      var file_path ="";//getDefault("outFolder");
      if(file_path==""){
        file_path=com.bomberstudios.getFileFolder();
      }
      log(file_path);
      var exportPath=openSavePanel(docName);
      var export_to_path=exportPath.path;
      var export_to_file=exportPath.fileName;      
      //setDefault("outFolder",export_to_path);
      outFolderToSandbox=export_to_path+"/";
      if(exportSelectedItemsOnly){
        outFolder=export_to_path+"/"+export_to_file+" Assets/";
      }else{
        outFolder=export_to_path+"/"+export_to_file+".protoiotemp/";  
      }
		alert(outFolder);
		
       outPackageFolder=export_to_path;
       outPackageFile=export_to_file;
    }
    return true;

  }
  var openSavePanelWithFolder = function(name) {
    var panel = [NSOpenPanel openPanel]
    //[panel setNameFieldStringValue: name + ".protoioimport"]
    [panel setPrompt:@"Save"];
    [panel setCanChooseDirectories:true];
    [panel setCanCreateDirectories:true];
    if (panel.runModal() == 0) {
      return nil
    }
    //DNF: check uniqueness in future version
    var fileName=docName; 
    var path = panel.URL().path();
    return {"path":path,"fileName":fileName};

  }

  var openSavePanel = function(name) {
    if(apVersion){
      return openSavePanelWithFolder(name);  
    }
    var panel = [NSSavePanel savePanel]
    [panel setNameFieldStringValue: name + ".protoio"]
    [panel setPrompt:@"Save"];
    //[panel setCanChooseDirectories:false];
    [panel setCanCreateDirectories:true];
    if (panel.runModal() == 0) {
      return nil
    }

    var fileName=panel.URL().lastPathComponent();
    var path = panel.URL().URLByDeletingLastPathComponent().path();

    return {"path":path,"fileName":fileName};
  }


function doStuff(aArtboards, artboardsDensities){
  log("Plugin version "+version);
  
	initFolders();
	initLogging();
	initStopFile();
	totalArtboardsToProcess=0;
	processingArtboardNo=0;
	currentArtboardTitle="";
	if(aArtboards){
		if(exportType=="process"){
			return loopSelectedArboards(aArtboards, artboardsDensities);
		}else{
			return finishExport();
		}
  }else{
    loopPages(doc);  
  }
  

  [doc setCurrentPage:initialPage];
  if(duplicateFileNameWarning){
        //alert("Some assets could not be exported. Please make sure you do not have duplicate layer names.");
  }


}

function doConfirm(message){
	return true;
    var alert=[NSAlert alertWithMessageText:"Export "+message+" to Proto.io" defaultButton:"Export" alternateButton:"Cancel" otherButton:"" informativeTextWithFormat:""];
    var accessory = [[NSView alloc] initWithFrame:NSMakeRect(0,0,300,110)];
    
    var checkbox = [[NSButton alloc] initWithFrame:NSMakeRect(0,80,300,25)];
    [checkbox setButtonType:NSSwitchButton];
    [checkbox setTitle:@"Export hidden layers"];
    var optionExportHidden =getDefault("optionExportHidden");
    if(!optionExportHidden || optionExportHidden=="" || optionExportHidden=="1"){
        [checkbox setState:NSOnState];
    }
    [accessory addSubview:checkbox];


    var checkbox2 = [[NSButton alloc] initWithFrame:NSMakeRect(0,55,300,25)];
    [checkbox2 setButtonType:NSSwitchButton];
    [checkbox2 setTitle:@"Export layers prefixed with '@' as single items"];
    var optionMinimalExport =getDefault("optionMinimalExport");
    
    if(!optionMinimalExport || optionMinimalExport=="" || optionMinimalExport=="1"){
        [checkbox2 setState:NSOnState];
    }
    [accessory addSubview:checkbox2];

    var label=[[NSTextField alloc] initWithFrame:NSMakeRect(0,20,80,25)];
    label.stringValue="Scale: "
    label.editable=false;
    label.bordered=false;
    [label setAlignment:0];
    label.useSingleLineMode = true
    label.drawsBackground = false
    [accessory addSubview:label];

    var combobox = [[NSComboBox alloc] initWithFrame:NSMakeRect(40, 25, 55, 25)];
    [combobox addItemsWithObjectValues:["1x", "1.5x", "2x", "3x"]];
    [accessory addSubview:combobox];

    var defaultScale=getDefault("optionExportScale");
    if(!defaultScale || defaultScale==""){
      defaultScale="1x";
    }else{
      defaultScale=defaultScale+"x";
    }
    [combobox setStringValue:defaultScale];


    var about=[[NSTextField alloc] initWithFrame:NSMakeRect(0,-10,200,25)];
    about.stringValue="(Proto.io Plugin version "+version+")"
    about.editable=false;
    about.bordered=false;
    [about setAlignment:0];
    about.useSingleLineMode = true
    about.drawsBackground = false
    [about setFont:[NSFont systemFontOfSize:10]];
    [accessory addSubview:about];

    [alert setAccessoryView:accessory];
    [alert layout];

    var button = [alert runModal];
    
    var checkstate = [checkbox state] == NSOnState;
    //cancel=0, onlyexportable=-1,allitems=1
    exportInvisible=checkstate;
    setDefault("optionExportHidden",exportInvisible?"1":"0");

    var checkstate2 = [checkbox2 state] == NSOnState;
    minimalExportMode=checkstate2;
    if(minimalExportMode){
      log("Minimal export")
    }
    
    setDefault("optionMinimalExport",minimalExportMode?"1":"0");


    if(button==0){
        return false;
    }else if(button==-1){
        exportMode="exportable";
    }else if(button=1){
        exportMode="all";
    }

  var comboboxScale=1;
  if ([combobox indexOfSelectedItem] != -1) {
    comboboxScale=[combobox objectValueOfSelectedItem].replace(/[^0-9.]/g,"");
   }else{
    comboboxScale=([combobox stringValue].replace(/[^0-9.]/g,""));
   }
   setDefault("optionExportScale",comboboxScale.toString());
   export_scale=eval(comboboxScale);
  return true;
}


function export_main(context,aArtboards,exportTypeParam,artboardsDensities,requiredDensity, includeFlowsUserSelection) {
	exportType=exportTypeParam;
	doc=context.document;
	selection = context.selection;
	//designed in 3, req 3
	//assets in @1
	//scale /3
	//design 2
	//assets 3/2
	//expo /2
	
	// export_scale=1/density;
    // alert(export_scale);
	// export_assets_scale=requiredDensity/density;
    print("Artboards to export " + aArtboards);
    includeFlows = includeFlowsUserSelection;
    export_assets_scale = requiredDensity;
	setStartTime();
	docName=[doc displayName].replace(".sketch","");
    initialPage=[doc currentPage];
    var message="All Pages and Artboards"
    if(aArtboards && aArtboards.length>0){message="Selected Artboards"}
    if(exportSelectedItemsOnly){message="Selected Items"}
	
	if(doConfirm(message)){
	
		if (pickOutFolder()){
	
			return doStuff(aArtboards,artboardsDensities);
		}
	}

	
}


function export_selected_items_main(selectedItems,selectedArboards){
  setStartTime();
  exportSelectedItemsOnly=true;
  extendSelection(selectedItems);
  export_main(selectedArboards);

}

function setStartTime(){
  startTime=[NSDate date];
}
function setEndTime(){
  endTime=[NSDate date];
}
function getTimeTaken(){
  return [endTime timeIntervalSinceDate:startTime];

}

function extendSelection(items){
  //loops through all selected items and finds children that should also be included
  var count=[items count]
  for(var i=0;i<count;i++){
    currentItem=[items objectAtIndex:i];
    if(is_validExportableItem(currentItem)){
      [globalSelectedItems setObject:1 forKey:[currentItem objectID]];
    }
    if(is_group(currentItem)){
      extendSelection([currentItem layers]);
    }
  }

}

function log(message){
  if(!debugMode){return;}
	if(!doc){ return;}
  [doc showMessage:message];
  print(message);
}

function buildAssetsFolder(){
    log("Assets saved here: "+outFolder);
    workspace = [[NSWorkspace alloc] init];
    [workspace openFile:outFolderToSandbox];
    [workspace selectFile:outFolder inFileViewerRootedAtPath:outFolderToSandbox];
    task = null
}

function buildArchive(){
	if(!createArhiveOnComplete){
		setEndTime();
		archiveWithoutArchive();
		return;
	}
	//alert(outFolder);
    var task = [[NSTask alloc] init];
	/*
	var argsArray=[[NSArray alloc] init];
	argsArray[0]="-r";
	argsArray[1]="../"+outPackageFile;
	argsArray[2]="./";
	 */
    //var argsArray = [NSArray arrayWithObjects:@"-r","../"+outPackageFile,@"./", nil];
	var argsArray=[[NSMutableArray alloc] initWithCapacity:3];
	[argsArray addObject:@"-r"];
	[argsArray addObject:[NSString stringWithFormat:@"../%@.ovrsketch",outPackageFile]];
	[argsArray addObject:@"./"];
	
    [task setCurrentDirectoryPath:outFolder];
    [task setLaunchPath:"/usr/bin/zip"];
    [task setArguments:argsArray];
    [task launch];
    setEndTime();
    archiveComplete();
}

function archiveComplete(){
    var archiveFile=outFolderToSandbox+outPackageFile+".ovrsketch";
    var file_manager = [NSFileManager defaultManager];
    if([file_manager fileExistsAtPath:archiveFile]){
       [[NSFileManager defaultManager] removeItemAtPath:archiveFile error:nil]  
    }
  if ([file_manager fileExistsAtPath:outFolder]) {
    var timeTaken=getTimeTaken();
    var delay=timeTaken/5;
    [NSThread sleepForTimeInterval:delay]
    if(apVersion){
      //DNF: check uniqueness in future versions
      [[NSFileManager defaultManager] copyItemAtPath:outFolder+outPackageFile+".ovrsketch" toPath:archiveFile error:nil];
    }
    if(!debugMode){
      [[NSFileManager defaultManager] removeItemAtPath:outFolder error:nil]
    }
    }
    log("Overflow package saved here: "+outFolderToSandbox+outPackageFile+".ovrsketch");
	if(1==1){
		var workspace = [NSWorkspace sharedWorkspace];
		var applicationPath = [workspace absolutePathForAppBundleWithIdentifier:bundleId];
		if (!applicationPath) {
			//[NSApp displayDialog:@"Please make sure that you installed and launched it: https://overflow.io/download" withTitle:"Could not find Overflow Desktop App"];
			//return;
		}
		logToFile('"finish":{"doc":"'+archiveFile+'"}');
		//[doc showMessage:@"Launching Overflow! with "+ archiveFile];
		
		//[workspace openFile:archiveFile withApplication:applicationPath andDeactivate:true];
			
		workspace = nil;
		applicationPath = nil;
		path = nil;
	}
}

function archiveWithoutArchive(){
	archiveFile="";
	logToFile('"finish":{"doc":"'+archiveFile+'"}');
}


function  escapeFilename (acFilename) {
     if (!acFilename){
         acFilename = "";
     }
     //--Invalid characters \ / : ? * < > " |
     acFilename = acFilename.replace(/\\/g, "-");
     acFilename = acFilename.replace(/[/]/g, "-");
     acFilename = acFilename.replace(/:/g, "-");
     acFilename = acFilename.replace(/[?]/g, "-");
     acFilename = acFilename.replace(/[*]/g, "-");
     acFilename = acFilename.replace(/[<]/g, "-");
     acFilename = acFilename.replace(/[>]/g, "-");
     acFilename = acFilename.replace(/[""]/g, '-');
     acFilename = acFilename.replace(/[|]/g, "-");
     try{
      //temporarily remove accented character fix because .normalize is not supported by older OSX versions
      //will look for an alternative function
      acFilename=acFilename.normalize('NFD').replace(/[\u0300-\u036f]/g,""); //Remove accented characters and diacritics 
     }catch(e){

     }
     
     return acFilename.trim();
}

function colorToRGBA(color){
  var rValue= "rgba(" + ([color red]*255).toFixed(0) + "," + ([color green]*255).toFixed(0) + "," + ([color blue]*255).toFixed(0) + "," + [color alpha].toFixed(2) + ")";
  return rValue;
}
