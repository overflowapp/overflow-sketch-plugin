
// Run this code in the `Custom Script` window in Sketch

// 1. does user have Midnight installed and enabled?
if(NSClassFromString("DLMidnight")) {

	// 2. get the current theme
  const currentTheme = DLMidnight.main().currentTheme()

  
  // 3. All possible colors in a theme:

	const borderColor = currentTheme.borderColor();
	log("borderColor: " + DLMidnightUtils.hexFromColor(borderColor));

	const accentColor = currentTheme.accentColor();
	log("accentColor: " + DLMidnightUtils.hexFromColor(accentColor));

	const activeCanvasColor = currentTheme.activeCanvasColor();
	log("activeCanvasColor: " + DLMidnightUtils.hexFromColor(activeCanvasColor));

	const activeCanvasColorWithoutArtboards = currentTheme.activeCanvasColorWithoutArtboards();
	log("activeCanvasColorWithoutArtboards: " + DLMidnightUtils.hexFromColor(activeCanvasColorWithoutArtboards));

	const listArtboardColor = currentTheme.listArtboardColor();
	log("listArtboardColor: " + DLMidnightUtils.hexFromColor(listArtboardColor));

	const listLayerOddColor = currentTheme.listLayerOddColor();
	log("listLayerOddColor: " + DLMidnightUtils.hexFromColor(listLayerOddColor));

	const listLayerEvenColor = currentTheme.listLayerEvenColor();
	log("listLayerEvenColor: " + DLMidnightUtils.hexFromColor(listLayerEvenColor));

	const sidebarColor = currentTheme.sidebarColor();
	log("sidebarColor: " + DLMidnightUtils.hexFromColor(sidebarColor));

	const tabbarColor = currentTheme.tabbarColor();
	log("tabbarColor: " + DLMidnightUtils.hexFromColor(tabbarColor));

	const inspectorSectionHeaderDarkColor = currentTheme.inspectorSectionHeaderDarkColor();
	log("inspectorSectionHeaderDarkColor: " + DLMidnightUtils.hexFromColor(inspectorSectionHeaderDarkColor));

	const sheetHeaderColor = currentTheme.sheetHeaderColor();
	log("sheetHeaderColor: " + DLMidnightUtils.hexFromColor(sheetHeaderColor));

	const sheetBackgroundColor = currentTheme.sheetBackgroundColor();
	log("sheetBackgroundColor: " + DLMidnightUtils.hexFromColor(sheetBackgroundColor));

	const sharedObjectSectionHeaderColor = currentTheme.sharedObjectSectionHeaderColor();
	log("sharedObjectSectionHeaderColor: " + DLMidnightUtils.hexFromColor(sharedObjectSectionHeaderColor));

	const sharedObjectSectionHeaderLightColor = currentTheme.sharedObjectSectionHeaderLightColor();
	log("sharedObjectSectionHeaderLightColor: " + DLMidnightUtils.hexFromColor(sharedObjectSectionHeaderLightColor));

	const textColor = currentTheme.textColor();
	log("textColor: " + DLMidnightUtils.hexFromColor(textColor));

	const textfieldPlaceholderColor = currentTheme.textfieldPlaceholderColor();
	log("textfieldPlaceholderColor: " + DLMidnightUtils.hexFromColor(textfieldPlaceholderColor));

	const textfieldBackgroundColor = currentTheme.textfieldBackgroundColor();
	log("textfieldBackgroundColor: " + DLMidnightUtils.hexFromColor(textfieldBackgroundColor));

	const textfieldBorderColor = currentTheme.textfieldBorderColor();
	log("textfieldBorderColor: " + DLMidnightUtils.hexFromColor(textfieldBorderColor));

	const stepperBackgroundColor = currentTheme.stepperBackgroundColor();
	log("stepperBackgroundColor: " + DLMidnightUtils.hexFromColor(stepperBackgroundColor));

	const stepperArrowColor = currentTheme.stepperArrowColor();
	log("stepperArrowColor: " + DLMidnightUtils.hexFromColor(stepperArrowColor));

	const rulerBackgroundColor = currentTheme.rulerBackgroundColor();
	log("rulerBackgroundColor: " + DLMidnightUtils.hexFromColor(rulerBackgroundColor));

	const rulerTicksColor = currentTheme.rulerTicksColor();
	log("rulerTicksColor: " + DLMidnightUtils.hexFromColor(rulerTicksColor));

}
